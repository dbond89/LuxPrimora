
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum MusicPlayType { Play, Stop, FadeIn, FadeOut, FadeTo, FadeOutPlay }

	public enum MusicPlayFromType { Start, CurrentChannelTime, StoredTimePosition }

	public class PlayMusic : BaseData
	{
		[EditorHelp("Music Channel", "Define the music channel that will be used.\n" +
			"The default channel is 0.", "")]
		[EditorLimit(0, false)]
		public int channel = 0;

		[EditorHelp("Play Type", "Select how the music should be played (or stopped):\n" +
			"- Play: Plays the music clip and stops the currently playing clip.\n" +
			"- Stop: Stops the currently playing music clip.\n" +
			"- Fade In: Fades in the music clip and stops the currently playing clip.\n" +
			"- Fade Out: Fades out the currently playing music clip and stops it.\n" +
			"- Fade Out Play: Fades out the currently playing music clip and plays the new one after fading out is done.\n" +
			"- Fade To: Fades from the currently playing clip to the new one.", "")]
		public MusicPlayType type = MusicPlayType.Play;

		[EditorHelp("Play Stored Music", "The currently stored clip will be played from it's stored time position.", "")]
		[EditorCondition("type", MusicPlayType.Play)]
		[EditorCondition("type", MusicPlayType.FadeIn)]
		[EditorCondition("type", MusicPlayType.FadeTo)]
		[EditorCondition("type", MusicPlayType.FadeOutPlay)]
		public bool stored = false;

		[EditorHelp("Stored ID", "Define the ID used to store the clip.\n" +
			"You can store multiple clips by using different IDs.\n" +
			"The default ID is 0.", "")]
		[EditorLimit(0, false)]
		[EditorCondition("stored", true)]
		public int storedID = 0;

		[EditorHelp("Music Clip", "Select the music clip that will be played.", "")]
		[EditorElseCondition]
		[EditorAutoInit]
		public AssetSelection<MusicClipAsset> musicClip;

		[EditorHelp("Target Volume (0-1)", "The volume the music will be played at.\n" +
			"Doesn't change the overall music volume or the channel's volume.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider = true)]
		public float targetVolume = 1;

		[EditorHelp("Play From", "Select from what time the music clip will be played:\n" +
			"- Start: From the start of the clip.\n" +
			"- Current Channel Time: From the play time of the current music channel's music.\n" +
			"- Stored Time Position: From the last stored time position of the music clip (start if none stored).", "")]
		[EditorEndCondition(2)]
		public MusicPlayFromType playFromType = MusicPlayFromType.Start;

		[EditorHelp("Fade Time (s)", "The time in seconds used to fade the music clip.", "")]
		[EditorCondition("type", MusicPlayType.FadeIn)]
		[EditorCondition("type", MusicPlayType.FadeOut)]
		[EditorCondition("type", MusicPlayType.FadeTo)]
		[EditorCondition("type", MusicPlayType.FadeOutPlay)]
		[EditorLimit(0.0f, false)]
		public float fade = 1;

		[EditorEndCondition]
		[EditorAutoInit]
		public Interpolation interpolation;

		public PlayMusic()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("fromCurrentTime"))
			{
				bool tmp = false;
				data.Get("fromCurrentTime", ref tmp);
				if(tmp)
				{
					this.playFromType = MusicPlayFromType.CurrentChannelTime;
				}
			}
		}

		public void Play()
		{
			if(MusicPlayType.Play == this.type)
			{
				if(this.stored)
				{
					Maki.Audio.GetMusicChannel(this.channel).PlayStored(this.storedID);
				}
				else
				{
					MusicClipAsset asset = this.musicClip;
					if(asset != null)
					{
						Maki.Audio.GetMusicChannel(this.channel).Play(asset.Settings, this.targetVolume, this.playFromType);
					}
				}
			}
			else if(MusicPlayType.Stop == this.type)
			{
				Maki.Audio.GetMusicChannel(this.channel).Stop();
			}
			else if(MusicPlayType.FadeIn == this.type)
			{
				if(this.stored)
				{
					Maki.Audio.GetMusicChannel(this.channel).FadeInStored(this.storedID,
						this.fade, this.interpolation);
				}
				else
				{
					MusicClipAsset asset = this.musicClip;
					if(asset != null)
					{
						Maki.Audio.GetMusicChannel(this.channel).FadeIn(asset.Settings,
							this.targetVolume, this.playFromType,
							this.fade, this.interpolation);
					}
				}
			}
			else if(MusicPlayType.FadeOut == this.type)
			{
				Maki.Audio.GetMusicChannel(this.channel).FadeOut(this.fade, this.interpolation);
			}
			else if(MusicPlayType.FadeTo == this.type)
			{
				if(this.stored)
				{
					Maki.Audio.GetMusicChannel(this.channel).FadeToStored(this.storedID,
						this.fade, this.interpolation);
				}
				else
				{
					MusicClipAsset asset = this.musicClip;
					if(asset != null)
					{
						Maki.Audio.GetMusicChannel(this.channel).FadeTo(asset.Settings,
							this.targetVolume, this.playFromType,
							this.fade, this.interpolation);
					}
				}
			}
			else if(MusicPlayType.FadeOutPlay == this.type)
			{
				if(this.stored)
				{
					Maki.Audio.GetMusicChannel(this.channel).FadeOutPlayStored(this.storedID,
						this.fade, this.interpolation);
				}
				else
				{
					MusicClipAsset asset = this.musicClip;
					if(asset != null)
					{
						Maki.Audio.GetMusicChannel(this.channel).FadeOutPlay(asset.Settings,
							this.targetVolume, this.playFromType,
							this.fade, this.interpolation);
					}
				}
			}
		}

		public override string ToString()
		{
			return "Channel " + this.channel + ": " +
				this.type + (MusicPlayType.Stop == this.type ? "" :
					(this.stored ?
						" stored " + this.storedID : " " +
						(this.musicClip != null ? this.musicClip.ToString() : "")));
		}
	}
}
