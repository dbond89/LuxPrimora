
using UnityEngine;

namespace GamingIsLove.Makinom
{
	public class MusicClipAsset : MakinomGenericAsset<MusicClipSetting>
	{
		public MusicClipAsset()
		{

		}

		public override string DataName
		{
			get { return "Music Clip"; }
		}
	}

	public class MusicClipSetting : BaseIndexData
	{
		[EditorHelp("Name", "The name of the music clip.")]
		[EditorFoldout("Music Settings", "Set the name and base settings of the music clip.")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Audio Clip", "Select the audio clip used for this music clip.")]
		[EditorSeparator]
		public AssetSource<AudioClip> clip = new AssetSource<AudioClip>();

		[EditorHelp("Maximum Volume", "The maximum volume this music clip will be played at (between 0 and 1).")]
		[EditorSeparator]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		public float maxVolume = 1;

		[EditorHelp("Loop Clip", "This music clip will replay when it reaches the end.")]
		public bool doLoop = false;

		[EditorHelp("Store Time Position", "Automatically store the current time position of the music clip when stopping or changing to a different music clip.\n" +
			"The music can restart from the stored time position by using the 'Play From' setting in the play music settings.")]
		public bool storeTimePosition = false;

		// start time
		[EditorHelp("Use Start PCM", "Use PCM instead of time to set the start position.")]
		[EditorSeparator]
		public bool useStartPCM = false;

		[EditorHelp("Start PCM", "The playback position in PCM samples to start from.")]
		[EditorLimit(0, false)]
		[EditorCondition("useStartPCM", true)]
		public int startPCM = 0;

		[EditorHelp("Start Time (s)", "The time position in seconds to start from.")]
		[EditorEndFoldout]
		[EditorLimit(0.0f, false)]
		[EditorElseCondition]
		[EditorEndCondition()]
		public float startTime = 0;


		// loops
		[EditorFoldout("Loop Settings", "Music clips can loop within themselves.\n" +
			"They check for a certain time position in the track and set the time to " +
			"a defined position when the check position is reached.\n" +
			"Music clips can have multiple loops - if the first loop is finished, the second will be checked, etc..")]
		[EditorEndFoldout]
		[EditorArray("Add Loop", "Adds a loop to this music clip.\n", "",
			"Remove", "Removes this loop from the music clip.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Loop", "Define the where to loop this music clip.", ""
		})]
		public MusicClipLoop[] clipLoop = new MusicClipLoop[0];

		public MusicClipSetting()
		{

		}

		public MusicClipSetting(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}
	}
}
