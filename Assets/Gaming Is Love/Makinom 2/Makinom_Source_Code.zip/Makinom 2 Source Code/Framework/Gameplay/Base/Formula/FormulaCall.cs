
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class FormulaCall : IDataCall
	{
		public float initialValue = 0;

		public float result = 0;

		protected FormulaCall parentCall;

		protected FormulaCall subCall;

		protected FloatOperator subOperator;


		// user
		protected object user;

		protected GameObject userGameObject;


		// target
		protected object target;

		protected GameObject targetGameObject;


		// data
		protected VariableHandler localVariables;

		protected SelectedDataHandler localSelectedData;

		protected int inputID = 0;

		protected FormulaCall(FormulaCall parentCall, float initialValue)
		{
			this.parentCall = parentCall;
			this.initialValue = initialValue;
			this.result = initialValue;

			if(this.parentCall != null)
			{
				this.user = this.parentCall.user;
				this.userGameObject = this.parentCall.userGameObject;
				this.target = this.parentCall.target;
				this.targetGameObject = this.parentCall.targetGameObject;
				this.inputID = this.parentCall.inputID;
			}
		}

		public FormulaCall(float initialValue, object user, object target)
		{
			this.result = initialValue;
			this.initialValue = initialValue;
			this.User = user;
			this.Target = target;
			this.inputID = Maki.Control.InputID;
		}

		public FormulaCall(float initialValue, object user, object target,
			VariableHandler localVariables, SelectedDataHandler localSelectedData)
		{
			this.result = initialValue;
			this.initialValue = initialValue;
			this.User = user;
			this.Target = target;
			this.localVariables = localVariables;
			this.localSelectedData = localSelectedData;
			this.inputID = Maki.Control.InputID;
		}

		public FormulaCall(float initialValue, object user, object target,
			VariableHandler localVariables, SelectedDataHandler localSelectedData, int inputID)
		{
			this.result = initialValue;
			this.initialValue = initialValue;
			this.User = user;
			this.Target = target;
			this.localVariables = localVariables;
			this.localSelectedData = localSelectedData;
			this.inputID = inputID;
		}


		/*
		============================================================================
		User/target
		============================================================================
		*/
		public virtual object User
		{
			get { return this.user; }
			set
			{
				if(this.user != value)
				{
					this.user = value;
					this.userGameObject = ComponentHelper.ToGameObject(value);
				}
			}
		}

		public virtual GameObject UserGameObject
		{
			get { return this.userGameObject; }
		}

		public virtual object Target
		{
			get { return this.target; }
			set
			{
				if(this.target != value)
				{
					this.target = value;
					this.targetGameObject = ComponentHelper.ToGameObject(value);
				}
			}
		}

		public virtual GameObject TargetGameObject
		{
			get { return this.targetGameObject; }
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public virtual int InputID
		{
			get { return this.inputID; }
		}

		public virtual bool HasDebug
		{
			get { return false; }
		}

		public virtual IDebug DebugInfo
		{
			get { return null; }
		}

		public virtual float TimeScale
		{
			get { return Maki.Game.TimeScale; }
		}

		public virtual float DeltaTime
		{
			get { return Maki.Game.DeltaTime; }
		}

		public virtual VariableHandler Variables
		{
			get
			{
				if(this.parentCall == null)
				{
					if(this.localVariables == null)
					{
						this.localVariables = new VariableHandler();
					}
					return this.localVariables;
				}
				else
				{
					return this.parentCall.Variables;
				}
			}
		}

		public virtual SelectedDataHandler SelectedData
		{
			get { return this.parentCall == null ? this.localSelectedData : this.parentCall.SelectedData; }
		}


		/*
		============================================================================
		Sub calculation functions
		============================================================================
		*/
		public virtual FormulaCall Current
		{
			get { return this.subCall != null ? this.subCall.Current : this; }
		}

		public virtual void BeginSubCalculation(FloatOperator formulaOperator, float initialValue)
		{
			this.subOperator = formulaOperator;
			this.subCall = new FormulaCall(this, initialValue);
		}

		public virtual void EndSubCalculation()
		{
			if(this.subCall != null)
			{
				this.subCall.EndSubCalculation();
			}
			if(this.parentCall != null)
			{
				this.parentCall.subOperator.Use(ref this.parentCall.result, this.result);
				this.parentCall.subCall = null;
				this.parentCall.subOperator = null;
				this.parentCall = null;
			}
		}
	}
}
