
using UnityEngine;
using GamingIsLove.Makinom.Formulas;
using GamingIsLove.Makinom.Formulas.Nodes;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class FormulaAsset : MakinomGenericAssetWithType<Formula, FormulaTypeAsset>
	{
		public FormulaAsset()
		{

		}

		public override string DataName
		{
			get { return "Formula"; }
		}
	}

	public class Formula : BaseIndexDataWithType<FormulaTypeAsset, FormulaType>
	{
		// formula setting
		public FormulaSettings setting = new FormulaSettings();

		public Formula()
		{

		}

		public Formula(string n)
		{
			this.setting.name = n;
		}

		public override string EditorName
		{
			get { return this.setting.name; }
			set { this.setting.name = value; }
		}

		public override FormulaTypeAsset TypeAsset
		{
			get { return this.setting.formulaType.StoredAsset; }
		}

		public float Calculate(FormulaCall call)
		{
			this.setting.formulaOperator.Use(ref call.result,
				this.setting.startValue.GetValue(call));
			int currentNode = this.setting.startIndex;

			while(currentNode >= 0 && currentNode < this.setting.node.Length)
			{
				if(this.setting.node[currentNode].IsEnabled)
				{
					currentNode = this.setting.node[currentNode].Calculate(call.Current);
				}
				else
				{
					currentNode = this.setting.node[currentNode].GetNext(0);
				}
			}

			call.EndSubCalculation();

			if(this.setting.useMinValue)
			{
				float min = this.setting.minValue != null ?
					this.setting.minValue.GetValue(call) : 0;
				if(call.result < min)
				{
					call.result = min;
				}
			}
			if(this.setting.useMaxValue)
			{
				float max = this.setting.maxValue != null ?
					this.setting.maxValue.GetValue(call) : 0;
				if(call.result > max)
				{
					call.result = max;
				}
			}

			return call.result;
		}

		public float CalculatePreview(FormulaCall call)
		{
			this.setting.formulaOperator.Use(ref call.result,
				this.setting.startValue.GetValue(call));
			int currentNode = this.setting.startIndex;

			while(currentNode >= 0 && currentNode < this.setting.node.Length)
			{
				if(this.setting.node[currentNode].IsEnabled)
				{
					currentNode = this.setting.node[currentNode].CalculatePreview(call.Current);
				}
				else
				{
					currentNode = this.setting.node[currentNode].GetNext(0);
				}
			}

			call.EndSubCalculation();

			if(this.setting.useMinValue)
			{
				float min = this.setting.minValue != null ?
					this.setting.minValue.GetValue(call) : 0;
				if(call.result < min)
				{
					call.result = min;
				}
			}
			if(this.setting.useMaxValue)
			{
				float max = this.setting.maxValue != null ?
					this.setting.maxValue.GetValue(call) : 0;
				if(call.result > max)
				{
					call.result = max;
				}
			}

			return call.result;
		}
	}
}
