﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IAssetBundleAssetSource
	{
		string AssetName
		{
			get;
			set;
		}

		AssetBundleSettings AssetBundle
		{
			get;
			set;
		}
	}

	[EditorSettingInfo("Asset Bundle", "Uses an asset stored in an asset bundle.\n" +
		"Define the name of the asset, asset bundle and path the asset bundle is stored in.")]
	public class AssetBundleAssetSource<T> : BaseAssetSource<T>, IAssetBundleAssetSource where T : UnityEngine.Object
	{
		[EditorHelp("Asset", "Select the asset that will be used.\n" +
			"The asset has to be assigned to an asset bundle, ORK will fill the 'Asset Name' and " +
			"'Asset Bundle Name' fields with the according information.\n" +
			"The asset isn't saved, but you can use this to find the asset bundle it is part of.", "")]
		[EditorHide]
		[EditorWidth(150, true)]
		public T asset;

		[EditorHelp("Asset Name", "Define the name of the asset in the asset bundle.", "")]
		[EditorIndent]
		[EditorWidth(true)]
		public string assetName = "";

		[EditorIndent]
		public AssetBundleSettings assetBundle = new AssetBundleSettings();

		public AssetBundleAssetSource()
		{

		}

		public override DataObject GetData()
		{
			DataObject data = new DataObject();
			data.Set("assetName", this.assetName);
			data.Set("assetBundle", this.assetBundle.GetData());
			data.Set(DataSerializer.TYPE, this.GetGenericTypeName());
			return data;
		}

		public override T Get()
		{
			return AssetSourceCache.Instance.GetFromAssetBundle<T>(
				this.assetBundle.GetBundlePath(),
				this.assetName,
				this.assetBundle.LoadType);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override bool EditorAfter(bool assetChanged, string assetPath)
		{
			if(assetChanged)
			{
				if(this.asset == null ||
					string.IsNullOrEmpty(assetPath))
				{
					this.asset = null;
					this.assetName = "";
					this.assetBundle.assetBundleName = "";
					return true;
				}
				else
				{
					this.assetName = this.asset.name;
					this.assetBundle.assetBundleName = assetPath;
				}
			}
			return false;
		}

		public override bool EditorHasAssetField
		{
			get { return true; }
		}

		public override Object EditorAsset
		{
			get { return this.asset; }
			set { this.asset = value as T; }
		}

		public override bool HasAsset
		{
			get { return !string.IsNullOrEmpty(this.assetBundle.assetBundleName); }
		}

		public string AssetName
		{
			get { return this.assetName; }
			set { this.assetName = value; }
		}

		public AssetBundleSettings AssetBundle
		{
			get { return this.assetBundle; }
			set { this.assetBundle = value; }
		}

		public override string ToString()
		{
			return this.assetName + " (" + this.assetBundle.assetBundleName + ")";
		}
	}
}
