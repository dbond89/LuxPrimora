﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class PrefabSaverAsset : MakinomGenericAsset<PrefabSaver>
	{
		public PrefabSaverAsset()
		{

		}

		public override string DataName
		{
			get { return "Prefab Saver"; }
		}
	}

	public class PrefabSaver : BaseIndexData
	{
		// base settings
		[EditorHelp("Name", "The name of this prefab saver.", "")]
		[EditorFoldout("Base Settings", "Set the base settings of this game state.", "")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Prefab", "Select the prefab that will be used.\n" +
			"Schematics that use the same prefab can optionally mark a prefab instance to be saved between scenes and in save games.\n" +
			"This is done in the 'Spawn Prefab' node - " +
			"destroying a prefab instance using 'Destroy Prefab' or 'Destroy Object' nodes will remove the instance from saving.", "")]
		[EditorSeparator]
		[EditorEndFoldout]
		public AssetSource<GameObject> prefab = new AssetSource<GameObject>();


		// save settings
		[EditorFoldout("Save Settings", "Define the data that will be saved of spawned prefabs.", "")]
		[EditorEndFoldout]
		public SaveGameObjectSettings saveSettings = new SaveGameObjectSettings();

		public PrefabSaver()
		{

		}

		public PrefabSaver(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}
	}
}
