﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Unblock Player Control", "When the player control is unblocked.")]
	public class UnblockPlayerControlGameStateChangeType : BaseGameStateChangeType
	{
		public UnblockPlayerControlGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Control.UnblockPlayerControlCalled += notify;
		}
	}
}
