
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameStateConditionTemplateAsset : MakinomGenericAsset<GameStateConditionTemplate>
	{
		public GameStateConditionTemplateAsset()
		{

		}

		public override string DataName
		{
			get { return "Game State Condition Template"; }
		}
	}

	public class GameStateConditionTemplate : BaseIndexData
	{
		[EditorHelp("Name", "The name of the game state condition template.", "")]
		[EditorFoldout("Template Settings", "Define the name of this game state condition template.", "")]
		[EditorEndFoldout]
		[EditorWidth(true)]
		public string name = "";

		[EditorFoldout("Game State Condition", "Define the game state conditions of this template.\n" +
			"You can use this template in other game state conditions, e.g. in machine components and nodes.", "")]
		[EditorEndFoldout]
		public GameStateCondition condition = new GameStateCondition();

		public GameStateConditionTemplate()
		{

		}

		public GameStateConditionTemplate(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}

		public bool Check()
		{
			return this.condition.Check();
		}
	}
}
