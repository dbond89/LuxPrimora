
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum InteractionControlType { InteractionController, SelectedObject, BothController, BothSelected }
	public enum InteractionRaycastUse { OnlyHit, InChildren, InParent, InChildrenFirst, InParentFirst, All }

	public class InteractionSetting : BaseData
	{
		[EditorHelp("Interaction Control", "Select how the player can to start interactions:\n" +
			"- Interaction Controller: Interact with objects within the 'Interaction Controller' of the player.\n" +
			"- Selected Object: Interact with objects selected by the player " +
			"(requires a 'Selectable Object' component attached to an object).\n" +
			"- Both Controller: Uses both 'Interaction Controller' and 'Selected Object', prioritizing the 'Interaction Controller'.\n" +
			"- Both Selected: Uses both 'Selected Object' and 'Interaction Controller', prioritizing the 'Selected Object'.", "")]
		public InteractionControlType type = InteractionControlType.InteractionController;

		[EditorHelp("Interact Key", "The key used to interact with objects.", "")]
		public AssetSelection<InputKeyAsset> interactKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Start Cursor Interaction", "The 'Interact Key' will start interactions below the cursor (see 'Cursor Raycast Settings' for layer definitions).\n" +
			"Uses the 'Interact' start type.")]
		[EditorIndent]
		public bool startCursorInteraction = false;

		[EditorHelp("Max Interaction Distance", "The maximum distance in world units to allow " +
			"starting an interaction of start type 'Interact' and 'Key Press'.\n" +
			"Set to -1 to allow interaction without checking the distance.\n" +
			"This setting can be overridden by the individual interactions.", "")]
		[EditorLimit(-1.0f, false)]
		public float maxInteractionDistance = -1;

		[EditorHelp("Max Mouse Distance", "The maximum distance in world units to allow " +
			"starting an interaction by mouse/touch (used by all 'Mouse' start types).\n" +
			"Set to 0 to not allow clicking.\n" +
			"Set to -1 to allow clicking without checking the distance.\n" +
			"This setting can be overridden by the individual interactions.", "")]
		[EditorLimit(-1.0f, false)]
		public float maxMouseDistance = -1;


		// interaction controller
		[EditorFoldout("Interaction Controller Settings", "Define settings for 'Interaction Controller' interaction.", "")]
		[EditorEndFoldout]
		[EditorCondition("type", InteractionControlType.SelectedObject)]
		[EditorElseCondition]
		[EditorEndCondition]
		public InteractionControllerInteractionSetting interactionController = new InteractionControllerInteractionSetting();


		// selected object
		[EditorFoldout("Selected Object Settings", "Define settings for 'Selected Object' interaction.", "")]
		[EditorEndFoldout]
		[EditorCondition("type", InteractionControlType.InteractionController)]
		[EditorElseCondition]
		[EditorEndCondition]
		public SelectedObjectInteractionSetting selectedObject = new SelectedObjectInteractionSetting();


		// raycast HUD
		[EditorHelp("Layer Mask", "Select the layers that will be used by raycasts to find interactions below the cursor.\n" +
			"E.g. used for 'Cursor' interaction sources in HUDs.", "")]
		[EditorFoldout("Cursor Raycast Settings", "Define the raycast settings for finding interactions below the cursor.", "")]
		public LayerMask cusrorLayerMask = -1;

		[EditorHelp("Raycast Distance", "The distance used by the raycast.", "")]
		public float cusrorRaycastDistance = 100;

		[EditorHelp("Find Interaction", "Select how interaction components are found on the hit game object:\n" +
			"- Only Hit: Only on the hit game object.\n" +
			"- In Children: On the hit game object and it's child objects.\n" +
			"- In Parent: On the hit game object and it's parent objects.\n" +
			"- In Children First: First checks 'In Children', of nothing was found, checks 'In Parent'.\n" +
			"- In Parent First: First checks 'In Parent', of nothing was found, checks 'In Children'.\n" +
			"- All: Uses both 'In Children' and 'In Parent'.")]
		public InteractionRaycastUse cursorUse = InteractionRaycastUse.InChildrenFirst;

		[EditorHelp("From Root", "Interactions will be taken from the root game object of the hit game object.", "")]
		[EditorEndFoldout]
		public bool cursorFromRoot = false;


		// line of sight
		[EditorFoldout("Line Of Sight", "Optionally check the line of sight between the player and an interaction.\n" +
			"An interaction will only avaialble when nothing is blocking the line if sight.", "")]
		[EditorEndFoldout]
		public RaycastLineOfSightSetting lineOfSight = new RaycastLineOfSightSetting();


		// move to interaction
		[EditorFoldout("Move To Interaction", "The player can optionally move to an interaction machine " +
			"before starting the interaction.", "")]
		[EditorEndFoldout]
		public MoveToInteractionSettings moveToInteraction = new MoveToInteractionSettings();


		// auto stop interaction
		[EditorFoldout("Auto Stop Interaction", "Automatically stop interactions when the player is a defined distance away from it.\n" +
			"Has to be enabled in individual interaction components to use it.", "")]
		[EditorEndFoldout]
		public AutoStopInteractionSettings autoStopInteraction = new AutoStopInteractionSettings();

		public InteractionSetting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("addIC"))
			{
				this.interactionController.SetData(data);
				this.selectedObject.SetData(data);
			}
		}

		public bool IsInteractionController
		{
			get { return InteractionControlType.InteractionController == this.type; }
		}

		public bool IsSelectedObject
		{
			get { return InteractionControlType.SelectedObject == this.type; }
		}

		public bool IsBothController
		{
			get { return InteractionControlType.BothController == this.type; }
		}

		public bool IsBothSelected
		{
			get { return InteractionControlType.BothSelected == this.type; }
		}
	}
}
