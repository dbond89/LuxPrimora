
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Distance", "The distance between user and target is used.", "")]
	[NodeInfo("Position")]
	public class DistanceNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();


		// distance
		[EditorHelp("Ignore Distance", "The distance along the enabled axes will be ignored, " +
			"e.g. enabling Y will ignore the height difference.", "")]
		[EditorSeparator]
		public AxisBool ignoreDistance = new AxisBool();

		[EditorHelp("Ignore Radius", "The radius of the game objects will be ignored.", "")]
		public bool ignoreRadius = true;

		public DistanceNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			if(call.UserGameObject != null &&
				call.TargetGameObject != null)
			{
				this.formulaOperator.Use(ref call.result,
					VectorHelper.Distance(call.UserGameObject, call.TargetGameObject,
						this.ignoreDistance, this.ignoreRadius));
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Distance", "The distance between user and target is checked with " +
		"the current value of the formula or a defined value.\n" +
		"If the check is true, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckDistanceNode : BaseFormulaCheckNode
	{
		// distance
		[EditorHelp("Ignore Distance", "The distance along the enabled axes will be ignored, " +
			"e.g. enabling Y will ignore the height difference.", "")]
		public AxisBool ignoreDistance = new AxisBool();

		[EditorHelp("Ignore Radius", "The radius of the game objects will be ignored.", "")]
		public bool ignoreRadius = true;


		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckDistanceNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(call.UserGameObject != null && 
				call.TargetGameObject != null && 
				this.check.Check(
					VectorHelper.Distance(call.UserGameObject, call.TargetGameObject, this.ignoreDistance, this.ignoreRadius),
					call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Angle", "The angle between user and target (-180 - 180) is used.", "")]
	[NodeInfo("Position")]
	public class AngleNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();


		// angle
		[EditorSeparator]
		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[EditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		public bool direction = false;

		[EditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[EditorCondition("direction", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool fromTarget = false;

		public AngleNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float value = 0;
			if(call.UserGameObject != null && 
				call.TargetGameObject != null)
			{
				if(this.direction)
				{
					value = VectorHelper.HorizontalDirectionAngle(
						call.UserGameObject.transform, call.TargetGameObject.transform, this.horizontalPlane);
				}
				else if(this.fromTarget)
				{
					value = VectorHelper.HorizontalAngle(
						call.TargetGameObject.transform, call.UserGameObject.transform, this.horizontalPlane);
				}
				else
				{
					value = VectorHelper.HorizontalAngle(
						call.UserGameObject.transform, call.TargetGameObject.transform, this.horizontalPlane);
				}
			}
			this.formulaOperator.Use(ref call.result, value);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator +
				(this.direction ? " Direction" : "") +
				(this.fromTarget ? " from Target" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Angle", "The angle between user and target is checked with " +
		"the current value of the formula or a defined value.\n" +
		"If the check is true, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckAngleNode : BaseFormulaCheckNode
	{
		// angle
		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[EditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		public bool direction = false;

		[EditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[EditorCondition("direction", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool fromTarget = false;


		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckAngleNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			float tmpVal = 0;
			if(call.UserGameObject != null && 
				call.TargetGameObject != null)
			{
				if(this.direction)
				{
					tmpVal = VectorHelper.HorizontalDirectionAngle(
						call.UserGameObject.transform, call.TargetGameObject.transform, this.horizontalPlane);
				}
				else if(this.fromTarget)
				{
					tmpVal = VectorHelper.HorizontalAngle(
						call.TargetGameObject.transform, call.UserGameObject.transform, this.horizontalPlane);
				}
				else
				{
					tmpVal = VectorHelper.HorizontalAngle(
						call.UserGameObject.transform, call.TargetGameObject.transform, this.horizontalPlane);
				}
			}
			if(this.check.Check(tmpVal, call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Orientation", "Checks the orientation from user to target (e.g. if the target is in front of the user).\n" +
		"If the check is true, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckOrientationNode : BaseFormulaCheckNode
	{
		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[EditorHelp("Orientation", "Select the orientation that'll be checked for:\n" +
			"- None: The orientation is ignored.\n" +
			"- Front: The target has to be in front of the user.\n" +
			"- Back: The target has to be in the back of the user.\n" +
			"- Left: The target has to be left of the user.\n" +
			"- Right: The target has to be right of the user.", "")]
		public Orientation orientation = Orientation.Front;

		[EditorHelp("From Target", "The orientation is checked from target to user.\n" +
			"If disabled, the orientation is checked from user to target.", "")]
		public bool fromTarget = false;

		public CheckOrientationNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Orientation check = Orientation.None;
			if(call.UserGameObject != null && 
				call.TargetGameObject != null)
			{
				if(this.fromTarget)
				{
					check = VectorHelper.GetOrientation(
						call.TargetGameObject.transform, call.UserGameObject.transform, this.horizontalPlane);
				}
				else
				{
					check = VectorHelper.GetOrientation(
						call.UserGameObject.transform, call.TargetGameObject.transform, this.horizontalPlane);
				}
			}
			if(Orientation.None == this.orientation ||
				this.orientation == check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.orientation + (this.fromTarget ? ", from Target" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}
	
	[EditorHelp("Check Height Differences", "Checks if the target is above or below the user.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckHeightDifferencesNode : BaseFormulaCheckNode
	{
		public HeightDifferenceCheck heightCheck = new HeightDifferenceCheck();

		public CheckHeightDifferencesNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.heightCheck.Check(call.UserGameObject, call.TargetGameObject))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.heightCheck.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}
}
