﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseTextFileHandler : BaseTypeData
	{
		public abstract void SaveFile(string fileName, string data);

		public abstract string LoadFile(string fileName);

		public abstract void DeleteFile(string fileName);

		public abstract bool FileExists(string fileName);
	}
}
