
using UnityEngine;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class CustomAnimation : BaseData
	{
		// duration for wait in schematics
		[EditorHelp("Duration (s)", "The duration of the animation in seconds.\n" +
			"This value is used in schematics to set the wait time for animation nodes.", "")]
		[EditorLimit(0.0f, false)]
		public float duration = 0;


		// play
		[EditorFoldout("Play Function", "Define the function that will be called when the animation is played.", "")]
		[EditorEndFoldout]
		public CallFunction<GameObjectSelection> playMethod = new CallFunction<GameObjectSelection>();


		// stop
		[EditorFoldout("Stop Function", "Define the function that will be called when the animation is stopped.", "")]
		[EditorEndFoldout]
		public CallFunction<GameObjectSelection> stopMethod = new CallFunction<GameObjectSelection>();

		public CustomAnimation()
		{

		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public AnimInfo Play(DataCall call)
		{
			this.playMethod.Call(call.UserGameObject, call, false);

			return new AnimInfo(AnimationSystem.Custom,
				this.playMethod.className + "." + this.playMethod.functionName,
				this.duration);
		}

		public void Stop(DataCall call)
		{
			this.stopMethod.Call(call.UserGameObject, call, false);
		}
	}
}
