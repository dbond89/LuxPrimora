
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IInputID
	{
		int InputID
		{
			get;
			set;
		}
	}

	public class InputID : BaseData
	{
		[EditorHelp("Override Input ID", "Define an input ID that will be used.\n" +
			"If disabled, the input ID of a provided game object or the global input ID will be used.", "")]
		public bool overrideID = false;

		[EditorHelp("Input ID", "Define the input ID that will be used.\n" +
			"The minimum input ID is 0, the value will be used as an integer (i.e. only whole numbers).", "")]
		[EditorCondition("overrideID", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<GameObjectSelection> inputID;

		public InputID()
		{

		}

		public int GetInputID()
		{
			return this.GetInputID(Maki.Game.Player.GameObject, Maki.Game.Player.GameObject);
		}

		public int GetInputID(object user, object target)
		{
			if(this.overrideID)
			{
				int id = (int)this.inputID.GetValue(this.inputID.NeedsCall ? new DataCall(user, target) : null);
				return id < 0 ? 0 : id;
			}
			else
			{
				IInputID tmpInputID = ComponentHelper.ToInputID(target);
				if(tmpInputID != null)
				{
					return tmpInputID.InputID;
				}
				else
				{
					tmpInputID = ComponentHelper.ToInputID(user);
					if(tmpInputID != null)
					{
						return tmpInputID.InputID;
					}
					else
					{
						return Maki.Control.InputID;
					}
				}
			}
		}
	}
}
