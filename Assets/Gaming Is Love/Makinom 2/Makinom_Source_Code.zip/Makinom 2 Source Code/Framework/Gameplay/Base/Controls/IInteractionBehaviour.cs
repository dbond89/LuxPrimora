﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	// TODO: auto cancel if player is defined distance away from interaction
	// setup in interaction settings (game controls), each interaction has setting to use it
	// optionally only when player can be controlled
	// implement in base interaction and interaction machine > CancelInteraction function in interface for canceling
	public interface IInteractionBehaviour
	{
		/*
		============================================================================
		Properties
		============================================================================
		*/
		bool enabled
		{
			get;
			set;
		}

		bool isActiveAndEnabled
		{
			get;
		}

		GameObject gameObject
		{
			get;
		}

		Transform transform
		{
			get;
		}

		MachineTypeAsset MachineType
		{
			get;
		}
		
		
		/*
		============================================================================
		Condition functions
		============================================================================
		*/
		bool CheckConditions(GameObject startingObject, bool isAutoCheck);


		/*
		============================================================================
		Interact functions
		============================================================================
		*/
		bool IsInteract
		{
			get;
		}

		bool CanInteract(GameObject startingObject);

		bool Interact(GameObject startingObject);

		void StartInteraction(GameObject startingObject);

		void AutoStopInteraction();


		/*
		============================================================================
		Move to interaction functions
		============================================================================
		*/
		float MoveDestinationOffset
		{
			get;
		}

		MoveToInteractionComponentSettings MoveToInteractionSettings
		{
			get;
		}
	}
}
