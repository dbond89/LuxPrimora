﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Screen", "The screen is the origin.")]
	public class ScreenRaycastType<T> : BaseRaycastType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		public FloatValue<T> distance = new FloatValue<T>(100.0f);

		[EditorSeparator]
		[EditorHelp("Use Cursor Position", "Use the current cursor/mouse position as target for the raycast.\n" +
			"Otherwise uses the center of the screen.", "")]
		public bool useCursorPosition = false;

		public ScreenRaycastType()
		{

		}

		public override string ToString()
		{
			return "Screen";
		}

		protected virtual Ray GetRay(IDataCall call, Vector3 originOffset, Camera camera)
		{
			Vector3 tmp = Vector3.zero;
			if(this.useCursorPosition)
			{
				tmp = VectorHelper.GetMousePosition(originOffset);
			}
			else
			{
				tmp = Maki.UISystem.GetScreenCenter() + originOffset;
				tmp = Maki.UI.DefaultScreenMatrix.Matrix.MultiplyPoint3x4(tmp);
				tmp.y = Screen.height - tmp.y;
			}

			return VectorHelper.ScreenToRay(tmp, camera);
		}

		public override RaycastOutput Raycast(IDataCall call, RaycastType raycastType, 
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera)
		{
			Ray ray = this.GetRay(call, originOffset, camera);
			RaycastOutput hit = null;
			if(RaycastHelper.Raycast(raycastType, ray.origin, ray.direction,
				out hit, this.distance.GetValue(call), layerMask, storeCoords))
			{
				return hit;
			}
			return null;
		}

		public override List<RaycastOutput> RaycastAll(IDataCall call, RaycastType raycastType, 
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera)
		{
			Ray ray = this.GetRay(call, originOffset, camera);
			return RaycastHelper.RaycastAll(raycastType,
				ray.origin, ray.direction, this.distance.GetValue(call), layerMask, storeCoords);
		}
	}
}
