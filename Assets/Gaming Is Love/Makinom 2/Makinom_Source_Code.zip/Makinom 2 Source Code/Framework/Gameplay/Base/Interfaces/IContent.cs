
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IContent
	{
		int ID
		{
			get;
		}

		string GetName();

		string GetShortName();

		string GetDescription();

		Sprite GetIconSprite();

		Texture GetIconTexture();

		string GetIconTextCode();

		string GetCustomContent(string contentKey);
	}
}
