﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Start Scene Change", "When starting a scene change (before fading out).")]
	public class StartSceneChangeGameStateChangeType : BaseGameStateChangeType
	{
		public StartSceneChangeGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Control.StartSceneChangeCalled += notify;
		}
	}
}
