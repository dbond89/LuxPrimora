﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Block Camera Control", "When the camera control is blocked.")]
	public class BlockCameraControlGameStateChangeType : BaseGameStateChangeType
	{
		public BlockCameraControlGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Control.BlockCameraControlCalled += notify;
		}
	}
}
