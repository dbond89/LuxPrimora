
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum InteractionSource { InteractionControl, Cursor, InteractionControlFirst, CursorFirst }

	public class InteractionCheck : BaseData
	{
		[EditorHelp("Any Interaction", "Any interaction is available.", "")]
		public bool any = true;

		[EditorHelp("Machine Type", "Select the machine type that will be used.", "")]
		[EditorArray("Add Machine Type", "Adds a machine type that will be available.", "",
			"Remove", "Removes this machine type.", "", isHorizontal=true)]
		[EditorCondition("any", false)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<MachineTypeAsset>[] machineType;

		public InteractionCheck()
		{

		}

		public bool Check()
		{
			if(this.any)
			{
				return Maki.Game.Interactions.Available(null);
			}
			else
			{
				for(int i = 0; i < this.machineType.Length; i++)
				{
					if(Maki.Game.Interactions.Available(this.machineType[i]))
					{
						return true;
					}
				}
				return false;
			}
		}

		public bool Interact(InteractionController ic)
		{
			if(ic != null)
			{
				if(this.any)
				{
					return ic.Interact(null);
				}
				else
				{
					for(int i = 0; i < this.machineType.Length; i++)
					{
						if(ic.Interact(this.machineType[i]))
						{
							return true;
						}
					}
					return false;
				}
			}
			return false;
		}

		public bool IsType(IInteractionBehaviour interaction)
		{
			if(interaction != null)
			{
				if(this.any)
				{
					return true;
				}
				else
				{
					for(int i = 0; i < this.machineType.Length; i++)
					{
						if(this.machineType[i].Is(interaction.MachineType))
						{
							return true;
						}
					}
					return false;
				}
			}
			return false;
		}

		/// <summary>
		/// Gets all interactions in the scene matching the selected machine types.
		/// </summary>
		/// <returns>
		/// The interactions matching the selected machine types.
		/// </returns>
		public List<IInteractionBehaviour> GetAll()
		{
			if(this.any)
			{
				return Maki.Game.Interactions.GetAll();
			}
			else
			{
				List<IInteractionBehaviour> list = new List<IInteractionBehaviour>();
				for(int i = 0; i < this.machineType.Length; i++)
				{
					Maki.Game.Interactions.Get(this.machineType[i], ref list);
				}
				return list;
			}
		}

		public IInteractionBehaviour GetFirst(InteractionSource source)
		{
			IInteractionBehaviour machineComponent = null;
			if(Maki.Game.Interactions != null)
			{
				if(source == InteractionSource.InteractionControl)
				{
					machineComponent = this.GetFirstControl();
				}
				else if(InteractionSource.Cursor == source)
				{
					machineComponent = this.GetFirstCursor(Maki.Game.Player.GameObject);
				}
				else if(InteractionSource.InteractionControlFirst == source)
				{
					machineComponent = this.GetFirstControl();
					if(machineComponent == null)
					{
						machineComponent = this.GetFirstCursor(Maki.Game.Player.GameObject);
					}
				}
				else if(InteractionSource.CursorFirst == source)
				{
					machineComponent = this.GetFirstCursor(Maki.Game.Player.GameObject);
					if(machineComponent == null)
					{
						machineComponent = this.GetFirstControl();
					}
				}
			}
			return machineComponent;
		}

		public IInteractionBehaviour GetFirstControl()
		{
			if(Maki.Game.Interactions != null)
			{
				if(this.any)
				{
					return Maki.Game.Interactions.GetFirstAvailable((MachineTypeAsset)null);
				}
				else
				{
					for(int i = 0; i < this.machineType.Length; i++)
					{
						IInteractionBehaviour firstAvailable = Maki.Game.Interactions.GetFirstAvailable(this.machineType[i]);
						if(firstAvailable != null)
						{
							return firstAvailable;
						}
					}
				}
			}
			return null;
		}

		public IInteractionBehaviour GetFirstCursor(GameObject startingObject)
		{
			if(Maki.Game.Interactions.CursorInteractions.Count > 0)
			{
				List<IInteractionBehaviour> cursorInteractions = Maki.Game.Interactions.CursorInteractions;
				for(int i = 0; i < cursorInteractions.Count; i++)
				{
					if(cursorInteractions[i].enabled &&
						cursorInteractions[i].CanInteract(startingObject) &&
						this.IsType(cursorInteractions[i]) &&
						Maki.GameControls.interaction.lineOfSight.Check(startingObject, cursorInteractions[i].gameObject))
					{
						return cursorInteractions[i];
					}
				}
			}
			return null;
		}
	}
}
