﻿
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class InteractionControllerInteractionSetting : BaseData
	{
		[EditorHelp("Add Automatically", "The interaction controller is automatically added to the player.\n" +
			"If disabled, you need to manually add an interaction controller to the prefab of the player.", "")]
		public bool addIC = false;

		[EditorHelp("IC Prefab", "The prefab used as interaction controller.", "")]
		[EditorCondition("addIC", true)]
		[EditorAutoInit]
		public AssetSource<GameObject> icPrefab;

		[EditorEndCondition]
		[EditorAutoInit]
		public MountSettings icMount;

		public InteractionControllerInteractionSetting()
		{

		}

		public virtual void AddInteractionController(GameObject player)
		{
			if(this.addIC &&
				this.icPrefab.StoredAsset != null &&
				player.GetComponentInChildren<InteractionController>() == null)
			{
				GameObject instance = UnityWrapper.Instantiate(this.icPrefab.StoredAsset);
				if(instance != null)
				{
					this.icMount.MountTo(player.transform, instance.transform);
				}
			}
		}
	}
}
