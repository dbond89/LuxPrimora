
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Vector3 Transform Value", "Transforms a Vector3 value " +
	 	"between local and world space of a game object and stores the result into a variable", "")]
	[NodeInfo("Vector3")]
	public class Vector3TransformValueNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Value")]
		public Vector3Value<FormulaObjectSelection> value = new Vector3Value<FormulaObjectSelection>();


		// used object
		[EditorSeparator]
		[EditorTitleLabel("Object")]
		public FormulaObjectSelection transformObject = new FormulaObjectSelection();


		// transform change
		[EditorHelp("Modify", "Select how the value will be modified:\n" +
			"- None: No change.\n" +
			"- Transform Point: Transforms the value as a position from local to world space.\n" +
			"- Transform Direction: Transforms the value as a direction from local to world space.\n" +
			"- Inverse Transform Point: Transforms the value as a position from world to local space.\n" +
			"- Inverse Transform Direction: Transforms the value as a direction from world to local space.", "")]
		[EditorSeparator]
		public TransformChange transformChange = TransformChange.TransformPoint;

		public Vector3TransformValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			if(TransformChange.None != this.transformChange)
			{
				string tmpKey = this.variable.key.GetValue(call);

				if(this.variable.IsSameObject(this.transformObject))
				{
					List<GameObject> list = this.transformObject.GetObjects(call);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent comp = list[i].GetComponentInChildren<ObjectVariablesComponent>();
							if(comp != null)
							{
								this.variable.ChangeVector3(call, comp.Handler, tmpKey,
									VectorHelper.UseTransformChange(
										this.value.GetValue(call),
										this.transformChange, list[i]),
									this.vector3Operator, this.normalize);
							}
						}
					}
					Maki.Pooling.GameObjectLists.Add(list);
				}
				else
				{
					GameObject gameObject = this.transformObject.GetObject(call);

					if(gameObject != null)
					{
						Vector3 tmpValue = VectorHelper.UseTransformChange(
							this.value.GetValue(call),
							this.transformChange, gameObject);

						List<VariableHandler> handlers = this.variable.GetHandlers(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							this.variable.ChangeVector3(call, handlers[i], tmpKey,
								tmpValue, this.vector3Operator, this.normalize);
						}
						Maki.Pooling.VariableHandlerLists.Add(handlers);
					}
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + ": " +
				this.value.ToString() + " " +
				this.transformObject.ToString() + " " +
				this.transformChange.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Angle", "Uses the angle in degree between two Vector3 to " +
		"change the current formula value or stores it into a float variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3AngleNode : BaseFormulaNode
	{
		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorSeparator]
		[EditorTitleLabel("Variable Settings")]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorSeparator]
		[EditorTitleLabel("From")]
		public Vector3Value<FormulaObjectSelection> fromValue = new Vector3Value<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("To")]
		public Vector3Value<FormulaObjectSelection> toValue = new Vector3Value<FormulaObjectSelection>();

		public Vector3AngleNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = Vector3.Angle(
				this.fromValue.GetValue(call),
				this.toValue.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.fromValue.ToString() + " - " + this.toValue.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Magnitude", "Uses the magnitude (length) or square magnitude (squared length) " +
		"of a Vector3 to change the current formula value or stores it into a float variable..", "")]
	[NodeInfo("Vector3")]
	public class Vector3MagnitudeNode : BaseFormulaNode
	{
		[EditorHelp("Use Square Magnitude", "Use the square magnitude (squared length) " +
			"of the Vector3 instead of the magnitude (length).", "")]
		public bool sqrMagnitude = false;

		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorSeparator]
		[EditorTitleLabel("Variable Settings")]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorSeparator]
		[EditorTitleLabel("Vector3 Value")]
		public Vector3Value<FormulaObjectSelection> value = new Vector3Value<FormulaObjectSelection>();

		public Vector3MagnitudeNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = this.sqrMagnitude ?
				this.value.GetValue(call).sqrMagnitude :
				this.value.GetValue(call).magnitude;

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.value.ToString() + (this.sqrMagnitude ? " squared" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Clamp", "Store a Vector3 with it's " +
		"axes clamped between two values into a variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3ClampNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Vector3 Value")]
		public Vector3Value<FormulaObjectSelection> vector3Value = new Vector3Value<FormulaObjectSelection>();


		// x-axis
		[EditorHelp("Clamp X-Axis", "The X-axis of the Vector3 will be clamped.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Clamp X-Axis")]
		public bool clampX = false;

		[EditorHelp("X-Axis Minimum", "The minimum value the X-axis will have.", "")]
		[EditorSeparator]
		[EditorCondition("clampX", true)]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> xMin;

		[EditorHelp("X-Axis Maximum", "The maximum value the X-axis will have.", "")]
		[EditorSeparator]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> xMax;


		// y-axis
		[EditorHelp("Clamp Y-Axis", "The Y-axis of the Vector3 will be clamped.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Clamp Y-Axis")]
		public bool clampY = false;

		[EditorHelp("Y-Axis Minimum", "The minimum value the Y-axis will have.", "")]
		[EditorSeparator]
		[EditorCondition("clampY", true)]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> yMin;

		[EditorHelp("Y-Axis Maximum", "The maximum value the Y-axis will have.", "")]
		[EditorSeparator]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> yMax;


		// z-axis
		[EditorHelp("Clamp Z-Axis", "The Z-axis of the Vector3 will be clamped.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Clamp Z-Axis")]
		public bool clampZ = false;

		[EditorHelp("Z-Axis Minimum", "The minimum value the Z-axis will have.", "")]
		[EditorSeparator]
		[EditorCondition("clampZ", true)]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> zMin;

		[EditorHelp("Z-Axis Maximum", "The maximum value the Z-axis will have.", "")]
		[EditorSeparator]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> zMax;

		public Vector3ClampNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			Vector3 tmpValue = this.vector3Value.GetValue(call);

			if(this.clampX)
			{
				tmpValue.x = Mathf.Clamp(tmpValue.x,
					this.xMin.GetValue(call),
					this.xMax.GetValue(call));
			}
			if(this.clampY)
			{
				tmpValue.y = Mathf.Clamp(tmpValue.y,
					this.yMin.GetValue(call),
					this.yMax.GetValue(call));
			}
			if(this.clampZ)
			{
				tmpValue.z = Mathf.Clamp(tmpValue.z,
					this.zMin.GetValue(call),
					this.zMax.GetValue(call));
			}

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.vector3Value.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Clamp Magnitude", "Store a Vector3 with it's " +
		"magnitude clamped to a max length into a variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3ClampMagnitudeNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Vector3 Value")]
		public Vector3Value<FormulaObjectSelection> vector3Value = new Vector3Value<FormulaObjectSelection>();

		[EditorHelp("Maximum Length", "The maximum length the magnitude will be clamped to.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Length")]
		public FloatValue<FormulaObjectSelection> maxLength = new FloatValue<FormulaObjectSelection>();

		public Vector3ClampMagnitudeNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			Vector3 tmpValue = Vector3.ClampMagnitude(
				this.vector3Value.GetValue(call),
				this.maxLength.GetValue(call));

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.vector3Value.ToString() + ", " + this.maxLength.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Lerp", "Store the linear or spherical interpolation between two Vector3 into a variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3LerpNode : BaseFormulaNode
	{
		[EditorHelp("Use Slerp", "Use spherical interpolation (i.e. Vector3.Slerp).\n" +
			"If disabled, linear interpolation is used (i.e. Vector3.Lerp).", "")]
		public bool useSlerp = false;


		// variable settings
		[EditorSeparator]
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("From")]
		public Vector3Value<FormulaObjectSelection> fromValue = new Vector3Value<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("To")]
		public Vector3Value<FormulaObjectSelection> toValue = new Vector3Value<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("By Fraction")]
		[EditorHelp("Delta Time", "Multiply the fraction value by Time.deltaTime.", "")]
		public bool deltaTime = false;

		[EditorHelp("Fraction", "The fraction of the interpolation.\n" +
			"Clamped between 0 and 1.", "")]
		public FloatValue<FormulaObjectSelection> fraction = new FloatValue<FormulaObjectSelection>();

		public Vector3LerpNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			Vector3 tmpValue = this.useSlerp ?
				Vector3.Slerp(
				this.fromValue.GetValue(call),
				this.toValue.GetValue(call),
				this.deltaTime ?
					this.fraction.GetValue(call) * Time.deltaTime :
					this.fraction.GetValue(call)) :
				Vector3.Lerp(
				this.fromValue.GetValue(call),
				this.toValue.GetValue(call),
				this.deltaTime ?
					this.fraction.GetValue(call) * Time.deltaTime :
					this.fraction.GetValue(call));

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.fromValue.ToString() + " - " + this.toValue.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Move Towards", "Moves the Vector3 current in a straight line towards a target " +
		"and stores it into a variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3MoveTowardsNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Current")]
		public Vector3Value<FormulaObjectSelection> fromValue = new Vector3Value<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("Target")]
		public Vector3Value<FormulaObjectSelection> toValue = new Vector3Value<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("Max Distance Delta")]
		[EditorHelp("Delta Time", "Multiply the maximum distance delta value by Time.deltaTime.", "")]
		public bool deltaTime = false;

		[EditorHelp("Max Distance Delta", "The maximum distance delta the Vector3 will be moved.", "")]
		public FloatValue<FormulaObjectSelection> maxDistance = new FloatValue<FormulaObjectSelection>();

		public Vector3MoveTowardsNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			Vector3 tmpValue = Vector3.MoveTowards(
				this.fromValue.GetValue(call),
				this.toValue.GetValue(call),
				this.deltaTime ?
					this.maxDistance.GetValue(call) * Time.deltaTime :
					this.maxDistance.GetValue(call));

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.fromValue.ToString() + " - " + this.toValue.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Rotate Towards", "Rotates the Vector3 current towards a target " +
		"and stores it into a variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3RotateTowardsNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Current")]
		public Vector3Value<FormulaObjectSelection> fromValue = new Vector3Value<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("Target")]
		public Vector3Value<FormulaObjectSelection> toValue = new Vector3Value<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("Max Radians Delta")]
		[EditorHelp("Delta Time", "Multiply the maximum radians delta value by Time.deltaTime.", "")]
		public bool deltaTime = false;

		[EditorHelp("Max Radians Delta", "The maximum radians delta used when rotating.", "")]
		public FloatValue<FormulaObjectSelection> maxRadians = new FloatValue<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("Max Magnitude Delta")]
		[EditorHelp("Delta Time", "Multiply the maximum magnitude delta value by Time.deltaTime.", "")]
		public bool deltaTimeMagnitude = false;

		[EditorHelp("Max Magnitude Delta", "The maximum magnitude delta used when rotating.", "")]
		public FloatValue<FormulaObjectSelection> maxMagnitude = new FloatValue<FormulaObjectSelection>();

		public Vector3RotateTowardsNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			Vector3 tmpValue = Vector3.RotateTowards(
				this.fromValue.GetValue(call),
				this.toValue.GetValue(call),
				this.deltaTime ?
					this.maxRadians.GetValue(call) * Time.deltaTime :
					this.maxRadians.GetValue(call),
				this.deltaTimeMagnitude ?
					this.maxMagnitude.GetValue(call) * Time.deltaTime :
					this.maxMagnitude.GetValue(call));

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.fromValue.ToString() + " - " + this.toValue.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Ortho Normalize", "Make two or three Vector3 variables normalized and orthogonal to each other.", "")]
	[NodeInfo("Vector3")]
	public class Vector3OrthoNormalizeNode : BaseFormulaNode
	{
		// normal
		[EditorTitleLabel("Normal")]
		public VariableSet<FormulaObjectSelection> normal = new VariableSet<FormulaObjectSelection>();


		// tangent
		[EditorSeparator]
		[EditorTitleLabel("Tangent")]
		public VariableSet<FormulaObjectSelection> tangent = new VariableSet<FormulaObjectSelection>();


		// binormal
		[EditorHelp("Use Binormal", "Use a binormal Vector3 as well, " +
			"i.e. three Vector3 variables will be used instead of two.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Binormal")]
		public bool useBinormal = false;

		[EditorCondition("useBinormal", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> binormal;

		public Vector3OrthoNormalizeNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.useBinormal)
			{
				string tmpNK = this.normal.key.GetValue(call);
				string tmpTK = this.tangent.key.GetValue(call);
				string tmpBK = this.binormal.key.GetValue(call);

				List<VariableHandler> normalList = this.normal.GetHandlers(call);
				List<VariableHandler> tangentList = this.tangent.GetHandlers(call);
				List<VariableHandler> binormalList = this.binormal.GetHandlers(call);

				for(int i = 0; i < normalList.Count; i++)
				{
					Vector3 tmpNormal = normalList[i].GetVector3(tmpNK);
					for(int j = 0; j < tangentList.Count; j++)
					{
						Vector3 tmpTangent = tangentList[j].GetVector3(tmpTK);
						for(int k = 0; k < binormalList.Count; k++)
						{
							Vector3 tmpBinormal = binormalList[k].GetVector3(tmpBK);
							Vector3.OrthoNormalize(ref tmpNormal, ref tmpTangent, ref tmpBinormal);
							this.binormal.ChangeVector3(call, binormalList[k], tmpBK,
								tmpBinormal, Vector3Operator.Set, false);
						}
						this.tangent.ChangeVector3(call, tangentList[j], tmpTK,
							tmpTangent, Vector3Operator.Set, false);
					}
					this.normal.ChangeVector3(call, normalList[i], tmpNK,
						tmpNormal, Vector3Operator.Set, false);
				}
				Maki.Pooling.VariableHandlerLists.Add(normalList);
				Maki.Pooling.VariableHandlerLists.Add(tangentList);
				Maki.Pooling.VariableHandlerLists.Add(binormalList);
			}
			else
			{
				string tmpNK = this.normal.key.GetValue(call);
				string tmpTK = this.tangent.key.GetValue(call);

				List<VariableHandler> normalList = this.normal.GetHandlers(call);
				List<VariableHandler> tangentList = this.tangent.GetHandlers(call);

				for(int i = 0; i < normalList.Count; i++)
				{
					Vector3 tmpNormal = normalList[i].GetVector3(tmpNK);
					for(int j = 0; j < tangentList.Count; j++)
					{
						Vector3 tmpTangent = tangentList[j].GetVector3(tmpTK);
						Vector3.OrthoNormalize(ref tmpNormal, ref tmpTangent);
						this.tangent.ChangeVector3(call, tangentList[j], tmpTK,
							tmpTangent, Vector3Operator.Set, false);
					}
					this.normal.ChangeVector3(call, normalList[i], tmpNK,
						tmpNormal, Vector3Operator.Set, false);
				}
				Maki.Pooling.VariableHandlerLists.Add(normalList);
				Maki.Pooling.VariableHandlerLists.Add(tangentList);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.normal.ToString() + ", " + this.tangent.ToString() +
				(this.useBinormal ? ", " + this.binormal.ToString() : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Multiply", "Multiplies a Vector3 with a float and stores it into a variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3MultiplyNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Vector3 Value")]
		public Vector3Value<FormulaObjectSelection> vector3Value = new Vector3Value<FormulaObjectSelection>();

		[EditorHelp("Multiply By", "The value the Vector3 will be multiplied with.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Multiply By")]
		public FloatValue<FormulaObjectSelection> floatValue = new FloatValue<FormulaObjectSelection>();

		public Vector3MultiplyNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			Vector3 tmpValue = this.vector3Value.GetValue(call) *
				this.floatValue.GetValue(call);

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.vector3Value.ToString() + " * " + this.floatValue.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Divide", "Divides a Vector3 by a float and stores it into a variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3DivideNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Vector3 Value")]
		public Vector3Value<FormulaObjectSelection> vector3Value = new Vector3Value<FormulaObjectSelection>();

		[EditorHelp("Divide By", "The value the Vector3 will be divided by.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Divide By")]
		public FloatValue<FormulaObjectSelection> floatValue = new FloatValue<FormulaObjectSelection>();

		public Vector3DivideNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			float tmpFloat = this.floatValue.GetValue(call);
			Vector3 tmpValue = tmpFloat != 0 ?
				this.vector3Value.GetValue(call) / tmpFloat :
				this.vector3Value.GetValue(call);

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.vector3Value.ToString() + " / " + this.floatValue.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 Rotate", "Rotates a Vector3 and stores it into a variable.", "")]
	[NodeInfo("Vector3")]
	public class Vector3RotateNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Vector3 Value")]
		public Vector3Value<FormulaObjectSelection> value = new Vector3Value<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("Rotation Value")]
		public Vector3Value<FormulaObjectSelection> rotation = new Vector3Value<FormulaObjectSelection>();

		public Vector3RotateNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			Vector3 tmpValue = Quaternion.Euler(this.rotation.GetValue(call)) *
				this.value.GetValue(call);

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.value.ToString() + ", " + this.rotation.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Vector3 To Angle", "Changes all axes of a Vector3 value into a angles (i.e. between 0 and 360) " +
		"and stores it into a Vector3 variable.\n" +
		"E.g. -90 will become 270, 480 will become 120.", "")]
	[NodeInfo("Vector3")]
	public class Vector3ToAngleNode : BaseFormulaNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public Vector3Operator vector3Operator = new Vector3Operator();

		[EditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;


		// values
		[EditorSeparator]
		[EditorTitleLabel("Value")]
		public Vector3Value<FormulaObjectSelection> value = new Vector3Value<FormulaObjectSelection>();

		public Vector3ToAngleNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.vector3Operator.OldDataUpgrade(data, "vector3Operator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);
			Vector3 tmpValue = this.value.GetValue(call);

			ValueHelper.ToAngle(ref tmpValue.x);
			ValueHelper.ToAngle(ref tmpValue.y);
			ValueHelper.ToAngle(ref tmpValue.z);

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeVector3(call, handlers[i], tmpKey,
					tmpValue, this.vector3Operator, this.normalize);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.vector3Operator.ToString() + " " +
				this.value.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
