﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameStateChangeType : BaseData
	{
		[EditorHelp("State Change Event", "Select the state change event that will be used:")]
		[EditorInfo(settingBaseType=typeof(BaseGameStateChangeType), settingAutoSetup="settings")]
		public string type = typeof(StartGameGameStateChangeType).ToString();

		public BaseGameStateChangeType settings = new StartGameGameStateChangeType();

		public GameStateChangeType()
		{

		}

		public GameStateChangeType(BaseGameStateChangeType type)
		{
			this.settings = type;
			this.type = this.settings.GetType().ToString();
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("settings" == fieldName)
			{
				if(!this.settings.IsType(this.type))
				{
					DataObject data = this.settings.GetData();
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						this.type, typeof(BaseGameStateChangeType));
					if(tmpSettings is BaseGameStateChangeType)
					{
						this.settings = (BaseGameStateChangeType)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new StartGameGameStateChangeType();
						this.settings.SetData(data);
						this.type = this.settings.GetType().ToString();
					}
				}
			}
		}
	}
}
