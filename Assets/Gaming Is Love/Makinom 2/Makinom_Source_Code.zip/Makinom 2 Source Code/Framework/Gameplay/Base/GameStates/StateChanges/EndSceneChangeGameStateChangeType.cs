﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("End Scene Change", "When ending a scene change (after fading in).")]
	public class EndSceneChangeGameStateChangeType : BaseGameStateChangeType
	{
		public EndSceneChangeGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Control.EndSceneChangeCalled += notify;
		}
	}
}
