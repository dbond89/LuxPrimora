﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Start Blocking Machine", "When starting a 'Blocking' execution type machine.")]
	public class StartBlockingMachineGameStateChangeType : BaseGameStateChangeType
	{
		public StartBlockingMachineGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Control.StartBlockingMachineCalled += notify;
		}
	}
}
