﻿
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace GamingIsLove.Makinom
{
	public class GridCellMove
	{
		private GameObjectGrid grid;

		private GridCell cell;

		private GridCell cell2;

		private bool setPosition = true;

		private bool setRotation = true;

		private bool mount = true;

		private bool destroy = true;

		public GridCellMove()
		{

		}

		public GridCellMove(GameObjectGrid grid, GridCell cell, GridCell cell2,
			bool setPosition, bool setRotation, bool mount, bool destroy)
		{
			this.grid = grid;
			this.cell = cell;
			this.cell2 = cell2;
			this.setPosition = setPosition;
			this.setRotation = setRotation;
			this.mount = mount;
			this.destroy = destroy;
		}

		public IEnumerator MoveAfter(float time)
		{
			yield return new WaitForSeconds(time);
			this.Move();
		}

		public void Move()
		{
			if(this.cell2.GameObject != null)
			{
				if(this.destroy)
				{
					UnityWrapper.Destroy(this.cell2.GameObject);
				}
				else if(this.cell2.GameObject.transform.parent == this.grid.GameObject.transform)
				{
					this.cell2.GameObject.transform.SetParent(null);
				}
			}

			this.cell2.GameObject = this.cell.GameObject;
			this.cell.GameObject = null;

			if(this.setPosition && this.setRotation)
			{
				this.cell2.GameObject.transform.SetPositionAndRotation(
					this.grid.GameObject.transform.TransformPoint(this.cell2.Position),
					Quaternion.Euler(this.grid.GameObject.transform.eulerAngles + this.cell2.Rotation));
			}
			else
			{
				if(this.setPosition)
				{
					this.cell2.GameObject.transform.position = this.grid.GameObject.transform.TransformPoint(this.cell2.Position);
				}
				if(this.setRotation)
				{
					this.cell2.GameObject.transform.eulerAngles = this.grid.GameObject.transform.eulerAngles + this.cell2.Rotation;
				}
			}
			if(this.mount)
			{
				this.cell2.GameObject.transform.SetParent(this.grid.GameObject.transform);
			}
		}

		public void Set(float time)
		{
			if(this.cell2.GameObject != null)
			{
				if(this.destroy)
				{
					UnityWrapper.Destroy(this.cell2.GameObject, time);
				}
				else if(this.cell2.GameObject.transform.parent == this.grid.GameObject.transform)
				{
					this.cell2.GameObject.transform.SetParent(null);
				}
			}

			this.cell2.GameObject = this.cell.GameObject;
			this.cell.GameObject = null;
		}
	}
}
