
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Schematics
{
	public class SchematicMecanimParameter : BaseData
	{
		[EditorHelp("Parameter Name", "The name of the parameter.", "")]
		[EditorWidth(true)]
		public StringValue<SchematicObjectSelection> name = new StringValue<SchematicObjectSelection>();

		[EditorHelp("Parameter Type", "Select the type of the value that will be set.", "")]
		public MecanimParameterType type = MecanimParameterType.Bool;


		// bool
		[EditorHelp("Toggle", "Toggle the current bool value.\n" +
			"If disabled, the bool value will be set to the defined value.", "")]
		[EditorCondition("type", MecanimParameterType.Bool)]
		public bool bToggle = false;

		[EditorHelp("Bool Value", "The value the parameter that will be set to.", "")]
		[EditorTitleLabel("Value")]
		[EditorSeparator]
		[EditorCondition("bToggle", false)]
		[EditorEndCondition(2)]
		public BoolValue<SchematicObjectSelection> bVal = new BoolValue<SchematicObjectSelection>();


		// other values
		[EditorHelp("Add", "Add the value to the current value.", "")]
		[EditorCondition("type", MecanimParameterType.Int)]
		[EditorCondition("type", MecanimParameterType.Float)]
		public bool add = false;

		[EditorHelp("Value", "The value the parameter will be set to.", "")]
		[EditorSeparator]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<SchematicObjectSelection> value;


		// trigger
		[EditorHelp("Reset Trigger", "Reset the trigger to false.", "")]
		[EditorCondition("type", MecanimParameterType.Trigger)]
		[EditorEndCondition]
		public bool resetTrigger = false;


		public SchematicMecanimParameter()
		{

		}

		public override string ToString()
		{
			if(MecanimParameterType.Bool == this.type)
			{
				if(this.bToggle)
				{
					return this.name.ToString() + " Toggle";
				}
				else
				{
					return this.name.ToString() + " = " + this.bVal.ToString();
				}
			}
			// set int/float
			else if(MecanimParameterType.Int == this.type ||
				MecanimParameterType.Float == this.type)
			{
				if(this.add)
				{
					return this.name.ToString() + " += " + this.value.ToString();
				}
				else
				{
					return this.name.ToString() + " = " + this.value.ToString();
				}
			}
			// set trigger
			else if(MecanimParameterType.Trigger == this.type)
			{
				return this.name.ToString() + (this.resetTrigger ? " reset" : "");
			}
			return "";
		}


		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public void Set(Animator animator, Schematic schematic)
		{
			string tmpName = this.name.GetValue(schematic);

			// set bool
			if(MecanimParameterType.Bool == this.type)
			{
				if(this.bToggle)
				{
					animator.SetBool(tmpName, !animator.GetBool(tmpName));
				}
				else
				{
					animator.SetBool(tmpName, this.bVal.GetValue(schematic));
				}
			}
			// set int
			else if(MecanimParameterType.Int == this.type)
			{
				if(this.add)
				{
					animator.SetInteger(tmpName,
						animator.GetInteger(tmpName) + (int)this.value.GetValue(schematic));
				}
				else
				{
					animator.SetInteger(tmpName,
						(int)this.value.GetValue(schematic));
				}
			}
			// set float
			else if(MecanimParameterType.Float == this.type)
			{
				if(this.add)
				{
					animator.SetFloat(tmpName,
						animator.GetFloat(tmpName) + this.value.GetValue(schematic));
				}
				else
				{
					animator.SetFloat(tmpName,
						this.value.GetValue(schematic));
				}
			}
			// set trigger
			else if(MecanimParameterType.Trigger == this.type)
			{
				if(this.resetTrigger)
				{
					animator.ResetTrigger(tmpName);
				}
				else
				{
					animator.SetTrigger(tmpName);
				}
			}
		}
	}
}
