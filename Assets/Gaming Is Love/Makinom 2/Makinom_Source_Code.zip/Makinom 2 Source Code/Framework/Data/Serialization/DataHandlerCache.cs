﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class DataHandlerCache
	{
		public DataHandlerCache()
		{

		}

		private EditorSettings editorSettings;
		public EditorSettings EditorSettings
		{
			get
			{
				if(this.editorSettings == null)
				{
					this.editorSettings = Maki.Data.Get<EditorSettings>();
				}
				return this.editorSettings;
			}
		}

		private BackupSettings backups;
		public BackupSettings Backups
		{
			get
			{
				if(this.backups == null)
				{
					this.backups = Maki.Data.Get<BackupSettings>();
				}
				return this.backups;
			}
		}

		private PluginsSettings plugins;
		public PluginsSettings Plugins
		{
			get
			{
				if(this.plugins == null)
				{
					this.plugins = Maki.Data.Get<PluginsSettings>();
				}
				return this.plugins;
			}
		}

		private GameStatesSettings gameStates;
		public GameStatesSettings GameStates
		{
			get
			{
				if(this.gameStates == null)
				{
					this.gameStates = Maki.Data.Get<GameStatesSettings>();
				}
				return this.gameStates;
			}
		}

		private LanguagesSettings languages;
		public LanguagesSettings Languages
		{
			get
			{
				if(this.languages == null)
				{
					this.languages = Maki.Data.Get<LanguagesSettings>();
				}
				return this.languages;
			}
		}

		private InputKeysSettings inputKeys;
		public InputKeysSettings InputKeys
		{
			get
			{
				if(this.inputKeys == null)
				{
					this.inputKeys = Maki.Data.Get<InputKeysSettings>();
				}
				return this.inputKeys;
			}
		}

		private GameSettings gameSettings;
		public GameSettings GameSettings
		{
			get
			{
				if(this.gameSettings == null)
				{
					this.gameSettings = Maki.Data.Get<GameSettings>();
				}
				return this.gameSettings;
			}
		}

		private GameControlsSettings gameControls;
		public GameControlsSettings GameControls
		{
			get
			{
				if(this.gameControls == null)
				{
					this.gameControls = Maki.Data.Get<GameControlsSettings>();
				}
				return this.gameControls;
			}
		}

		private MusicClipsSettings musicClips;
		public MusicClipsSettings MusicClips
		{
			get
			{
				if(this.musicClips == null)
				{
					this.musicClips = Maki.Data.Get<MusicClipsSettings>();
				}
				return this.musicClips;
			}
		}

		private GlobalMachinesSettings globalMachines;
		public GlobalMachinesSettings GlobalMachines
		{
			get
			{
				if(this.globalMachines == null)
				{
					this.globalMachines = Maki.Data.Get<GlobalMachinesSettings>();
				}
				return this.globalMachines;
			}
		}

		private PrefabSaversSettings prefabSavers;
		public PrefabSaversSettings PrefabSavers
		{
			get
			{
				if(this.prefabSavers == null)
				{
					this.prefabSavers = Maki.Data.Get<PrefabSaversSettings>();
				}
				return this.prefabSavers;
			}
		}

		private SceneConnectionsSettings sceneConnections;
		public SceneConnectionsSettings SceneConnections
		{
			get
			{
				if(this.sceneConnections == null)
				{
					this.sceneConnections = Maki.Data.Get<SceneConnectionsSettings>();
				}
				return this.sceneConnections;
			}
		}

		private UILayersSettings uiLayers;
		public UILayersSettings UILayers
		{
			get
			{
				if(this.uiLayers == null)
				{
					this.uiLayers = Maki.Data.Get<UILayersSettings>();
				}
				return this.uiLayers;
			}
		}

		private UILayoutsSettings uiLayouts;
		public UILayoutsSettings UILayouts
		{
			get
			{
				if(this.uiLayouts == null)
				{
					this.uiLayouts = Maki.Data.Get<UILayoutsSettings>();
				}
				return this.uiLayouts;
			}
		}

		private UIBoxesSettings uiBoxes;
		public UIBoxesSettings UIBoxes
		{
			get
			{
				if(this.uiBoxes == null)
				{
					this.uiBoxes = Maki.Data.Get<UIBoxesSettings>();
				}
				return this.uiBoxes;
			}
		}

		private SaveGameSettings saveGameSettings;
		public SaveGameSettings SaveGameSettings
		{
			get
			{
				if(this.saveGameSettings == null)
				{
					this.saveGameSettings = Maki.Data.Get<SaveGameSettings>();
				}
				return this.saveGameSettings;
			}
		}

		private UISystemSettings uiSystem;
		public UISystemSettings UISystem
		{
			get
			{
				if(this.uiSystem == null)
				{
					this.uiSystem = Maki.Data.Get<UISystemSettings>();
				}
				return this.uiSystem;
			}
		}

		private UISettings uiSettings;
		public UISettings UISettings
		{
			get
			{
				if(this.uiSettings == null)
				{
					this.uiSettings = Maki.Data.Get<UISettings>();
				}
				return this.uiSettings;
			}
		}

		private TextCodeSettings textCodes;
		public TextCodeSettings TextCodes
		{
			get
			{
				if(this.textCodes == null)
				{
					this.textCodes = Maki.Data.Get<TextCodeSettings>();
				}
				return this.textCodes;
			}
		}

		private HUDsSettings huds;
		public HUDsSettings HUDs
		{
			get
			{
				if(this.huds == null)
				{
					this.huds = Maki.Data.Get<HUDsSettings>();
				}
				return this.huds;
			}
		}
	}
}
