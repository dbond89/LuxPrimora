﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseIndexDataWithType<T, V> : BaseIndexData, ITypeAsset<T>, ITypeData<V> where T : MakinomGenericAsset<V> where V : BaseIndexData, new()
	{
		public BaseIndexDataWithType()
		{

		}

		public BaseIndexDataWithType(string name) : base(name)
		{

		}

		public virtual T TypeAsset
		{
			get;
		}

		public virtual bool HasType
		{
			get { return this.TypeAsset != null; }
		}

		public virtual V TypeData
		{
			get { return this.TypeAsset != null ? this.TypeAsset.Settings : null; }
		}

		public override string GetEditorPopupName(bool addType)
		{
			if(addType &&
				this.TypeData != null)
			{
				return this.ID + ": " + this.EditorName +
					"\n<i>" + this.TypeData.EditorName + "</i>";
			}
			return this.ID + ": " + this.EditorName;
		}
	}
}
