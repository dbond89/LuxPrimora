
using UnityEngine;
using System.Collections.Generic;
using System;

namespace GamingIsLove.Makinom
{
	public abstract class BaseLanguageData : BaseIndexData, IContent
	{
		[EditorHide]
		public LanguageData<ContentInformation> languageContent = new LanguageData<ContentInformation>();

		[EditorFoldout("Custom Content", "Custom content information can be displayed via text codes.",
			initialState = false)]
		[EditorEndFoldout]
		[EditorArray("Add Custom Content", "Adds a custom content information.", "",
			"Remove", "Removes this custom content", "",
			isCopy = true, isMove = true, foldout = true, foldoutText = new string[]
			{
				"Custom Content", "Custom content can be displayed via text codes using the content key.", ""
			})]
		[EditorHide]
		public CustomContentInformation[] customContent = new CustomContentInformation[0];

		[EditorHelp("Editor Name", "Optionally define a name that'll be displayed in the editor.\n" +
			"This name will be used in popup fields and searches." +
			"Leave this empty to show the default language name.")]
		[EditorHide]
		[EditorWidth(true)]
		public string editorName = "";

		public BaseLanguageData()
		{

		}

		public BaseLanguageData(string name) : base(name)
		{
			this.languageContent.data = new ContentInformation(name);
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public override string EditorName
		{
			get { return this.editorName != "" ? this.editorName : this.languageContent.data.name.text; }
			set
			{
				this.editorName = "";
				this.languageContent.data.name = new TextContent(value);
			}
		}

		public override string DataName
		{
			get { return this.languageContent.data.name.text; }
		}

		public virtual string GetName()
		{
			return this.languageContent.Current.name;
		}

		public virtual string GetShortName()
		{
			return this.languageContent.Current.ShortName;
		}

		public virtual string GetDescription()
		{
			return this.languageContent.Current.description;
		}

		public virtual Sprite GetIconSprite()
		{
			return this.languageContent.Current.icon.image.sprite;
		}

		public virtual Texture GetIconTexture()
		{
			return this.languageContent.Current.icon.image.texture;
		}

		public virtual string GetIconTextCode()
		{
			return this.languageContent.Current.icon.textCode;
		}

		public virtual string GetCustomContent(string contentKey)
		{
			for(int i = 0; i < this.customContent.Length; i++)
			{
				if(this.customContent[i].contentKey == contentKey)
				{
					return this.customContent[i].content.Current;
				}
			}
			return "";
		}
	}
}
