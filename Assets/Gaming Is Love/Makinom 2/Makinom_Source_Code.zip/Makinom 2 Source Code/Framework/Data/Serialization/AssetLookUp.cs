
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.Serializable]
	public class AssetLookUp
	{
		/*
		============================================================================
		INFO: No null checks when adding assets to lists to prevent issues with Unity serialization
		============================================================================
		*/
		[SerializeField]
		[HideInInspector]
		private List<UnityEngine.Object> assets = new List<UnityEngine.Object>();

		public AssetLookUp()
		{

		}

		public bool CompareTo(AssetLookUp lookUp)
		{
			if(this.assets.Count == lookUp.assets.Count)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i] != lookUp.assets[i])
					{
						return false;
					}
				}
				return true;
			}
			else
			{
				return false;
			}
		}


		/*
		============================================================================
		General Asset functions
		============================================================================
		*/
		public int AddAsset(UnityEngine.Object asset)
		{
			this.assets.Add(asset);
			return this.assets.Count - 1;
		}

		public UnityEngine.Object GetAsset(int index)
		{
			if(index >= 0 && index < this.assets.Count)
			{
				return this.assets[index];
			}
			return null;
		}
	}
}
