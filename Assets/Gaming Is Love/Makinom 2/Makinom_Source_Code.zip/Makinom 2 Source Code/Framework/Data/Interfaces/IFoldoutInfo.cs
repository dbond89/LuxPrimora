﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IFoldoutInfo
	{
		string GetFoldoutInfo();
	}
}
