﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom
{
	public class UILayoutsSettings : GenericAssetListSettings<UILayoutAsset, UILayoutSetting>
	{
		public UILayoutsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "UI Layouts"; }
		}


		/*
		============================================================================
		Layout functions
		============================================================================
		*/
		public void Clear()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				this.assets[i].Settings.Clear();
			}
		}

		public void CreateLayouts()
		{
			Rect bounds = new Rect(Vector2.zero, Maki.UISystem.defaultScreen);
			for(int i = 0; i < this.assets.Count; i++)
			{
				this.assets[i].Settings.CreateInstance(bounds);
			}
		}
	}
}

