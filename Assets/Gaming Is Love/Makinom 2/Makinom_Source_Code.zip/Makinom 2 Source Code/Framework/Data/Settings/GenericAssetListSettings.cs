﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class GenericAssetListSettings<T, V> : BaseSettings where T : MakinomGenericAsset<V> where V : BaseIndexData, new()
	{
		// asset reference
		protected List<T> assets = new List<T>();

		protected Dictionary<string, T> guidLookup = new Dictionary<string, T>();

		public override System.Type InstanceType
		{
			get { return typeof(T); }
		}

		public virtual void SetAssets(List<T> data)
		{
			this.assets = data;
		}

		public virtual void AddAsset(T asset)
		{
			asset.Index = this.assets.Count;
			this.assets.Add(asset);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			DataObject[] assetData = data.GetFileArray("assets");
			if(assetData != null)
			{
				this.assets.Clear();
				for(int i = 0; i < assetData.Length; i++)
				{
					UnityEngine.Object tmpAsset = null;
					assetData[i].GetAsset("asset", ref tmpAsset);
					T asset = tmpAsset as T;
					if(asset != null)
					{
						if(Application.isPlaying)
						{
							asset.LoadData();
						}
						this.assets.Add(asset);
					}
				}
			}
		}

		public override DataObject GetData()
		{
			DataObject data = base.GetData();

			DataObject[] assetData = new DataObject[this.assets.Count];
			for(int i = 0; i < assetData.Length; i++)
			{
				assetData[i] = new DataObject();
				assetData[i].SetAsset("asset", (UnityEngine.Object)this.assets[i]);
			}
			data.Set("assets", assetData);

			return data;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override int Count
		{
			get { return this.assets.Count; }
		}


		/*
		============================================================================
		GUID functions
		============================================================================
		*/
		public virtual void CreateGUIDLookup()
		{
			this.guidLookup.Clear();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					while(this.guidLookup.ContainsKey(this.assets[i].Settings.GUID))
					{
						this.assets[i].Settings.GenerateGUID();
					}
					this.guidLookup.Add(this.assets[i].Settings.GUID, this.assets[i]);
				}
			}
		}

		public virtual string IndexToGUID(int index)
		{
			if(index >= 0 &&
				index < this.assets.Count &&
				this.assets[index] != null)
			{
				return this.assets[index].Settings.GUID;
			}
			return "";
		}

		public virtual int GUIDToIndex(string guid)
		{
			T asset;
			if(this.guidLookup.TryGetValue(guid, out asset))
			{
				if(asset != null)
				{
					return asset.Index;
				}
			}
			return -1;
		}

		public V Get(string guid)
		{
			T asset;
			if(this.guidLookup.TryGetValue(guid, out asset))
			{
				if(asset != null)
				{
					return asset.Settings;
				}
			}
			return null;
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public V Get(int index)
		{
			if(index >= 0 &&
				index < this.assets.Count &&
				this.assets[index] != null)
			{
				return this.assets[index].Settings;
			}
			return null;
		}

		public T GetAsset(int index)
		{
			if(index >= 0 &&
				index < this.assets.Count &&
				this.assets[index] != null)
			{
				return this.assets[index];
			}
			return null;
		}

		public T Find(string name)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings != null &&
					this.assets[i].Settings.EditorName == name)
				{
					return this.assets[i];
				}
			}
			return null;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual List<string> GetNames()
		{
			List<string> list = new List<string>();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings != null)
				{
					list.Add(this.assets[i].Settings.EditorName);
				}
			}
			return list;
		}
	}
}
