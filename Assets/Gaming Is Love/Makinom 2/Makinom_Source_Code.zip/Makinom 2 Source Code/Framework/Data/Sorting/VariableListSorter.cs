
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class StringVariableListSorter : IComparer<string>
	{
		private bool invert = false;

		public StringVariableListSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(string x, string y)
		{
			return this.invert ? y.CompareTo(x) : x.CompareTo(y);
		}
	}

	public class BoolVariableListSorter : IComparer<bool>
	{
		private bool invert = false;

		public BoolVariableListSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(bool x, bool y)
		{
			return this.invert ? y.CompareTo(x) : x.CompareTo(y);
		}
	}

	public class IntVariableListSorter : IComparer<int>
	{
		private bool invert = false;

		public IntVariableListSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(int x, int y)
		{
			return this.invert ? y.CompareTo(x) : x.CompareTo(y);
		}
	}

	public class FloatVariableListSorter : IComparer<float>
	{
		private bool invert = false;

		public FloatVariableListSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(float x, float y)
		{
			return this.invert ? y.CompareTo(x) : x.CompareTo(y);
		}
	}

	public class Vector3VariableListSorter : IComparer<Vector3>
	{
		private bool invert = false;

		private Vector3ListSortType sortType = Vector3ListSortType.XYZ;

		public Vector3VariableListSorter(bool invert, Vector3ListSortType sortType)
		{
			this.invert = invert;
			this.sortType = sortType;
		}

		public int Compare(Vector3 a, Vector3 b)
		{
			if(Vector3ListSortType.SquareMagnitude == this.sortType)
			{
				return this.invert ?
					b.sqrMagnitude.CompareTo(a.sqrMagnitude) :
					a.sqrMagnitude.CompareTo(b.sqrMagnitude);
			}
			else
			{
				int x = this.invert ? b.x.CompareTo(a.x) : a.x.CompareTo(b.x);
				int y = this.invert ? b.y.CompareTo(a.y) : a.y.CompareTo(b.y);
				int z = this.invert ? b.z.CompareTo(a.z) : a.z.CompareTo(b.z);

				if(Vector3ListSortType.XYZ == this.sortType)
				{
					return x != 0 ? x : (y != 0 ? y : z);
				}
				else if(Vector3ListSortType.XZY == this.sortType)
				{
					return x != 0 ? x : (z != 0 ? z : y);
				}
				else if(Vector3ListSortType.YXZ == this.sortType)
				{
					return y != 0 ? y : (x != 0 ? x : z);
				}
				else if(Vector3ListSortType.YZX == this.sortType)
				{
					return y != 0 ? y : (z != 0 ? z : x);
				}
				else if(Vector3ListSortType.ZXY == this.sortType)
				{
					return z != 0 ? z : (x != 0 ? x : y);
				}
				else if(Vector3ListSortType.ZYX == this.sortType)
				{
					return z != 0 ? z : (y != 0 ? y : x);
				}
				return 0;
			}
		}
	}
}
