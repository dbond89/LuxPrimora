﻿
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class InteractionDistanceSorter : IComparer<IInteractionBehaviour>
	{
		private InteractionController controller;

		private Vector3 position;

		public InteractionDistanceSorter(InteractionController controller)
		{
			this.controller = controller;
			this.UpdatePosition();
		}

		public void UpdatePosition()
		{
			this.position = this.controller.transform.TransformPoint(this.controller.settings.positionOffset);
		}

		public int Compare(IInteractionBehaviour x, IInteractionBehaviour y)
		{
			if(x != null && y != null)
			{
				return VectorHelper.Distance(this.position, x.transform.position,
						this.controller.settings.ignoreDistance).CompareTo(
					VectorHelper.Distance(this.position, y.transform.position,
						this.controller.settings.ignoreDistance));
			}
			return 0;
		}
	}

	public class InteractionControllerPrioritySorter : IComparer<InteractionController>
	{
		public InteractionControllerPrioritySorter()
		{

		}

		public int Compare(InteractionController x, InteractionController y)
		{
			if(x != null && y != null)
			{
				return y.settings.priority.CompareTo(x.settings.priority);
			}
			return 0;
		}
	}
}
