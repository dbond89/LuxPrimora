
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Schematics
{
	public class MachinePrioritySorter : IComparer<Schematic>
	{
		public int Compare(Schematic x, Schematic y)
		{
			return y.Priority.CompareTo(x.Priority);
		}
	}
}
