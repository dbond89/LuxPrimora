﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorFoldoutAttribute : System.Attribute
	{
		public GUIContent content;

		public string info;

		// index:
		// 0 = name
		// 1 = text
		// 2 = info
		public string[] subFoldouts;

		public bool initialState = true;

		public EditorFoldoutAttribute(string name, string text) : this(name, text, "")
		{
			this.content = new GUIContent(name, text);
			this.info = "";
		}

		public EditorFoldoutAttribute(string name, string text, string info)
		{
			this.content = new GUIContent(name, text);
			this.info = info;
		}

		public EditorFoldoutAttribute(string name, string text, string info, params string[] subFoldouts)
		{
			this.content = new GUIContent(name, text);
			this.info = info;
			this.subFoldouts = subFoldouts;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorEndFoldoutAttribute : System.Attribute
	{
		public int count = 1;

		public EditorEndFoldoutAttribute()
		{

		}

		public EditorEndFoldoutAttribute(int count)
		{
			this.count = count;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorSeparatorAttribute : System.Attribute
	{
		public int count = 1;

		public EditorSeparatorAttribute()
		{

		}

		public EditorSeparatorAttribute(int count)
		{
			this.count = count;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorIndentAttribute : System.Attribute
	{
		public int count = 1;

		public EditorIndentAttribute()
		{

		}

		public EditorIndentAttribute(int count)
		{
			this.count = count;
		}
	}
}
