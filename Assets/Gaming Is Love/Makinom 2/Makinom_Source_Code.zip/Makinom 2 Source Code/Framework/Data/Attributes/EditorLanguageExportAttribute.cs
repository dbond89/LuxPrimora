﻿
namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.All, AllowMultiple = false)]
	public class EditorLanguageExportAttribute : System.Attribute
	{
		public string info = "";

		public EditorLanguageExportAttribute()
		{

		}

		public EditorLanguageExportAttribute(string info)
		{
			this.info = info;
		}
	}
}
