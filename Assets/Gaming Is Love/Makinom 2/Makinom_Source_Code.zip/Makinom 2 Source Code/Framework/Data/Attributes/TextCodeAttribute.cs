﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false)]
	public class TextCodeAttribute : System.Attribute
	{
		public System.Type assetType;

		public string name;

		public string baseTextCode;

		public string[] textCodes;

		public string[] options;

		public int[] customContentOption = new int[] { 4, 9 };

		public int[] subContentOption = new int[0];

		public TextCodeAttribute(System.Type assetType, string name, string baseTextCode,
			string[] textCodes, string[] options)
		{
			this.assetType = assetType;
			this.name = name;
			this.baseTextCode = baseTextCode;
			this.textCodes = textCodes;
			this.options = options;
		}

		public bool IsCustomContent(int index)
		{
			for(int i = 0; i < this.customContentOption.Length; i++)
			{
				if(this.customContentOption[i] == index)
				{
					return true;
				}
			}
			return false;
		}

		public bool IsSubContent(int index)
		{
			for(int i = 0; i < this.subContentOption.Length; i++)
			{
				if(this.subContentOption[i] == index)
				{
					return true;
				}
			}
			return false;
		}

		public class Sorter : IComparer<TextCodeAttribute>
		{
			public int Compare(TextCodeAttribute x, TextCodeAttribute y)
			{
				return x.name.CompareTo(y.name);
			}
		}
	}
}
