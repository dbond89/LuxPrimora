﻿
using UnityEngine;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.All, AllowMultiple = false)]
	public class EditorNameAttribute : System.Attribute
	{
		public string name = "";

		public EditorNameAttribute()
		{

		}

		public EditorNameAttribute(string name)
		{
			this.name = name;
		}
	}
}
