
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MakinomEditorAsset : ScriptableObject
	{
		// last project
		[HideInInspector]
		[SerializeField]
		private MakinomProjectAsset lastProject = null;

		[HideInInspector]
		[SerializeField]
		private DataFile.SaveFormatType lastSaveFormat = DataFile.SaveFormatType.ByteArray;

		[HideInInspector]
		[SerializeField]
		private bool lastEncrypted = false;


		// editor language
		[HideInInspector]
		[SerializeField]
		private TextAsset editorHelpLanguageTexts = null;


		// section
		[HideInInspector]
		[SerializeField]
		private int section = 0;

		[HideInInspector]
		[SerializeField]
		private int subSection = 0;

		[HideInInspector]
		[SerializeField]
		private int tabIndex = 0;

		[HideInInspector]
		[SerializeField]
		private float scrollY = 0;

		[HideInInspector]
		[SerializeField]
		private string foldoutLimit = "";


		// drags
		[HideInInspector]
		[SerializeField]
		private float helpDrag = 220;

		[HideInInspector]
		[SerializeField]
		private float subSectionDrag = 250;

		[HideInInspector]
		[SerializeField]
		private float tabListDrag = 250;

		[HideInInspector]
		[SerializeField]
		private float formulaDrag = 250;

		[HideInInspector]
		[SerializeField]
		private float schematicDrag = 400;

		[HideInInspector]
		[SerializeField]
		private float jumpListDrag = 250;


		// options
		[HideInInspector]
		[SerializeField]
		private int dataSelectionSorting = 0;

		[HideInInspector]
		[SerializeField]
		private int typeDataSelectionSorting = 0;


		// save options
		[HideInInspector]
		[SerializeField]
		private bool createBackup = true;

		[HideInInspector]
		[SerializeField]
		private bool updateSchematics = true;

		[HideInInspector]
		[SerializeField]
		private string schematicUpdateFolder = "";

		[HideInInspector]
		[SerializeField]
		private bool updatePrefabs = false;

		[HideInInspector]
		[SerializeField]
		private bool updateScenes = false;

		[HideInInspector]
		[SerializeField]
		private bool[] sceneUpdate = new bool[0];


		// schematics
		[HideInInspector]
		[SerializeField]
		private MakinomSchematicAsset[] schematicAsset = new MakinomSchematicAsset[0];

		[HideInInspector]
		[SerializeField]
		private DataFile dialogueImportSettings;

		// remember between play mode changes
		private MakinomSchematicAsset rememberSchematicAsset = null;

		private Vector2 rememberSchematicScroll = Vector2.zero;

		private Vector2 rememberSchematicZoomOffset = Vector2.zero;

		private int rememberSchematicFocusedNode = -1;


		// variables
		[HideInInspector]
		[SerializeField]
		private List<string> variablesDefined = new List<string>();

		[HideInInspector]
		[SerializeField]
		private List<string> variablesEditor = new List<string>();

		[HideInInspector]
		[SerializeField]
		private List<string> variablesSchematic = new List<string>();

		[HideInInspector]
		[SerializeField]
		private List<SceneVariables> variablesScene = new List<SceneVariables>();

		[HideInInspector]
		[SerializeField]
		private List<string> variablesPrefab = new List<string>();


		// foldout states
		[HideInInspector]
		[SerializeField]
		private List<string> foldoutKeys = new List<string>();

		[HideInInspector]
		[SerializeField]
		private List<MakinomEditorAsset.FoldoutState> foldoutStates = new List<MakinomEditorAsset.FoldoutState>();


		// popup favorites
		[HideInInspector]
		[SerializeField]
		private List<string> popupFavorites = new List<string>();

		private HashSet<string> popupFavoritesHash = null;

		public MakinomEditorAsset()
		{

		}


		/*
		============================================================================
		Project functions
		============================================================================
		*/
		public MakinomProjectAsset LastProject
		{
			get { return this.lastProject; }
			set { this.lastProject = value; }
		}

		public DataFile.SaveFormatType LastSaveFormat
		{
			get { return this.lastSaveFormat; }
			set { this.lastSaveFormat = value; }
		}

		public bool LastEncrypted
		{
			get { return this.lastEncrypted; }
			set { this.lastEncrypted = value; }
		}

		public TextAsset EditorHelpLanguageTexts
		{
			get { return this.editorHelpLanguageTexts; }
			set { this.editorHelpLanguageTexts = value; }
		}

		public void ResetSections()
		{
			this.section = 0;
			this.subSection = 0;
			this.tabIndex = 0;
			this.scrollY = 0;
			this.foldoutLimit = "";
		}

		public int Section
		{
			get { return this.section; }
			set { this.section = value; }
		}

		public int SubSection
		{
			get { return this.subSection; }
			set { this.subSection = value; }
		}

		public int TabIndex
		{
			get { return this.tabIndex; }
			set { this.tabIndex = value; }
		}

		public float ScrollY
		{
			get { return this.scrollY; }
			set { this.scrollY = value; }
		}

		public string FoldoutLimit
		{
			get { return this.foldoutLimit; }
			set { this.foldoutLimit = value; }
		}

		public int DataSelectionSorting
		{
			get { return this.dataSelectionSorting; }
			set { this.dataSelectionSorting = value; }
		}

		public int TypeDataSelectionSorting
		{
			get { return this.typeDataSelectionSorting; }
			set { this.typeDataSelectionSorting = value; }
		}

		public List<string> FoldoutKeys
		{
			get { return this.foldoutKeys; }
			set { this.foldoutKeys = value; }
		}

		public List<MakinomEditorAsset.FoldoutState> FoldoutStates
		{
			get { return this.foldoutStates; }
			set { this.foldoutStates = value; }
		}

		public void ResetFoldoutStates()
		{
			this.foldoutKeys = null;
			this.foldoutStates = null;
		}


		/*
		============================================================================
		Drag functions
		============================================================================
		*/
		public void ResetDrags()
		{
			this.helpDrag = 220;
			this.subSectionDrag = 250;
			this.tabListDrag = 250;
			this.formulaDrag = 250;
			this.schematicDrag = 400;
		}

		public float HelpDrag
		{
			get { return this.helpDrag; }
			set { this.helpDrag = value; }
		}

		public float SubSectionDrag
		{
			get { return this.subSectionDrag; }
			set { this.subSectionDrag = value; }
		}

		public float TabListDrag
		{
			get { return this.tabListDrag; }
			set { this.tabListDrag = value; }
		}

		public float FormulaDrag
		{
			get { return this.formulaDrag; }
			set { this.formulaDrag = value; }
		}

		public float SchematicDrag
		{
			get { return this.schematicDrag; }
			set { this.schematicDrag = value; }
		}

		public float JumpListDrag
		{
			get { return this.jumpListDrag; }
			set { this.jumpListDrag = value; }
		}


		/*
		============================================================================
		Save option functions
		============================================================================
		*/
		public bool CreateBackup
		{
			get { return this.createBackup; }
			set { this.createBackup = value; }
		}

		public bool UpdateSchematics
		{
			get { return this.updateSchematics; }
			set { this.updateSchematics = value; }
		}

		public string SchematicUpdateFolder
		{
			get { return this.schematicUpdateFolder; }
			set { this.schematicUpdateFolder = value; }
		}

		public bool UpdatePrefabs
		{
			get { return this.updatePrefabs; }
			set { this.updatePrefabs = value; }
		}

		public bool UpdateScenes
		{
			get { return this.updateScenes; }
			set { this.updateScenes = value; }
		}

		public bool[] SceneUpdate
		{
			get { return this.sceneUpdate; }
			set { this.sceneUpdate = value; }
		}


		/*
		============================================================================
		Schematics functions
		============================================================================
		*/
		public MakinomSchematicAsset GetLastOpenedSchematic()
		{
			for(int i = 0; i < this.schematicAsset.Length; i++)
			{
				if(this.schematicAsset[i] != null)
				{
					return this.schematicAsset[i];
				}
			}
			return null;
		}

		public List<MakinomSchematicAsset> LastSchematics
		{
			get { return new List<MakinomSchematicAsset>(this.schematicAsset); }
			set { this.schematicAsset = value.ToArray(); }
		}

		public MakinomSchematicAsset RememberSchematic
		{
			get { return this.rememberSchematicAsset; }
			set { this.rememberSchematicAsset = value; }
		}

		public Vector2 RememberSchematicScroll
		{
			get { return this.rememberSchematicScroll; }
			set { this.rememberSchematicScroll = value; }
		}

		public Vector2 RememberSchematicZoomOffset
		{
			get { return this.rememberSchematicZoomOffset; }
			set { this.rememberSchematicZoomOffset = value; }
		}

		public int RememberSchematicFocusedNode
		{
			get { return this.rememberSchematicFocusedNode; }
			set { this.rememberSchematicFocusedNode = value; }
		}

		public DataFile DialogueImportSettings
		{
			get { return this.dialogueImportSettings; }
			set { this.dialogueImportSettings = value; }
		}


		/*
		============================================================================
		Variable functions
		============================================================================
		*/
		public List<string> VariablesDefined
		{
			get { return this.variablesDefined; }
			set { this.variablesDefined = value; }
		}

		public List<string> VariablesEditor
		{
			get { return this.variablesEditor; }
			set { this.variablesEditor = value; }
		}

		public List<string> VariablesSchematic
		{
			get { return this.variablesSchematic; }
			set { this.variablesSchematic = value; }
		}

		public List<SceneVariables> VariablesScene
		{
			get { return this.variablesScene; }
			set { this.variablesScene = value; }
		}

		public List<string> VariablesPrefab
		{
			get { return this.variablesPrefab; }
			set { this.variablesPrefab = value; }
		}

		[System.Serializable]
		public class SceneVariables
		{
			[HideInInspector]
			[SerializeField]
			public string sceneName = "";

			[HideInInspector]
			[SerializeField]
			public List<string> variables = new List<string>();

			public SceneVariables(string sceneName)
			{
				this.sceneName = sceneName;
			}
		}


		/*
		============================================================================
		Popup favorites functions
		============================================================================
		*/
		public bool IsPopupFavorite(string favorite)
		{
			if(this.popupFavoritesHash == null)
			{
				this.popupFavoritesHash = new HashSet<string>(this.popupFavorites);
			}
			return this.popupFavoritesHash.Contains(favorite);
		}

		public void AddPopupFavorite(string favorite)
		{
			if(!this.IsPopupFavorite(favorite))
			{
				this.popupFavorites.Add(favorite);
				this.popupFavoritesHash.Add(favorite);
			}
		}

		public void RemovePopupFavorite(string favorite)
		{
			if(this.IsPopupFavorite(favorite))
			{
				this.popupFavorites.Remove(favorite);
				this.popupFavoritesHash.Remove(favorite);
			}
		}

		public void ClearPopupFavorites()
		{
			this.popupFavoritesHash = null;
			this.popupFavorites.Clear();
		}


		/*
		============================================================================
		Foldout state class
		============================================================================
		*/
		[System.Serializable]
		public class FoldoutState
		{
			public bool expanded = true;

			public Color color = Color.white;

			public FoldoutState()
			{

			}
		}
	}
}
