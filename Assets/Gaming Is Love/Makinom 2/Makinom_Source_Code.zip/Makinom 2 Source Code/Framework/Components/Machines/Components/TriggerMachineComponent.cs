
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Trigger Machine")]
	public class TriggerMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			if(this.settings.startSetting.CheckTriggerEnter(this, other))
			{
				this.StartMachine(other.gameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, other.gameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, other.gameObject)) : null) :
						null);
			}
		}

		protected virtual void OnTriggerStay(Collider other)
		{
			if(this.settings.startSetting.CheckTriggerStay(this, other))
			{
				this.StartMachine(other.gameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, other.gameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, other.gameObject)) : null) :
						null);
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			if(this.settings.startSetting.CheckTriggerExit(this, other))
			{
				this.StartMachine(other.gameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, other.gameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, other.gameObject)) : null) :
						null);
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(this.settings.startSetting.CheckTriggerEnter2D(this, other))
			{
				this.StartMachine(other.gameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, other.gameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, other.gameObject)) : null) :
						null);
			}
		}

		protected virtual void OnTriggerStay2D(Collider2D other)
		{
			if(this.settings.startSetting.CheckTriggerStay2D(this, other))
			{
				this.StartMachine(other.gameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, other.gameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, other.gameObject)) : null) :
						null);
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			if(this.settings.startSetting.CheckTriggerExit2D(this, other))
			{
				this.StartMachine(other.gameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, other.gameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, other.gameObject)) : null) :
						null);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/TriggerMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			[EditorEndFoldout]
			public TriggerMachineStartSetting startSetting = new TriggerMachineStartSetting();

			public Settings()
			{

			}
		}
	}
}
