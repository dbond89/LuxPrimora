
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Template Machine")]
	public class TemplateMachineComponent : SerializedBehaviour<TemplateMachineComponent.Settings>
	{
		protected virtual void Start()
		{
			if(this.settings.delayTime > 0)
			{
				this.StartCoroutine(this.AddAfter(this.settings.delayTime));
			}
			else
			{
				this.AddMachine();
			}
		}

		public virtual IEnumerator AddAfter(float delay)
		{
			yield return new WaitForSeconds(delay);
			this.AddMachine();
		}

		public virtual void AddMachine()
		{
			MachineTemplateAsset asset = this.settings.template;
			if(asset != null)
			{
				asset.Settings.machineSetup.AddComponent(this.gameObject);
			}
			GameObject.Destroy(this);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/TemplateMachineComponent Icon.png");
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Machine Template", "Select the machine template that will be used.")]
			public AssetSelection<MachineTemplateAsset> template = new AssetSelection<MachineTemplateAsset>();

			[EditorHelp("Delay Time (s)", "The time in seconds before adding the template's machine component.")]
			public float delayTime = 0;

			public Settings()
			{

			}
		}
	}
}
