
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Tick Machine")]
	public class TickMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}


		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(!this.machineStarted &&
				this.settings.startSetting.isUpdate &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void LateUpdate()
		{
			if(!this.machineStarted &&
				this.settings.startSetting.isLateUpdate &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void FixedUpdate()
		{
			if(!this.machineStarted &&
				this.settings.startSetting.isFixedUpdate &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/TickMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			[EditorEndFoldout]
			public TickMachineStartSetting startSetting = new TickMachineStartSetting();

			public Settings()
			{

			}
		}
	}
}

