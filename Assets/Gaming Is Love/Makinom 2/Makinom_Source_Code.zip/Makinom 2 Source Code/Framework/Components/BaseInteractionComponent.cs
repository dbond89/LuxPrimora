﻿
using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public abstract class BaseInteractionComponent : BaseConditionComponent, ISerializationCallbackReceiver, IInteractionBehaviour, IDropInteraction
	{
		[System.NonSerialized]
		public StartSettings startSettings = new StartSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_startSetting;


		// ingame
		protected bool registered = false;

		protected bool initialized = false;

		protected bool isStarted = false;

		protected int isInTrigger = 0;

		protected int isColliding = 0;

		protected Quaternion storedRotation = Quaternion.identity;

		public abstract void StartInteraction(GameObject startingObject);

		public virtual bool UseAutoStopDistance
		{
			get { return false; }
		}

		public virtual void AutoStopInteraction()
		{

		}

		public virtual IEnumerator StartInteractionDelayed(GameObject startingObject, float delay)
		{
			yield return new WaitForSeconds(delay);
			this.StartInteraction(startingObject);
		}

		public virtual float MoveDestinationOffset
		{
			get
			{
				return (this.startSettings.moveToInteraction.overrideInteractionRadius ?
						(this.startSettings.moveToInteraction.setInteractionRadius ?
							this.startSettings.moveToInteraction.interactionRadius :
							RadiusComponent.GetRadius(this.gameObject)) :
						(Maki.GameControls.interaction.moveToInteraction.setInteractionRadius ?
							Maki.GameControls.interaction.moveToInteraction.defaultInteractionRadius :
							RadiusComponent.GetRadius(this.gameObject))) +
					(this.startSettings.moveToInteraction.overrideStopDistance ?
						this.startSettings.moveToInteraction.stopDistance :
						Maki.GameControls.interaction.moveToInteraction.defaultStopDistance);
			}
		}

		public virtual MoveToInteractionComponentSettings MoveToInteractionSettings
		{
			get { return this.startSettings.moveToInteraction; }
		}

		public virtual void DoTurns(GameObject startingObject)
		{
			TransformHelper.InteractionTurns(this.startSettings.turnStartingObject, startingObject,
				this.startSettings.turnMachineObject, this.gameObject, ref this.storedRotation);
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public virtual void Register()
		{
			if(!this.registered && Maki.Instantiated)
			{
				Maki.Game.Interactions.Add(this);

				if(this.startSettings.autoStartSetting.HasNotifyStart)
				{
					this.startSettings.autoStartSetting.Register(this.gameObject, this.StartByNotification);
				}
				this.registered = true;
			}
		}

		public virtual void Unregister()
		{
			if(this.registered && Maki.Instantiated)
			{
				Maki.Game.Interactions.Remove(this);

				if(this.startSettings.autoStartSetting.HasNotifyStart)
				{
					this.startSettings.autoStartSetting.Unregister(this.gameObject, this.StartByNotification);
				}
				this.registered = false;
			}
		}

		public virtual void StartByNotification()
		{
			if(this.startSettings.autoStartSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartInteraction(Maki.Game.Player.GameObject);
			}
		}


		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		protected override void Start()
		{
			bool destroyed = false;

			if(ConditionAutoCheckType.Start == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				this.initialized = true;
				this.Register();

				if(this.startSettings.autoStartSetting.isStart)
				{
					this.AutoStartCheck();
				}
			}
		}

		protected override void OnEnable()
		{
			Maki.Instance.SceneLoaded += this.OnAutoSceneLoaded;
			bool destroyed = false;

			if(ConditionAutoCheckType.Enable == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				if(this.initialized)
				{
					this.Register();
				}

				if(this.startSettings.autoStartSetting.isEnable)
				{
					this.AutoStartCheck();
				}
			}
		}

		protected virtual void OnDisable()
		{
			Maki.Instance.SceneLoaded -= this.OnAutoSceneLoaded;
			this.Unregister();

			if(this.startSettings.autoStartSetting.isDisable &&
				this.startSettings.autoStartSetting.CanStartDisabled(this, Maki.Game.Player.GameObject))
			{
				this.StartInteraction(Maki.Game.Player.GameObject);
			}
		}

		protected virtual void OnDestroy()
		{
			Maki.Instance.SceneLoaded -= this.OnAutoSceneLoaded;

			if(this.startSettings.autoStartSetting.isDestroy &&
				this.startSettings.autoStartSetting.CanStartDisabled(this, Maki.Game.Player.GameObject))
			{
				this.StartInteraction(Maki.Game.Player.GameObject);
			}
		}

		public virtual void OnAutoSceneLoaded()
		{
			if(this.startSettings.autoStartSetting.isLevelWasLoaded)
			{
				this.AutoStartCheck();
			}
		}

		protected virtual bool AutoStartCheck()
		{
			if(!this.CheckAutoDestroy())
			{
				this.CheckAutoStart();
				return true;
			}
			return false;
		}

		protected virtual void CheckAutoStart()
		{
			if(this.startSettings.autoStartSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				if(this.startSettings.autoStartSetting.autoStartDelay > 0)
				{
					this.StartCoroutine(this.StartInteractionDelayed(Maki.Game.Player.GameObject,
						this.startSettings.autoStartSetting.autoStartDelay));
				}
				else
				{
					this.StartInteraction(Maki.Game.Player.GameObject);
				}
			}
			else if(this.startSettings.autoStartSetting.repeatExecution)
			{
				this.StartCoroutine(this.CheckAutoStart2());
			}
		}

		protected virtual IEnumerator CheckAutoStart2()
		{
			if(this.startSettings.autoStartSetting.repeatDelay > 0)
			{
				yield return new WaitForSeconds(this.startSettings.autoStartSetting.repeatDelay);
			}
			else
			{
				yield return null;
			}
			this.CheckAutoStart();
		}

		protected override void EndCheck()
		{
			if(this.startSettings.turnMachineObject &&
				this.startSettings.turnRestoreMachineObject)
			{
				this.transform.rotation = this.storedRotation;
			}
			if(this.startSettings.autoStartSetting.IsStartCheck &&
				this.startSettings.autoStartSetting.repeatExecution &&
				this.isActiveAndEnabled)
			{
				this.StartCoroutine(this.CheckAutoStart2());
			}
			base.EndCheck();
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public virtual MachineTypeAsset MachineType
		{
			get { return this.startSettings.machineType.StoredAsset; }
		}

		public virtual bool IsInteract
		{
			get { return this.startSettings.interactStartSetting.isInteract; }
		}

		public virtual bool CanInteract(GameObject startingObject)
		{
			return !this.isStarted &&
				this.startSettings.interactStartSetting.isInteract &&
				this.startSettings.interactStartSetting.CanStart(this, startingObject);
		}

		public virtual bool Interact(GameObject startingObject)
		{
			if(this.startSettings.interactStartSetting.isInteract &&
				this.startSettings.interactStartSetting.CanStart(this, startingObject) &&
				this.startSettings.interactStartSetting.CheckInteractionDistance(
					this.gameObject, startingObject))
			{
				this.StartMoveToInteraction(startingObject);
				return true;
			}
			return false;
		}

		protected virtual void StartMoveToInteraction(GameObject startingObject)
		{
			if(startingObject != null &&
				Maki.GameControls.interaction.moveToInteraction.useMoveToInteraction &&
				this.startSettings.moveToInteraction.useMoveToInteraction)
			{
				MoveToInteractionComponent comp = startingObject.GetComponent<MoveToInteractionComponent>();
				if(comp == null)
				{
					comp = startingObject.AddComponent<MoveToInteractionComponent>();
					comp.Init();
				}
				comp.MoveToInteraction(this);
			}
			else
			{
				this.StartInteraction(startingObject);
			}
		}

		protected virtual void Update()
		{
			if(!this.isStarted && !Maki.Game.Paused &&
				this.startSettings.interactStartSetting.CheckKeyPress(this, this.gameObject,
					Maki.Control.InputID, this.isInTrigger > 0, this.isColliding > 0))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
			else if(this.isStarted &&
				this.UseAutoStopDistance &&
				Maki.GameControls.interaction.autoStopInteraction.Check(this.gameObject))
			{
				this.AutoStopInteraction();
			}
		}

		public virtual bool DropInteract(DragInfo drag)
		{
			if(!this.isStarted && !Maki.Game.Paused &&
				this.startSettings.interactStartSetting.CheckDrop(this, this.gameObject, drag))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Mouse functions
		============================================================================
		*/
		public virtual void OnMouseDown()
		{
			if(this.startSettings.interactStartSetting.CheckMouseDown(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		public virtual void OnMouseDrag()
		{
			if(this.startSettings.interactStartSetting.CheckMouseDrag(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		public virtual void OnMouseUp()
		{
			if(this.startSettings.interactStartSetting.CheckMouseUp(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		public virtual void OnMouseUpAsButton()
		{
			if(this.startSettings.interactStartSetting.CheckMouseUpAsButton(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		public virtual void OnMouseEnter()
		{
			if(this.startSettings.interactStartSetting.CheckMouseEnter(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		public virtual void OnMouseOver()
		{
			if(this.startSettings.interactStartSetting.CheckMouseOver(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		public virtual void OnMouseExit()
		{
			if(this.startSettings.interactStartSetting.CheckMouseExit(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		public virtual void OnTriggerEnter(Collider other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(!this.startSettings.interactStartSetting.startByRoot ||
					other.transform == other.transform.root))
			{
				this.isInTrigger++;
			}
			if(this.startSettings.triggerStartSetting.CheckTriggerEnter(this, other))
			{
				this.StartInteraction(other.gameObject);
			}
		}

		public virtual void OnTriggerStay(Collider other)
		{
			if(this.startSettings.triggerStartSetting.CheckTriggerStay(this, other))
			{
				this.StartInteraction(other.gameObject);
			}
		}

		public virtual void OnTriggerExit(Collider other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(!this.startSettings.interactStartSetting.startByRoot ||
					other.transform == other.transform.root))
			{
				this.isInTrigger--;
			}
			if(this.startSettings.triggerStartSetting.CheckTriggerExit(this, other))
			{
				this.StartInteraction(other.gameObject);
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		public virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(!this.startSettings.interactStartSetting.startByRoot ||
					other.transform == other.transform.root))
			{
				this.isInTrigger++;
			}
			if(this.startSettings.triggerStartSetting.CheckTriggerEnter2D(this, other))
			{
				this.StartInteraction(other.gameObject);
			}
		}

		public virtual void OnTriggerStay2D(Collider2D other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(!this.startSettings.interactStartSetting.startByRoot ||
					other.transform == other.transform.root))
			{
				this.isInTrigger--;
			}
			if(this.startSettings.triggerStartSetting.CheckTriggerStay2D(this, other))
			{
				this.StartInteraction(other.gameObject);
			}
		}

		public virtual void OnTriggerExit2D(Collider2D other)
		{
			if(this.startSettings.triggerStartSetting.CheckTriggerExit2D(this, other))
			{
				this.StartInteraction(other.gameObject);
			}
		}


		/*
		============================================================================
		Collision functions
		============================================================================
		*/
		public virtual void OnCollisionEnter(Collision collision)
		{
			if(Maki.Game.Player.IsPlayer(collision.gameObject) &&
				(!this.startSettings.interactStartSetting.startByRoot ||
					collision.transform == collision.transform.root))
			{
				this.isColliding++;
			}
			if(this.startSettings.collisionStartSetting.CheckCollisionEnter(this, collision))
			{
				this.StartInteraction(collision.gameObject);
			}
		}

		public virtual void OnCollisionStay(Collision collision)
		{
			if(this.startSettings.collisionStartSetting.CheckCollisionStay(this, collision))
			{
				this.StartInteraction(collision.gameObject);
			}
		}

		public virtual void OnCollisionExit(Collision collision)
		{
			if(Maki.Game.Player.IsPlayer(collision.gameObject) &&
				(!this.startSettings.interactStartSetting.startByRoot ||
					collision.transform == collision.transform.root))
			{
				this.isColliding--;
			}
			if(this.startSettings.collisionStartSetting.CheckCollisionExit(this, collision))
			{
				this.StartInteraction(collision.gameObject);
			}
		}

		public virtual void OnParticleCollision(GameObject other)
		{
			if(this.startSettings.collisionStartSetting.CheckParticleCollision(this, other))
			{
				this.StartInteraction(other);
			}
		}

		public virtual void OnControllerColliderHit(ControllerColliderHit hit)
		{
			if(this.startSettings.collisionStartSetting.CheckControllerColliderHit(this, hit))
			{
				this.StartInteraction(hit.gameObject);
			}
		}


		/*
		============================================================================
		Collision2D functions
		============================================================================
		*/
		public virtual void OnCollisionEnter2D(Collision2D collision)
		{
			if(Maki.Game.Player.IsPlayer(collision.gameObject) &&
				(!this.startSettings.interactStartSetting.startByRoot ||
					collision.transform == collision.transform.root))
			{
				this.isColliding++;
			}
			if(this.startSettings.collisionStartSetting.CheckCollisionEnter2D(this, collision))
			{
				this.StartInteraction(collision.gameObject);
			}
		}

		public virtual void OnCollisionStay2D(Collision2D collision)
		{
			if(this.startSettings.collisionStartSetting.CheckCollisionStay2D(this, collision))
			{
				this.StartInteraction(collision.gameObject);
			}
		}

		public virtual void OnCollisionExit2D(Collision2D collision)
		{
			if(Maki.Game.Player.IsPlayer(collision.gameObject) &&
				(!this.startSettings.interactStartSetting.startByRoot ||
					collision.transform == collision.transform.root))
			{
				this.isColliding--;
			}
			if(this.startSettings.collisionStartSetting.CheckCollisionExit2D(this, collision))
			{
				this.StartInteraction(collision.gameObject);
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_startSetting = this.startSettings.GetData().GetComponentDataFile("startSettings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_startSetting != null)
			{
				this.startSettings.SetData(this.serialize_startSetting.ToDataObject());
				this.serialize_startSetting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class StartSettings : BaseData
		{
			[EditorHelp("Machine Type", "Select the machine type of this interaction.\n" +
				"The machine type can be used to display different 'Interaction' HUDs or allow interaction with different 'Interaction Controller' components.")]
			public AssetSelection<MachineTypeAsset> machineType = new AssetSelection<MachineTypeAsset>();


			// auto
			[EditorFoldout("Auto", "Define the auto start settings of this interaction.", "",
				initialState = false)]
			[EditorEndFoldout]
			public AutoMachineStartSetting autoStartSetting = new AutoMachineStartSetting();


			// interact
			[EditorFoldout("Interaction", "Define the interaction start settings of this interaction.",
				initialState = false)]
			public InteractionMachineStartSetting interactStartSetting = new InteractionMachineStartSetting();

			[EditorFoldout("Move To Interaction", "This interaction can optionally move the player to the interaction before starting.",
				initialState = false)]
			[EditorEndFoldout(2)]
			public MoveToInteractionComponentSettings moveToInteraction = new MoveToInteractionComponentSettings();


			// trigger
			[EditorFoldout("Trigger", "Define the trigger start settings of this interaction.",
				initialState = false)]
			[EditorEndFoldout]
			public TriggerMachineStartSetting triggerStartSetting = new TriggerMachineStartSetting();


			// collision
			[EditorFoldout("Collision", "Define the collision start settings of this interaction.", "",
				initialState = false)]
			[EditorEndFoldout]
			public CollisionMachineStartSetting collisionStartSetting = new CollisionMachineStartSetting();

			// object turning
			[EditorHelp("Turn Starting Object", "Turn the starting game object to face the machine's game object.", "")]
			[EditorFoldout("Object Turn Settings", "Optionally turn the machine and starting game object to each other.", "",
				initialState = false)]
			public bool turnStartingObject = false;

			[EditorHelp("Turn Machine Object", "Turn the machine's game object to face the starting game object.", "")]
			public bool turnMachineObject = false;

			[EditorHelp("Reset Rotation", "Reset the machine object's rotation after the interaction finished.")]
			[EditorEndFoldout]
			[EditorIndent]
			[EditorCondition("turnMachineObject", true)]
			[EditorEndCondition]
			public bool turnRestoreMachineObject = false;

			public StartSettings()
			{

			}

			public StartSettings(bool isInteract)
			{
				this.interactStartSetting.isInteract = isInteract;
			}

			public virtual void DisableAll()
			{
				this.autoStartSetting.DisableAll();
				this.interactStartSetting.DisableAll();
				this.triggerStartSetting.DisableAll();
				this.collisionStartSetting.DisableAll();
			}

			public virtual List<string> GetUsedStartTypeNames()
			{
				List<string> list = new List<string>();
				this.autoStartSetting.GetUsedStartTypeNames(ref list);
				this.interactStartSetting.GetUsedStartTypeNames(ref list);
				this.triggerStartSetting.GetUsedStartTypeNames(ref list);
				this.collisionStartSetting.GetUsedStartTypeNames(ref list);
				return list;
			}
		}
	}
}
