
using System.Collections.Generic;
using UnityEngine;

namespace GamingIsLove.Makinom
{
	[AddComponentMenu("")]
	public class MakinomHandler : MonoBehaviour
	{
		protected Maki instance;

		// editor terrain changes need to be reset
		protected Dictionary<TerrainData, float[,,]> terrainAlphaMap;

		protected Dictionary<TerrainData, float[,]> terrainHeightMap;

		public virtual void Init(Maki instance)
		{
			this.instance = instance;
		}

		protected virtual void Update()
		{
			this.instance.FireTick();
		}

		protected virtual void LateUpdate()
		{
			this.instance.FireLateTick();
		}

		protected virtual void FixedUpdate()
		{
			this.instance.FireFixedTick();
		}

		protected virtual void OnGUI()
		{
			this.instance.FireGUITick();
		}

		protected virtual void OnApplicationQuit()
		{
			this.instance.FireApplicationQuit();
		}

		public virtual void TerrainAlphaMapChange(TerrainData terrainData)
		{
			if(Application.isEditor)
			{
				if(this.terrainAlphaMap == null)
				{
					this.terrainAlphaMap = new Dictionary<TerrainData, float[,,]>();
				}
				if(!this.terrainAlphaMap.ContainsKey(terrainData))
				{
					this.terrainAlphaMap.Add(terrainData,
						terrainData.GetAlphamaps(0, 0,
							terrainData.alphamapWidth,
							terrainData.alphamapHeight));
				}
			}
		}

		public virtual void TerrainHeightMapChange(TerrainData terrainData)
		{
			if(Application.isEditor)
			{
				if(this.terrainHeightMap == null)
				{
					this.terrainHeightMap = new Dictionary<TerrainData, float[,]>();
				}
				if(!this.terrainHeightMap.ContainsKey(terrainData))
				{
					this.terrainHeightMap.Add(terrainData,
						terrainData.GetHeights(0, 0, terrainData.heightmapResolution, terrainData.heightmapResolution));
				}
			}
		}

		protected virtual void OnDestroy()
		{
			if(Application.isEditor)
			{
				if(this.terrainAlphaMap != null)
				{
					foreach(KeyValuePair<TerrainData, float[,,]> pair in this.terrainAlphaMap)
					{
						pair.Key.SetAlphamaps(0, 0, pair.Value);
					}
				}
				if(this.terrainHeightMap != null)
				{
					foreach(KeyValuePair<TerrainData, float[,]> pair in this.terrainHeightMap)
					{
						pair.Key.SetHeights(0, 0, pair.Value);
					}
				}
			}
		}
	}
}
