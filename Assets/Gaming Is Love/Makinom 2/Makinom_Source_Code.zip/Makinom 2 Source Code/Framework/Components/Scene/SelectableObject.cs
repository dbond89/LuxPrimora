
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	public class SelectableObject : MonoBehaviour
	{
		protected bool registered = false;

		protected Renderer rendererComponent;

		public virtual Renderer Renderer
		{
			get { return this.rendererComponent; }
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public virtual void Register()
		{
			if(!this.registered && Maki.Instantiated)
			{
				if(this.rendererComponent == null)
				{
					this.rendererComponent = this.GetComponentInChildren<Renderer>();
					if(this.rendererComponent == null)
					{
						this.rendererComponent = this.GetComponentInParent<Renderer>();
					}
				}
				Maki.Game.Interactions.AddSelection(this);
				this.registered = true;
			}
		}

		public virtual void Unregister()
		{
			if(this.registered && Maki.Instantiated)
			{
				Maki.Game.Interactions.RemoveSelection(this);
				this.registered = false;
			}
		}

		protected virtual void OnEnable()
		{
			this.Register();
		}

		protected virtual void OnDisable()
		{
			this.Unregister();
		}
	}
}
