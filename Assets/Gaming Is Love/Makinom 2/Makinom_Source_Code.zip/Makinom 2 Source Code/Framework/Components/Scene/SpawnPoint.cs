
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Spawn Point")]
	public class SpawnPoint : BaseSceneID, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected bool isOnGround = false;

		protected Collider colliderComponent;

		protected Collider2D collider2DComponent;

		public override bool UseSceneID
		{
			get { return true; }
			set { }
		}

		public virtual bool HasCollider()
		{
			Collider collider = this.GetComponent<Collider>();
			if(collider != null &&
				collider.enabled)
			{
				return true;
			}
			Collider2D collider2D = this.GetComponent<Collider2D>();
			if(collider2D != null &&
				collider2D.enabled)
			{
				return true;
			}
			return false;
		}

		protected virtual void Awake()
		{
			this.SetOnGround();
		}

		public void SetOnGround()
		{
			this.colliderComponent = this.GetComponent<Collider>();
			this.collider2DComponent = this.GetComponent<Collider2D>();

			if(this.settings.placeOnGround &&
				(this.colliderComponent == null ||
					!this.colliderComponent.enabled) &&
				(this.collider2DComponent == null ||
					!this.collider2DComponent.enabled))
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(Maki.GameSettings.raycastType,
					this.transform.position, -Vector3.up, out hit, this.settings.distance, this.settings.layerMask))
				{
					this.transform.position = hit.point + this.settings.offset;
				}
			}
			this.isOnGround = true;
		}

		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "/GamingIsLove/Makinom/Components/SpawnPoint Icon.png");
		}

		public virtual void Spawn(GameObject gameObject, Vector3 offset)
		{
			if(gameObject != null)
			{
				if(!this.isOnGround)
				{
					this.SetOnGround();
				}

				Vector3 position = this.GetSpawnPosition();

				gameObject.transform.SetPositionAndRotation(position + offset,
					Quaternion.Euler(
						this.settings.useRotation.x ?
							this.transform.eulerAngles.x :
							gameObject.transform.eulerAngles.x,
						this.settings.useRotation.y ?
							this.transform.eulerAngles.y :
							gameObject.transform.eulerAngles.y,
						this.settings.useRotation.z ?
							this.transform.eulerAngles.z :
							gameObject.transform.eulerAngles.z));

				// scale
				gameObject.transform.localScale = new Vector3(
					this.settings.useScale.x ?
						this.transform.localScale.x :
						gameObject.transform.localScale.x,
					this.settings.useScale.y ?
						this.transform.localScale.y :
						gameObject.transform.localScale.y,
					this.settings.useScale.z ?
						this.transform.localScale.z :
						gameObject.transform.localScale.z);
			}
		}

		public virtual void GetVector3s(ref Vector3 position, ref Vector3 rotation, ref Vector3 scale)
		{
			if(!this.isOnGround)
			{
				this.SetOnGround();
			}

			position = this.GetSpawnPosition();

			// rotation
			rotation = new Vector3(
				this.settings.useRotation.x ?
					this.transform.eulerAngles.x :
					rotation.x,
				this.settings.useRotation.y ?
					this.transform.eulerAngles.y :
					rotation.y,
				this.settings.useRotation.z ?
					this.transform.eulerAngles.z :
					rotation.z);

			// scale
			scale = new Vector3(
				this.settings.useScale.x ?
					this.transform.localScale.x :
					scale.x,
				this.settings.useScale.y ?
					this.transform.localScale.y :
					scale.y,
				this.settings.useScale.z ?
					this.transform.localScale.z :
					scale.z);
		}

		public virtual void GetScale(ref Vector3 scale)
		{
			scale = new Vector3(
				this.settings.useScale.x ?
					this.transform.localScale.x :
					scale.x,
				this.settings.useScale.y ?
					this.transform.localScale.y :
					scale.y,
				this.settings.useScale.z ?
					this.transform.localScale.z :
					scale.z);
		}

		public virtual Vector3 GetSpawnPosition()
		{
			if(this.colliderComponent != null &&
				this.colliderComponent.enabled)
			{
				Vector3 position = this.colliderComponent.bounds.center;
				position.y += this.colliderComponent.bounds.extents.y - 0.1f;
				position.x += UnityWrapper.Range(-this.colliderComponent.bounds.extents.x,
					this.colliderComponent.bounds.extents.x);
				position.z += UnityWrapper.Range(-this.colliderComponent.bounds.extents.z,
					this.colliderComponent.bounds.extents.z);
				if(this.settings.placeOnGround)
				{
					RaycastOutput hit;
					if(RaycastHelper.Raycast(Maki.GameSettings.raycastType,
						position, -Vector3.up, out hit, this.settings.distance, this.settings.layerMask))
					{
						position = hit.point + this.settings.offset;
					}
				}
				return position;
			}
			else if(this.collider2DComponent != null &&
				this.collider2DComponent.enabled)
			{
				Vector3 position = this.collider2DComponent.bounds.center;
				position.y += this.collider2DComponent.bounds.extents.y - 0.1f;
				position.x += UnityWrapper.Range(-this.collider2DComponent.bounds.extents.x,
					this.collider2DComponent.bounds.extents.x);
				position.z += UnityWrapper.Range(-this.collider2DComponent.bounds.extents.z,
					this.collider2DComponent.bounds.extents.z);
				if(this.settings.placeOnGround)
				{
					RaycastOutput hit;
					if(RaycastHelper.Raycast(Maki.GameSettings.raycastType,
						position, -Vector3.up, out hit, this.settings.distance, this.settings.layerMask))
					{
						position = hit.point + this.settings.offset;
					}
				}
				return position;
			}
			return this.transform.position;
		}

		public static SpawnPoint GetSpawnPoint(int spawnID)
		{
			Scene activeScene = SceneManager.GetActiveScene();
			SpawnPoint[] sp = UnityEngine.Object.FindObjectsOfType<SpawnPoint>();
			List<SpawnPoint> list = new List<SpawnPoint>();
			for(int i = 0; i < sp.Length; i++)
			{
				if(sp[i].sceneID == spawnID &&
					sp[i].gameObject.scene == activeScene)
				{
					if(!sp[i].isOnGround)
					{
						sp[i].SetOnGround();
					}
					list.Add(sp[i]);
				}
			}
			if(list.Count == 0)
			{
				for(int i = 0; i < sp.Length; i++)
				{
					if(sp[i].sceneID == spawnID)
					{
						if(!sp[i].isOnGround)
						{
							sp[i].SetOnGround();
						}
						list.Add(sp[i]);
					}
				}
			}
			if(list.Count > 0)
			{
				return list[UnityWrapper.Range(0, list.Count)];
			}
			return null;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Use Rotation", "Use the rotation of the spawn point when placing a game object on it.")]
			public AxisBool useRotation = new AxisBool();

			[EditorHelp("Use Scale", "Use the scale of the spawn point when placing a game object on it.")]
			[EditorSeparator]
			public AxisBool useScale = new AxisBool();


			// place on ground
			[EditorHelp("Place On Ground", "Place the spawn point on the ground using a raycast.\n" +
				"When using a collider to create an area spawn, this will be used to " +
				"place the individual spawn positions on the ground instead of the spawn point.")]
			[EditorSeparator]
			[EditorTitleLabel("Place On Ground")]
			public bool placeOnGround = true;

			[EditorHelp("Distance", "The distance used for the raycast.")]
			[EditorCondition("placeOnGround", true)]
			public float distance = 100.0f;

			[EditorHelp("Layer Mask", "Select the layers that will be hit by the raycast.")]
			public LayerMask layerMask = -1;

			[EditorHelp("Offset", "The offset that will be added to the hit ground position.")]
			[EditorEndCondition]
			public Vector3 offset = Vector3.zero;

			public Settings()
			{

			}
		}
	}
}
