
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	public interface ISoundAssignment
	{
		AudioClip GetClip(SoundTypeAsset type);
	}

	[AddComponentMenu("Makinom/Scenes/Sound Assignment")]
	public class SoundAssignmentComponent : SerializedBehaviour<SoundAssignmentComponent.Settings>, ISoundAssignment
	{
		/*
		============================================================================
		Sound functions
		============================================================================
		*/
		public virtual AudioClip GetClip(SoundTypeAsset type)
		{
			return this.settings.GetClip(type);
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/SoundAssignmentComponent Icon.png");
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Sound Template", "Select the sound template that will be used.", "")]
			public AssetSelection<SoundTemplateAsset> template = new AssetSelection<SoundTemplateAsset>();

			[EditorArray("Add Sound", "Add a sound to this sound assignment.", "",
				"Remove", "Remove this sound.", "", enbox=true)]
			public Sound[] sound = new Sound[0];

			public Settings()
			{

			}

			public AudioClip GetClip(SoundTypeAsset type)
			{
				for(int i = 0; i < this.sound.Length; i++)
				{
					if(this.sound[i].soundType.Is(type))
					{
						return this.sound[i].GetSound();
					}
				}
				if(this.template.StoredAsset != null)
				{
					return this.template.StoredAsset.Settings.GetClip(type);
				}
				return null;
			}
		}
	}
}
