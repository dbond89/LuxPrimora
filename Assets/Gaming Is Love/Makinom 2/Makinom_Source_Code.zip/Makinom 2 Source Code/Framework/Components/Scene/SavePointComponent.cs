﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	public enum SavePointType { SavePoint, AutoSave, RetryPoint }

	[AddComponentMenu("Makinom/Scenes/Save Point")]
	public class SavePointComponent : BaseInteractionComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		protected virtual void Reset()
		{
			this.startSettings.interactStartSetting.isInteract = true;
		}


		/*
		============================================================================
		Scene change functions
		============================================================================
		*/
		public override void StartInteraction(GameObject startingObject)
		{
			if(!this.isStarted)
			{
				this.DoTurns(startingObject);

				if(SavePointType.AutoSave == this.settings.type)
				{
					Maki.SaveGame.Save(SaveGameHandler.AUTOSAVE_INDEX - Maki.Game.AutoSaveSlot);
					Maki.SaveGame.CreateInfos();
					if(Maki.SaveGameSettings.showAutoSaveMessage)
					{
						Maki.SaveGameSettings.ShowAutoSaveMessage();
					}
					if(this.settings.destroyAfter)
					{
						GameObject.Destroy(this.gameObject);
					}
					else
					{
						this.EndCheck();
					}
				}
				else if(SavePointType.RetryPoint == this.settings.type)
				{
					Maki.SaveGame.Save(SaveGameHandler.RETRY_INDEX);
					if(this.settings.destroyAfter)
					{
						GameObject.Destroy(this.gameObject);
					}
					else
					{
						this.EndCheck();
					}
				}
				else if(SavePointType.SavePoint == this.settings.type)
				{
					this.isStarted = true;

					Maki.Control.SetBlockControl(1, true);
					Maki.SaveGame.CreateInfos();

					int inputID = Maki.Control.InputID;
					IInputID tmpInputID = ComponentHelper.ToInputID(startingObject);
					if(tmpInputID != null)
					{
						inputID = tmpInputID.InputID;
					}
					else
					{
						tmpInputID = ComponentHelper.ToInputID(this.gameObject);
						if(tmpInputID != null)
						{
							inputID = tmpInputID.InputID;
						}
					}

					if(Maki.SaveGameSettings.showSPChoice)
					{
						Maki.SaveGameSettings.savePoint.Show(this.SaveMenuClosed, this.SaveMenuClosed, null, inputID);
					}
					else
					{
						Maki.SaveGameSettings.saveMenu.Show(this.SaveMenuClosed, this.SaveMenuClosed, inputID);
					}
				}
			}
		}

		public virtual void SaveMenuClosed()
		{
			this.isStarted = false;
			Maki.Control.SetBlockControl(-1, true);
			if(this.settings.destroyAfter)
			{
				GameObject.Destroy(this.gameObject);
			}
			else
			{
				this.EndCheck();
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/SavePointComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Save Point Type", "Select the type of this save point:\n" +
				"- Save Point: Opens the save point menu.\n" +
				"- Auto Save: Saves to the current auto save slot.\n" +
				"- Retry Point: Saves a retry save game.")]
			public SavePointType type = SavePointType.SavePoint;

			[EditorHelp("Destroy After", "Destroy the game object after using the save point.")]
			public bool destroyAfter = false;

			public Settings()
			{

			}
		}
	}
}