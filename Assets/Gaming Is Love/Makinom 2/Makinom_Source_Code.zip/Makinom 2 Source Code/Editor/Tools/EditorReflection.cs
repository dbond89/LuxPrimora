
using UnityEngine;
using UnityEngine.Audio;
using GamingIsLove.Makinom;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEditor;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorReflection
	{
		// instance
		private static EditorReflection instance;

		private static System.Object instanceLock = new System.Object();

		private List<System.Type> makinomAssetTypes;

		private List<System.Type> allowedParameterTypes;

		private List<System.Type> allowedSimpleTypes;

		private List<IEditorFunctions> editorFunctions;


		// reflection data
		private Dictionary<string, System.Type> reflectionType = new Dictionary<string, System.Type>();

		private Dictionary<string, List<string>> reflectionFunction = new Dictionary<string, List<string>>();

		private Dictionary<string, Dictionary<string, List<string>>> reflectionFunctionParameters =
			new Dictionary<string, Dictionary<string, List<string>>>();

		private Dictionary<string, Dictionary<System.Type, List<string>>> reflectionField =
			new Dictionary<string, Dictionary<System.Type, List<string>>>();

		private Dictionary<string, Dictionary<System.Type, List<string>>> reflectionProperty =
			new Dictionary<string, Dictionary<System.Type, List<string>>>();

		private Dictionary<string, List<string>> reflectionSimpleField = new Dictionary<string, List<string>>();

		private Dictionary<string, List<string>> reflectionSimpleProperty = new Dictionary<string, List<string>>();

		private FieldInfo textEditor;

		private System.Type componentType;

		private EditorReflection()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of EditorRefleciton!");
			}
			else
			{
				instance = this;
				instance.componentType = typeof(Component);
			}
		}

		public static EditorReflection Instance
		{
			get
			{
				if(instance == null)
				{
					lock(instanceLock)
					{
						if(instance == null)
						{
							new EditorReflection();
						}
					}
				}
				return instance;
			}
		}

		public TextEditor GetTextEditor()
		{
			if(this.textEditor == null)
			{
				this.textEditor = typeof(EditorGUI).GetField("activeEditor",
					System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);
			}
			return this.textEditor.GetValue(null) as TextEditor;
		}

		public List<System.Type> GetMakinomAssetTypes()
		{
			if(this.makinomAssetTypes == null)
			{
				System.Type baseType = typeof(IMakinomGenericAsset);
				this.makinomAssetTypes = new List<System.Type>();
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] type = assembly[i].GetTypes();
						for(int j = 0; j < type.Length; j++)
						{
							if(type[j] != null && type[j].IsClass && type[j].IsPublic &&
								!type[j].IsAbstract && !type[j].IsInterface &&
								baseType.IsAssignableFrom(type[j]) &&
								!this.makinomAssetTypes.Contains(type[j]))
							{
								this.makinomAssetTypes.Add(type[j]);
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for classes: " + ex.Message);
					}
				}
			}
			return this.makinomAssetTypes;
		}


		/*
		============================================================================
		Class functions
		============================================================================
		*/
		public System.Type GetClassType(string className, System.Type baseType)
		{
			System.Type foundType;
			if(this.reflectionType.TryGetValue(className, out foundType))
			{
				return foundType;
			}
			else
			{
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				bool isComponent = baseType == this.componentType;
				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] type = assembly[i].GetTypes();
						for(int j = 0; j < type.Length; j++)
						{
							if(type[j] != null &&
								(type[j].IsClass ?
									type[j].IsPublic && baseType.IsAssignableFrom(type[j]) :
									isComponent && type[j].IsInterface) &&
								type[j].Name == className)
							{
								this.reflectionType.Add(className, type[j]);
								return type[j];
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for class: " + ex.Message);
					}
				}
			}
			return null;
		}

		public List<string> GetClassList(string value, System.Type baseType)
		{
			List<string> list = new List<string>();

			if(value != "")
			{
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				bool isComponent = baseType == this.componentType;
				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] type = assembly[i].GetTypes();
						for(int j = 0; j < type.Length; j++)
						{
							if(type[j] != null &&
								(type[j].IsClass ?
									type[j].IsPublic && baseType.IsAssignableFrom(type[j]) :
									isComponent && type[j].IsInterface) &&
								type[j].Name.IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0 &&
								!list.Contains(type[j].Name))
							{
								list.Add(type[j].Name);
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for classes: " + ex.Message);
					}
				}
			}
			else
			{
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				bool isComponent = baseType == this.componentType;
				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] type = assembly[i].GetTypes();
						for(int j = 0; j < type.Length; j++)
						{
							if(type[j] != null &&
								(type[j].IsClass ?
									type[j].IsPublic && baseType.IsAssignableFrom(type[j]) :
									isComponent && type[j].IsInterface) &&
								!list.Contains(type[j].Name))
							{
								list.Add(type[j].Name);
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for classes: " + ex.Message);
					}
				}
			}
			return list;
		}

		public List<string> GetEnumList(string value)
		{
			List<string> list = new List<string>();

			if(value != "")
			{
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] type = assembly[i].GetTypes();
						for(int j = 0; j < type.Length; j++)
						{
							if(type[j] != null && type[j].IsEnum && type[j].IsPublic &&
								type[j].Name.IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0 &&
								!list.Contains(type[j].Name))
							{
								list.Add(type[j].Name);
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for enums: " + ex.Message);
					}
				}
			}
			else
			{
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] type = assembly[i].GetTypes();
						for(int j = 0; j < type.Length; j++)
						{
							if(type[j] != null && type[j].IsEnum && type[j].IsPublic &&
								!list.Contains(type[j].Name))
							{
								list.Add(type[j].Name);
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for enums: " + ex.Message);
					}
				}
			}
			return list;
		}


		/*
		============================================================================
		Function functions
		============================================================================
		*/
		public List<string> GetClassFunctions(string value, string className, System.Type baseType)
		{
			// get function names
			List<string> list = null;
			if(className != "")
			{
				if(!this.reflectionFunction.TryGetValue(className, out list))
				{
					list = new List<string>();

					System.Type type = this.GetClassType(className, baseType);
					if(type != null)
					{
						MethodInfo[] method = type.GetMethods(BindingFlags.Public | BindingFlags.Instance);
						for(int i = 0; i < method.Length; i++)
						{
							if(!method[i].IsSpecialName &&
								!method[i].IsConstructor &&
								this.CheckMethodParameters(method[i]) &&
								!list.Contains(method[i].Name))
							{
								list.Add(method[i].Name);
							}
						}
						list.Sort();
						this.reflectionFunction.Add(className, list);
					}
				}
			}

			// search
			if(value != "" && list != null && list.Count > 0)
			{
				List<string> found = new List<string>();
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
					{
						found.Add(list[i]);
					}
				}
				return found;
			}
			else
			{
				return list;
			}
		}

		public List<string> GetFunctionParameters(string className, string functionName, System.Type baseType)
		{
			if(className != "" && functionName != "")
			{
				Dictionary<string, List<string>> classList;
				if(!this.reflectionFunctionParameters.TryGetValue(className, out classList))
				{
					classList = new Dictionary<string, List<string>>();
					this.reflectionFunctionParameters.Add(className, classList);
				}
				List<string> list;
				if(classList.TryGetValue(functionName, out list))
				{
					return list;
				}
				else
				{
					System.Type type = this.GetClassType(className, baseType);
					if(type != null)
					{
						list = new List<string>();
						MethodInfo[] method = type.GetMethods(BindingFlags.Public | BindingFlags.Instance);
						for(int i = 0; i < method.Length; i++)
						{
							if(!method[i].IsSpecialName &&
								!method[i].IsConstructor &&
								method[i].Name == functionName &&
								this.CheckMethodParameters(method[i]))
							{
								// return type
								string returnType = "";
								if(method[i].ReturnType.Equals(typeof(string)))
								{
									returnType = "string";
								}
								else if(method[i].ReturnType.Equals(typeof(bool)))
								{
									returnType = "bool";
								}
								else if(method[i].ReturnType.Equals(typeof(int)))
								{
									returnType = "int";
								}
								else if(method[i].ReturnType.Equals(typeof(float)))
								{
									returnType = "float";
								}
								else if(method[i].ReturnType.Equals(typeof(Vector2)))
								{
									returnType = "Vector2";
								}
								else if(method[i].ReturnType.Equals(typeof(Vector3)))
								{
									returnType = "Vector3";
								}
								else if(method[i].ReturnType.Equals(typeof(Quaternion)))
								{
									returnType = "Quaternion";
								}
								else if(method[i].ReturnType.Equals(typeof(Color)))
								{
									returnType = "Color";
								}
								else if(method[i].ReturnType.Equals(typeof(LayerMask)))
								{
									returnType = "LayerMask";
								}
								else
								{
									returnType = method[i].ReturnType.Name;
								}

								// parameters
								ParameterInfo[] parameter = method[i].GetParameters();
								if(parameter.Length > 0)
								{
									StringBuilder builder = new StringBuilder();
									for(int j = 0; j < parameter.Length; j++)
									{
										if(j > 0)
										{
											builder.Append(", ");
										}
										if(parameter[j].ParameterType.Equals(typeof(string)))
										{
											builder.Append("string ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(bool)))
										{
											builder.Append("bool ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(int)))
										{
											builder.Append("int ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(float)))
										{
											builder.Append("float ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(Vector2)))
										{
											builder.Append("Vector2 ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(Vector3)))
										{
											builder.Append("Vector3 ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(Quaternion)))
										{
											builder.Append("Quaternion ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(Color)))
										{
											builder.Append("Color ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(LayerMask)))
										{
											builder.Append("LayerMask ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(GameObject)))
										{
											builder.Append("GameObject ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(AudioClip)))
										{
											builder.Append("AudioClip ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(AudioMixer)))
										{
											builder.Append("AudioMixer ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(AudioMixerGroup)))
										{
											builder.Append("AudioMixerGroup ").Append(parameter[j].Name);
										}
										else if(typeof(Texture).IsAssignableFrom(parameter[j].ParameterType))
										{
											builder.Append("Texture ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(Material)))
										{
											builder.Append("Material ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(PhysicMaterial)))
										{
											builder.Append("PhysicMaterial ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(PhysicsMaterial2D)))
										{
											builder.Append("PhysicsMaterial2D ").Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.Equals(typeof(Sprite)))
										{
											builder.Append("Sprite ").Append(parameter[j].Name);
										}
										else if(typeof(Component).IsAssignableFrom(parameter[j].ParameterType))
										{
											builder.Append(parameter[j].ParameterType.ToString()).Append(parameter[j].Name);
										}
										else if(parameter[j].ParameterType.IsEnum)
										{
											builder.Append(parameter[j].ParameterType.Name).Append("(Enum) ").Append(parameter[j].Name);
										}
										else
										{
											builder.Append("Not Supported");
										}
									}
									builder.Append(" (returns ").Append(returnType).Append(")");
									list.Add(list.Count + ": " + builder.ToString());
								}
								else
								{
									list.Add(list.Count + ": No parameters (returns " + returnType + ")");
								}
							}
						}
						if(list.Count > 0)
						{
							this.reflectionFunctionParameters[className].Add(functionName, list);
						}
						return list;
					}
				}
			}
			return null;
		}

		public bool CheckMethodParameters(MethodInfo method)
		{
			if(this.allowedParameterTypes == null)
			{
				this.allowedParameterTypes = new List<System.Type>();
				this.allowedParameterTypes.Add(typeof(string));
				this.allowedParameterTypes.Add(typeof(bool));
				this.allowedParameterTypes.Add(typeof(int));
				this.allowedParameterTypes.Add(typeof(float));
				this.allowedParameterTypes.Add(typeof(Vector2));
				this.allowedParameterTypes.Add(typeof(Vector3));
				this.allowedParameterTypes.Add(typeof(Quaternion));
				this.allowedParameterTypes.Add(typeof(Color));
				this.allowedParameterTypes.Add(typeof(LayerMask));
				this.allowedParameterTypes.Add(typeof(GameObject));
				this.allowedParameterTypes.Add(typeof(AudioClip));
				this.allowedParameterTypes.Add(typeof(AudioMixer));
				this.allowedParameterTypes.Add(typeof(AudioMixerGroup));
				this.allowedParameterTypes.Add(typeof(Texture));
				this.allowedParameterTypes.Add(typeof(Texture2D));
				this.allowedParameterTypes.Add(typeof(RenderTexture));
				this.allowedParameterTypes.Add(typeof(Material));
				this.allowedParameterTypes.Add(typeof(PhysicMaterial));
				this.allowedParameterTypes.Add(typeof(PhysicsMaterial2D));
				this.allowedParameterTypes.Add(typeof(Sprite));
				this.allowedParameterTypes.Add(typeof(Component));
			}

			ParameterInfo[] parameter = method.GetParameters();

			for(int i = 0; i < parameter.Length; i++)
			{
				if(!this.allowedParameterTypes.Contains(parameter[i].ParameterType) &&
					!parameter[i].ParameterType.IsEnum)
				{
					return false;
				}
			}
			return true;
		}

		private bool IsSimpleType(System.Type type)
		{
			if(this.allowedSimpleTypes == null)
			{
				this.allowedSimpleTypes = new List<System.Type>();
				this.allowedSimpleTypes.Add(typeof(string));
				this.allowedSimpleTypes.Add(typeof(bool));
				this.allowedSimpleTypes.Add(typeof(int));
				this.allowedSimpleTypes.Add(typeof(float));
				this.allowedSimpleTypes.Add(typeof(Vector2));
				this.allowedSimpleTypes.Add(typeof(Vector3));
				this.allowedSimpleTypes.Add(typeof(Quaternion));
			}

			return this.allowedSimpleTypes.Contains(type) || type.IsEnum;
		}


		/*
		============================================================================
		Field functions
		============================================================================
		*/
		public List<string> GetClassFields(string value, string className, System.Type baseType, System.Type fieldType)
		{
			// get field names
			List<string> list = null;
			if(className != "")
			{
				if(fieldType == null)
				{
					if(!this.reflectionSimpleField.TryGetValue(className, out list))
					{
						list = new List<string>();

						System.Type type = this.GetClassType(className, baseType);
						if(type != null)
						{
							FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(type);
							for(int i = 0; i < field.Length; i++)
							{
								if(this.IsSimpleType(field[i].FieldType) &&
									!list.Contains(field[i].Name))
								{
									list.Add(field[i].Name);
								}
							}
							list.Sort();
							this.reflectionSimpleField.Add(className, list);
						}
					}
				}
				else
				{
					Dictionary<System.Type, List<string>> fieldList;
					if(!this.reflectionField.TryGetValue(className, out fieldList))
					{
						fieldList = new Dictionary<System.Type, List<string>>();
						this.reflectionField.Add(className, fieldList);
					}
					if(!fieldList.TryGetValue(fieldType, out list))
					{
						list = new List<string>();

						System.Type type = this.GetClassType(className, baseType);
						if(type != null)
						{
							FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(type);
							for(int i = 0; i < field.Length; i++)
							{
								if((fieldType.IsAssignableFrom(field[i].FieldType) ||
										field[i].FieldType.IsEnum) &&
									!list.Contains(field[i].Name))
								{
									list.Add(field[i].Name);
								}
							}
							list.Sort();
							fieldList.Add(fieldType, list);
						}
					}
				}
			}

			// search
			if(value != "" && list != null && list.Count > 0)
			{
				List<string> found = new List<string>();
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
					{
						found.Add(list[i]);
					}
				}
				return found;
			}
			else
			{
				return list;
			}
		}

		public List<string> GetClassProperties(string value, string className, System.Type baseType, System.Type fieldType)
		{
			// get field names
			List<string> list = null;
			if(className != "")
			{
				if(fieldType == null)
				{
					if(!this.reflectionSimpleProperty.TryGetValue(className, out list))
					{
						list = new List<string>();

						System.Type type = this.GetClassType(className, baseType);
						if(type != null)
						{
							PropertyInfo[] property = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
							for(int i = 0; i < property.Length; i++)
							{
								if(this.IsSimpleType(property[i].PropertyType) &&
									!list.Contains(property[i].Name))
								{
									list.Add(property[i].Name);
								}
							}
							list.Sort();
							this.reflectionSimpleProperty.Add(className, list);
						}
					}
				}
				else
				{
					Dictionary<System.Type, List<string>> propertyList;
					if(!this.reflectionProperty.TryGetValue(className, out propertyList))
					{
						propertyList = new Dictionary<System.Type, List<string>>();
						this.reflectionProperty.Add(className, propertyList);
					}
					if(!propertyList.TryGetValue(fieldType, out list))
					{
						list = new List<string>();

						System.Type type = this.GetClassType(className, baseType);
						if(type != null)
						{
							PropertyInfo[] property = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
							for(int i = 0; i < property.Length; i++)
							{
								if((fieldType.IsAssignableFrom(property[i].PropertyType) ||
										property[i].PropertyType.IsEnum) &&
									!list.Contains(property[i].Name))
								{
									list.Add(property[i].Name);
								}
							}
							list.Sort();
							propertyList.Add(fieldType, list);
						}
					}
				}
			}

			// search
			if(value != "" && list != null && list.Count > 0)
			{
				List<string> found = new List<string>();
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
					{
						found.Add(list[i]);
					}
				}
				return found;
			}
			else
			{
				return list;
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public List<IEditorFunctions> GetEditorFunctions()
		{
			if(this.editorFunctions == null)
			{
				this.editorFunctions = new List<IEditorFunctions>();
				List<System.Type> addedTypes = new List<System.Type>();
				System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				System.Type baseType = typeof(IEditorFunctions);
				for(int i = 0; i < assembly.Length; i++)
				{
					this.GetEditorFunctionsFromAssembly(baseType, assembly[i],
						ref addedTypes, ref this.editorFunctions);
				}
			}
			return this.editorFunctions;
		}

		private void GetEditorFunctionsFromAssembly(System.Type baseType, System.Reflection.Assembly assembly,
			ref List<System.Type> addedTypes, ref List<IEditorFunctions> list)
		{
			try
			{
				System.Type[] types = assembly.GetTypes();
				for(int i = 0; i < types.Length; i++)
				{
					System.Type type = types[i].IsNested ? types[i].DeclaringType : types[i];
					if(!addedTypes.Contains(type) &&
						baseType.IsAssignableFrom(type))
					{
						ConstructorInfo constructorInfo = type.GetConstructor(System.Type.EmptyTypes);
						if(constructorInfo != null)
						{
							IEditorFunctions tmpTool = constructorInfo.Invoke(new System.Object[] { }) as IEditorFunctions;
							if(tmpTool != null)
							{
								list.Add(tmpTool);
								addedTypes.Add(type);
							}
						}
					}
				}
			}
			catch(System.Reflection.ReflectionTypeLoadException ex)
			{
				Debug.LogWarning("Issue while searching for editor functions: " + ex.Message);
			}
		}
	}
}

