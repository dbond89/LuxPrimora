﻿
using UnityEngine;
using System.Collections.Generic;
using System.IO;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class BaseLanguageExportFormat : BaseTypeData
	{
		public abstract string GetFileExtension();

		protected virtual void SaveFile(string path, string data)
		{
			using(StreamWriter writer = new StreamWriter(path))
			{
				writer.Write(data);
				writer.Flush();
				writer.Close();
			}
		}

		protected virtual string LoadFile(string path)
		{
			string text = "";
			if(File.Exists(path))
			{
				using(StreamReader reader = new StreamReader(path))
				{
					text = reader.ReadToEnd();
					reader.Close();
				}
			}
			return text;
		}

		/*
		============================================================================
		Export functions
		============================================================================
		*/
		public abstract void SaveExportData(string path, List<LanguageData.Export> export);


		/*
		============================================================================
		Import functions
		============================================================================
		*/
		public abstract EditorLanguageExporter.ImportData GetImportData(string path);
	}
}
