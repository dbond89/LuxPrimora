﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.Makinom.Editor
{
	[EditorSettingInfo("Markup", "Dialogues and their content are encapsuled by identifier tags (e.g. '<dialogue><title>Speaker</title><message>Text</message></dialogue>'.")]
	public class MarkupDialogueImportFormat : BaseDialogueImportFormat
	{
		// dialogue
		[EditorFoldout("Markup Format Settings", "Define the settings used to import the processing text.", "",
			"Dialogue Tags", "Define the tags used to encapsule a whole dialogue.\n" +
			"The other tags (message, title, choices) must be between the dialogue tags.", "")]
		[EditorEndFoldout]
		[EditorLabel("Define the tags used to encapsule a whole dialogue.\n" +
			"The other tags (message, title, choices) must be between the dialogue tags.")]
		public MarkupTags dialogueTags = new MarkupTags("<dialogue>", "</dialogue>");

		// title
		[EditorFoldout("Title Tags", "Define the tags used to encapsule the title.\n" +
			"Only one per dialogue is allowed.")]
		[EditorEndFoldout]
		[EditorLabel("Define the tags used to encapsule the title.\n" +
			"Only one per dialogue is allowed.")]
		public MarkupTags titleTags = new MarkupTags("<title>", "</title>");

		// title
		[EditorFoldout("Message Tags", "Define the tags used to encapsule the message of the dialogue.\n" +
			"Only one per dialogue is allowed.")]
		[EditorEndFoldout]
		[EditorLabel("Define the tags used to encapsule the message of the dialogue.\n" +
			"Only one per dialogue is allowed.")]
		public MarkupTags messageTags = new MarkupTags("<message>", "</message>");

		// choice
		[EditorFoldout("Choice Tags", "Define the tags used to encapsule a choice.\n" +
			"Multiple per dialogue are allowed.")]
		[EditorLabel("Define the tags used to encapsule a choice.\n" +
			"Multiple per dialogue are allowed.")]
		public MarkupTags choiceTags = new MarkupTags("<choice>", "</choice>");

		[EditorHelp("Auto Next Dialogue", "Choices of a dialogue will automatically set their next dialogue to the next dialogues that are processed after the choices.\n" +
			"The dialogue's own 'Next Dialogue' will not be set.")]
		[EditorEndFoldout(2)]
		public bool choiceAutoNextDialogue = false;


		// dialogue text
		[EditorHelp("Trim Spaces", "Remove spaces at the start and end of all lines.")]
		[EditorFoldout("Processing Text", "The text that will be processed to create dialogues.")]
		public bool trimSpaces = true;

		[EditorHelp("Trim Tabs", "Remove tabs at the start and end of all lines.")]
		public bool trimTabs = true;

		[EditorHelp("Trim Empty Lines", "Remove empty lines at the start and end of content (title, message, choices).\n" +
			"Only used when processing the next, not during preprocessing.")]
		public bool trimEmptyLines = true;

		[EditorHelp("Unified New Line", "All new line characters will be changed to use '\\n'.\n" +
			"I.e. '\\r\\n' will be updated to '\\n', and afterwards single '\\r' to '\\n'.")]
		public bool unifiedNewLine = true;

		[EditorHelp("Processing Text", "The text that will be processed to create dialogues.")]
		[EditorEndFoldout]
		[EditorInfo(isStandardTextArea = true)]
		[EditorWidth(true)]
		[EditorLabel("The text that will be processed to create dialogues.")]
		[EditorCallback("button:process", EditorCallbackType.Before)]
		[EditorCallback("button:process", EditorCallbackType.After)]
		public string processingText = "";

		public MarkupDialogueImportFormat()
		{

		}

		public override DataObject GetData()
		{
			DataObject data = base.GetData();
			data.Remove<string>("processingText");
			return data;
		}

		public override bool CanProcess
		{
			get
			{
				return this.dialogueTags.CanUse &&
					this.messageTags.CanUse &&
					!string.IsNullOrEmpty(this.processingText);
			}
		}

		public override bool CanPreprocessText
		{
			get { return !string.IsNullOrEmpty(this.processingText); }
		}

		public override void PreprocessText()
		{
			this.processingText = this.GetPreprocessedText();
		}

		public virtual string GetPreprocessedText()
		{
			string tmpProcessingText = this.processingText;
			if(this.unifiedNewLine)
			{
				tmpProcessingText = tmpProcessingText.Replace("\r\n", "\n").Replace("\r", "\n");
			}
			if(this.trimSpaces)
			{
				char[] trimming = new char[] { ' ' };
				string[] tmp = tmpProcessingText.Split(new string[] { "\n" }, System.StringSplitOptions.None);
				for(int i = 0; i < tmp.Length; i++)
				{
					tmp[i] = tmp[i].Trim(trimming);
				}
				tmpProcessingText = string.Join("\n", tmp);
			}
			if(this.trimTabs)
			{
				char[] trimming = new char[] { '\t' };
				string[] tmp = tmpProcessingText.Split(new string[] { "\n" }, System.StringSplitOptions.None);
				for(int i = 0; i < tmp.Length; i++)
				{
					tmp[i] = tmp[i].Trim(trimming);
				}
				tmpProcessingText = string.Join("\n", tmp);
			}
			return tmpProcessingText;
		}

		public virtual string TrimEmptyLines(string text)
		{
			if(this.trimEmptyLines &&
				!string.IsNullOrEmpty(text))
			{
				List<string> tmp = new List<string>(text.Split(new string[] { "\n" }, System.StringSplitOptions.None));
				int lastContent = -1;
				for(int i = 0; i < tmp.Count; i++)
				{
					if(string.IsNullOrEmpty(tmp[i]))
					{
						if(i == 0)
						{
							tmp.RemoveAt(i--);
						}
					}
					else
					{
						lastContent = i;
					}
				}
				lastContent += 1;
				if(lastContent < tmp.Count)
				{
					tmp.RemoveRange(lastContent, tmp.Count - lastContent);
				}
				if(tmp.Count == 0)
				{
					return "";
				}
				else if(tmp.Count == 1)
				{
					return tmp[0];
				}
				else
				{
					return string.Join("\n", tmp);
				}
			}
			return text;
		}

		public override DialogueImportContent ProcessText()
		{
			if(!string.IsNullOrEmpty(this.processingText))
			{
				try
				{
					string tmpProcessingText = this.GetPreprocessedText();

					this.dialogueTags.Preprocess();
					this.titleTags.Preprocess();
					this.messageTags.Preprocess();
					this.choiceTags.Preprocess();

					DialogueImportContent content = new DialogueImportContent();

					List<DialogueImport_Speaker> speakers = new List<DialogueImport_Speaker>();
					List<DialogueImport_Dialogue> dialogues = new List<DialogueImport_Dialogue>();

					int currentIndex = 0;

					while(currentIndex >= 0 &&
						currentIndex < tmpProcessingText.Length)
					{
						string dialogueData = this.dialogueTags.FindNext(ref tmpProcessingText, ref currentIndex);
						// no further dialogue
						if(string.IsNullOrEmpty(dialogueData))
						{
							break;
						}
						// process dialogue
						else
						{
							string message = this.TrimEmptyLines(this.messageTags.CanUse ? this.messageTags.FindAndRemove(ref dialogueData) : "");
							DialogueImport_Dialogue newDialogue = new DialogueImport_Dialogue(message);
							dialogues.Add(newDialogue);

							// title
							string title = this.TrimEmptyLines(this.titleTags.CanUse ? this.titleTags.FindAndRemove(ref dialogueData) : "");
							if(!string.IsNullOrEmpty(title))
							{
								int speakerID = -1;
								// find speaker
								for(int i = 0; i < speakers.Count; i++)
								{
									if(speakers[i].foundTitle == title)
									{
										speakerID = i;
										break;
									}
								}
								// new speaker
								if(speakerID < 0)
								{
									DialogueImport_Speaker newSpeaker = new DialogueImport_Speaker(title);
									speakerID = speakers.Count;
									speakers.Add(newSpeaker);
								}
								// set speaker
								if(speakerID >= 0)
								{
									newDialogue.useSpeaker = true;
									newDialogue.speakerID = speakerID;
								}
							}
							// choices
							if(this.choiceTags.CanUse)
							{
								List<DialogueImport_Choice> choices = new List<DialogueImport_Choice>();
								string choiceData = this.TrimEmptyLines(this.choiceTags.FindAndRemove(ref dialogueData));
								while(!string.IsNullOrEmpty(choiceData))
								{
									choices.Add(new DialogueImport_Choice(choiceData));
									choiceData = this.TrimEmptyLines(this.choiceTags.FindAndRemove(ref dialogueData));
								}

								if(choices.Count > 0)
								{
									newDialogue.choice = choices.ToArray();
								}
							}
						}
					}

					content.speakers = speakers.ToArray();
					content.dialogues = dialogues.ToArray();
					content.SetNextDialogues(this.choiceAutoNextDialogue);
					return content;
				}
				catch(System.Exception ex)
				{
					Debug.LogWarning("An issue occured while processing the dialogue text.\n" +
						ex.Message + ":\n" + ex.StackTrace);
				}
			}
			return null;
		}

		public class MarkupTags : BaseData
		{
			[EditorHelp("Start Tag", "The tag at the beginning of the content.")]
			[EditorWidth(true)]
			[EditorInfo(isStandardTextArea = true)]
			public string startTag = "";

			[EditorHelp("End Tag", "The tag at the end of the content.")]
			[EditorWidth(true)]
			[EditorInfo(isStandardTextArea = true)]
			public string endTag = "";

			protected string usedStartTag = "";

			protected string usedEndTag = "";

			public MarkupTags()
			{

			}

			public MarkupTags(string startTag, string endTag)
			{
				this.startTag = startTag;
				this.endTag = endTag;
			}

			public virtual bool CanUse
			{
				get
				{
					return !string.IsNullOrEmpty(this.startTag) &&
						!string.IsNullOrEmpty(this.endTag);
				}
			}

			public virtual void Preprocess()
			{
				this.usedStartTag = this.startTag.Replace("\r\n", "\n").Replace("\r", "\n");
				this.usedEndTag = this.endTag.Replace("\r\n", "\n").Replace("\r", "\n");
			}

			public virtual string FindNext(ref string text, ref int currentIndex)
			{
				int startIndex = text.IndexOf(this.usedStartTag, currentIndex, System.StringComparison.Ordinal);
				if(startIndex >= 0)
				{
					startIndex += this.usedStartTag.Length;
					currentIndex = startIndex;
					int endIndex = text.IndexOf(this.usedEndTag, startIndex, System.StringComparison.Ordinal);
					if(endIndex >= 0)
					{
						currentIndex = endIndex + 1;
						return text.Substring(startIndex, endIndex - startIndex);
					}
					else
					{
						Debug.LogWarning("Warning! Start tag ('" + this.startTag + "') used without an end tag ('" + this.endTag + "').");
					}
				}
				return "";
			}

			public virtual string FindAndRemove(ref string text)
			{
				int startIndex = text.IndexOf(this.usedStartTag, System.StringComparison.Ordinal);
				if(startIndex >= 0)
				{
					int originalStartIndex = startIndex;
					startIndex += this.usedStartTag.Length;
					int endIndex = text.IndexOf(this.usedEndTag, startIndex, System.StringComparison.Ordinal);
					if(endIndex >= 0)
					{
						string found = text.Substring(startIndex, endIndex - startIndex);
						text = text.Remove(originalStartIndex, endIndex + this.usedEndTag.Length - originalStartIndex);
						return found;
					}
					else
					{
						Debug.LogWarning("Warning! Start tag ('" + this.startTag + "') used without an end tag ('" + this.endTag + "').");
					}
				}
				return "";
			}
		}
	}
}
