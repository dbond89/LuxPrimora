﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class SettingInfo
	{
		// info
		public GUIContent content;

		public string listName;

		public int sortIndex = -1;


		// type
		public System.Type type;

		public string typeString;

		public SettingInfo(System.Type type)
		{
			this.type = type;
			this.typeString = this.type.ToString();
			if(this.type.IsGenericType)
			{
				this.typeString = ReflectionTypeHandler.GetGenericTypeName(this.type);
			}

			this.content = new GUIContent(this.type.Name, "");
			this.listName = this.content.text;
		}

		public SettingInfo(System.Type type, EditorSettingInfoAttribute info)
		{
			this.type = type;
			this.typeString = this.type.ToString();
			if(this.type.IsGenericType)
			{
				this.typeString = ReflectionTypeHandler.GetGenericTypeName(this.type);
			}

			this.content = info.content;
			this.listName = info.listName;
			this.sortIndex = info.sortIndex;
		}
	}
}
