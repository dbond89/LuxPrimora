
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor.Packages;
using UnityEngine;
using UnityEditor;

namespace GamingIsLove.Makinom.Editor
{
	public sealed class AboutTab : BaseEditorTab
	{
		private bool projectChangeMode = false;

		private MakinomProjectAsset projectAsset;

		public AboutTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "About"; }
		}

		public override string HelpText
		{
			get
			{
				return "Makinom version information and details about your project.\n" +
					"You can also change the opened project asset.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		protected override BaseSettings Settings
		{
			get { return null; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return null; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		private void DownloadFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
		{
			if(e.Error == null)
			{
				AssetDatabase.Refresh();
				AssetDatabase.ImportPackage("Assets/SamplePlugin.unitypackage", true);
			}
		}

		public override void ShowSettings()
		{
			if(this.BeginFoldout("Makinom Information", "Displays information about Makinom.", "", true))
			{
				EditorGUILayout.BeginHorizontal();
				if(!this.Editor.ShowLogo())
				{
					EditorTool.BoldLabel("Makinom");
				}

				EditorGUILayout.Separator();
				EditorGUILayout.BeginVertical();
				EditorTool.Separator(5);
#if Unity_2019
				EditorTool.BoldLabel("Version: " + Maki.VERSION + " for Unity 2019/2020/2021/2022");
#else
				EditorTool.BoldLabel("Version: " + Maki.VERSION);
#endif
				EditorTool.Label("� 2020 Gaming is Love e.U. All rights reserved.");

				EditorGUILayout.Separator();

				EditorTool.BoldLabel("Full Licence");

				EditorTool.Separator(4);

				// buttons
				EditorGUILayout.BeginHorizontal();
				if(EditorTool.MediumButton("Visit Website", "Opens the Makinom website in your default browser.", ""))
				{
					Application.OpenURL("https://makinom.com/");
				}
				if(EditorTool.MediumButton("Getting Started", "Opens the Makinom getting started documentation (online) in your default browser.", ""))
				{
					Application.OpenURL("https://makinom.com/guide/documentation/getting-started/introduction/");
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorGUILayout.BeginHorizontal();
				if(EditorTool.MediumButton("Documentation", "Opens the Makinom documentation (online) in your default browser.", ""))
				{
					Application.OpenURL("https://makinom.com/guide/documentation/");
				}
				if(EditorTool.MediumButton("Tutorials", "Opens the Makinom tutorials (online) in your default browser.", ""))
				{
					Application.OpenURL("https://makinom.com/guide/tutorials/");
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorGUILayout.BeginHorizontal();
				if(EditorTool.MediumButton("Extensions", "Opens the Makinom extensions (online) in your default browser.", ""))
				{
					Application.OpenURL("https://makinom.com/guide/extensions/");
				}
				if(EditorTool.MediumButton("Extension Manager", "Download and import plugins, custom nodes, scripts or schematics.\n" +
					"Opens the Makinom Extension Manager window.\n" +
					"Please make sure to save your Makinom project before importing any extensions.", ""))
				{
					MakinomExtensionManager.ShowExtensionManager();
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorTool.Separator(1);

				EditorGUILayout.BeginHorizontal();
				if(EditorTool.MediumButton("Community Forum", "Get help, give help or show your work - join the Community!\n" +
					"Opens the Makinom forum in your default browser.", ""))
				{
					Application.OpenURL("https://forum.orkframework.com/");
				}
				if(EditorTool.MediumButton("Contact (email)", "Send me an email!\n" +
					"Let me know if you have any problems, " +
					"feature requests or just want to tell me how awesome Makinom is!", ""))
				{
					Application.OpenURL("mailto:contact@makinom.com");
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorTool.Separator(4);


				// project asset
				EditorTool.BoldLabel("Loaded Project Asset");
				if(this.projectChangeMode)
				{
					this.projectAsset = (MakinomProjectAsset)EditorGUILayout.ObjectField("Project Asset",
						this.projectAsset, typeof(MakinomProjectAsset), false, EditorTool.WIDTH);

					EditorGUILayout.BeginHorizontal();
					if(EditorTool.MediumButton("Load Project",
						"Loads the selected project asset file.", ""))
					{
						if(EditorUtility.DisplayDialog("Load Project",
							"Do you really want to load this project asset:\n" +
							AssetDatabase.GetAssetPath(this.projectAsset) + "\n\n" +
							"Unsaved data will be lost.",
							"Load", "Cancel"))
						{
							Maki.Data.ProjectAsset = this.projectAsset;
							this.projectAsset = null;
							this.projectChangeMode = false;
							GUI.changed = true;
						}
						this.Editor.Focus();
					}
					if(EditorTool.MediumButton("Cancel",
						"Cancels loading another project file.", ""))
					{
						this.projectAsset = null;
						this.projectChangeMode = false;
						GUI.changed = true;
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					// project asset
					EditorGUILayout.LabelField("Currently Loaded", AssetDatabase.GetAssetPath(Maki.Data.ProjectAsset));
					EditorGUILayout.LabelField("Last Change", Maki.Data.ProjectAsset.SaveTime);

					EditorGUILayout.BeginHorizontal();
					if(EditorTool.MediumButton("Load Other Project",
						"Loads a different project asset file.", ""))
					{
						this.projectAsset = null;
						this.projectChangeMode = true;
						GUI.changed = true;
					}
					if(EditorTool.MediumButton("Create New Project",
						"Opens a save file dialogue to create a new project asset file.", ""))
					{
						if(EditorUtility.DisplayDialog("New Project",
							"Do you really want to create a new project asset?\n" +
							"Unsaved data will be lost.",
							"Create", "Cancel"))
						{
							string path = EditorUtility.SaveFilePanelInProject("Save Project Asset", "", "asset",
								"Please enter the name of the project asset file that will be created.\n" +
								"Existing files will be replaced!");
							if(path != "")
							{
								Maki.Data.ProjectAsset = MakinomAssetHelper.CreateProjectAsset(path);
								this.projectAsset = null;
								this.projectChangeMode = false;
								GUI.changed = true;
							}
						}
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}

				EditorGUILayout.EndVertical();
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorGUILayout.Separator();
			}
			this.EndFoldout();

			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				EditorContent.Extensions[i].ShowAbout(this);
			}


			if(this.BeginFoldout("Sponsors", "Check out this awesome people who support the further development of Makinom!\n" +
				"You can also become a patron on patreon.com and get awesome rewards in return.", "", true))
			{
				EditorTool.BoldLabel("Thanks to my patrons for supporting me!");
				EditorGUILayout.HelpBox(
					"You can also become a sponsor to support the further development of Makinom - and get awesome rewards in return!",
					MessageType.Info, true);

				if(EditorTool.Button("Become a Patron", "Opens my patreon.com page.\n" +
					"Please consider supporting me me as a patron, so that I can continue to provide free updates, " +
					"tutorials and support to anyone who needs it - every little bit helps!", ""))
				{
					Application.OpenURL("https://patreon.com/gamingislove/");
				}
				EditorGUILayout.Separator();

				string[] patrons = EditorContent.Instance.Patrons;
				for(int i = 0; i < patrons.Length; i++)
				{
					EditorTool.Label(patrons[i]);
				}
				EditorGUILayout.Separator();
			}
			this.EndFoldout();
		}
	}
}

