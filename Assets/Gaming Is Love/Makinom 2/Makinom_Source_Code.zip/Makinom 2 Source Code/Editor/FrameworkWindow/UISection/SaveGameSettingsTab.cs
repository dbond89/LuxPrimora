
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;

namespace GamingIsLove.Makinom.Editor
{
	public class SaveGameSettingsTab : BaseEditorTab
	{
		public SaveGameSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Save Game Settings"; }
		}

		public override string HelpText
		{
			get { return "Set up save game related settings and the save game UI."; }
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/save-games/"; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.SaveGameSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.SaveGameSettings; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "check:variables")
			{
				SaveGameSettings settings = Maki.SaveGameSettings;
				if(Selector.None == settings.variableSelector)
				{
					settings.variableList = null;
				}
				else
				{
					if(settings.variableList == null)
					{
						settings.variableList = new string[0];
					}
					if(Selector.Select == settings.variableSelector)
					{
						EditorTool.BoldLabel("Include Variables");
					}
					else if(Selector.All == settings.variableSelector)
					{
						EditorTool.BoldLabel("Exclude Variables");
					}
				}
			}
			else if(info == "extension:savegamedata")
			{
				for(int i = 0; i < EditorContent.Extensions.Count; i++)
				{
					if(EditorContent.Extensions[i].SaveGameDataSettings != null)
					{
						EditorAutomation.Automate(EditorContent.Extensions[i].SaveGameDataSettings, this);
					}
				}
			}
			else if(info == "extension:playerprefsgameoptions")
			{
				for(int i = 0; i < EditorContent.Extensions.Count; i++)
				{
					if(EditorContent.Extensions[i].PlayerPrefsGameOptionsSettings != null)
					{
						EditorTool.Separator(1);
						EditorAutomation.Automate(EditorContent.Extensions[i].PlayerPrefsGameOptionsSettings, this);
					}
				}
			}
			else if(info == "extension:fileinfo")
			{
				for(int i = 0; i < EditorContent.Extensions.Count; i++)
				{
					EditorContent.Extensions[i].ShowSaveGameFileInfo();
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}

