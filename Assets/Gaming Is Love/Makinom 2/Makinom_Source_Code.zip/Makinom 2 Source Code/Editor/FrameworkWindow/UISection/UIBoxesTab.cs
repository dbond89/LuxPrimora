
using GamingIsLove.Makinom.UI;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class UIBoxesTab : GenericAssetListTab<UIBoxAsset, UIBoxSetting>
	{
		public UIBoxesTab(MakinomEditorWindow parent) : base(parent)
		{

		}

		public override void DefaultSetup()
		{
			base.DefaultSetup();
			if(Maki.Data.ProjectAsset.IsEmpty)
			{
				Maki.UIBoxes.controls.horizontalAxis.Source.EditorAsset = Maki.InputKeys.GetAsset(0);
				Maki.UIBoxes.controls.verticalAxis.Source.EditorAsset = Maki.InputKeys.GetAsset(1);
				Maki.UIBoxes.controls.acceptKey.Source.EditorAsset = Maki.InputKeys.GetAsset(2);
				Maki.UIBoxes.controls.cancelKey.Source.EditorAsset = Maki.InputKeys.GetAsset(3);
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "UI Boxes"; }
		}

		public override string HelpText
		{
			get
			{
				return "UI boxes are used to display dialogues.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/ui-system/ui-boxes/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings that are used by all individual UI boxes.\n" +
					"The default settings can optionally be overridden by each UI box individually.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return Maki.UIBoxes; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return Maki.UIBoxes;
				}
				return base.DisplayedSettings;
			}
		}

		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<UILayerAsset, UILayerSetting>(
							new string[] { "UI Layer", "Filter the UI box list by UI layer.", "" }));
				}
				return this.filter;
			}
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override bool CheckFilterCondition(int index)
		{
			return this.Filter.assetFilterSelection[0].Check(
				this.assetList.Assets[index].Settings.layer.Source.EditorAsset);
		}
	}
}
