
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class MachineTemplatesTab : GenericAssetListTab<MachineTemplateAsset, MachineTemplate>
	{
		public MachineTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Machine Templates"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up reusable templates for machine components.\n" +
					"They're used by 'Template Machine' components and add the defined machine to the game object.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/machines/template-machine/"; }
		}
	}
}
