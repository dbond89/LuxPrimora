
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class InputKeysTab : GenericAssetListTab<InputKeyAsset, InputKey>
	{
		public InputKeysTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.InputKeys.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.InputKeys.SetAssets(this.assetList.Assets);
		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				this.assetList.Add(InputKeysTab.CreateAsset("Horizontal Menu", KeyCode.RightArrow, KeyCode.LeftArrow, InputHandling.Hold));
				this.assetList.Add(InputKeysTab.CreateAsset("Vertical Menu", KeyCode.UpArrow, KeyCode.DownArrow, InputHandling.Hold));
				this.assetList.Add(InputKeysTab.CreateAsset("Accept", KeyCode.Return, KeyCode.None, InputHandling.Down));
				this.assetList.Add(InputKeysTab.CreateAsset("Cancel", KeyCode.Escape, KeyCode.None, InputHandling.Down));
				this.assetList.Add(InputKeysTab.CreateAsset("Horizontal Move", KeyCode.D, KeyCode.A, InputHandling.Hold));
				this.assetList.Add(InputKeysTab.CreateAsset("Vertical Move", KeyCode.W, KeyCode.S, InputHandling.Hold));
			}
		}

		protected static InputKeyAsset CreateAsset(string name, KeyCode positiveKey, KeyCode negativeKey, InputHandling handling)
		{
			InputKeyAsset asset = ScriptableObject.CreateInstance<InputKeyAsset>();
			asset.Settings = new InputKey(name, positiveKey, negativeKey, handling);
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Input Keys"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up input from different sources to be used in Makinom.\n" +
					"You can use local multiplayer or switch between different control styles " +
					"by using 'Input IDs' to set up different controls per input key.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/input-keys/"; }
		}
	}
}
