
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SpawnPoint))]
public class SpawnPointInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as SpawnPoint);
	}

	private void ComponentSetup(SpawnPoint target)
	{
		Undo.RecordObject(target, "Change to 'Spawn Point' on " + target.name);
		this.BaseInit(false);

		if(target.HasCollider())
		{
			EditorGUILayout.HelpBox("Spawns at a random position within the bounds of the attached collider.\n" +
				"The 'Place On Ground' settings will be used to find the ground for the " +
				"individual random positions instead of placing the spawn point on the ground.",
				MessageType.Info);
		}
		else
		{
			EditorGUILayout.HelpBox("Spawns at this game object's position.\n" +
				"Add a collider to spawn at a random position within an area.",
				MessageType.Info);
		}

		target.SceneID = EditorGUILayout.IntField("Spawn ID", target.SceneID);
		if(target.SceneID < 0)
		{
			target.SceneID = 0;
		}
		EditorGUILayout.BeginHorizontal();
		if(GUILayout.Button("Get New Spawn ID") ||
			target.SceneID == -1)
		{
			SceneObjectHelper.SetNextSceneID(target);
		}
		if(GUILayout.Button("Reset All Spawn IDs"))
		{
			SceneObjectHelper.ResetAllSceneIDs<SpawnPoint>();
		}
		EditorGUILayout.EndHorizontal();

		EditorGUILayout.Separator();

		EditorAutomation.Automate(target.settings, this.baseEditor);

		EditorGUILayout.Separator();

		this.EndSetup();
	}
}