
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(AnimationMachineComponent))]
public class AnimationMachineInspector : BaseMachineInspector
{
	public override void OnInspectorGUI()
	{
		this.MachineSetup(target as AnimationMachineComponent);
	}

	private void MachineSetup(AnimationMachineComponent target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Animation Machine' on " + target.name);
		this.BaseInit(true);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.BaseMachineSetup(target);

		this.EndSetup();
	}
}
