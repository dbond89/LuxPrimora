﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	[CustomEditor(typeof(ObjectChanges))]
	public class ObjectChangesInspector : BaseInspector
	{
		public override void OnInspectorGUI()
		{
			this.ShowSettings((ObjectChanges)target);
		}

		public virtual void ShowSettings(ObjectChanges target)
		{
			EditorGUILayout.HelpBox("Calculates speed and other changes of a game object.\n" + 
				"Automatically added in 'Auto' mode if not yet on a game object and requested by Makinom.",
				MessageType.Info);

			this.ShowSettings(target.settings, false);

			if(Application.isPlaying)
			{
				if(target.IsUpdate)
				{
					EditorGUILayout.Separator();
					EditorTool.BoldLabel("Update Changes");
					this.ShowChanges(target.GetChanges(MachineUpdateType.Update));
				}
				if(target.IsLateUpdate)
				{
					EditorGUILayout.Separator();
					EditorTool.BoldLabel("Late Update Changes");
					this.ShowChanges(target.GetChanges(MachineUpdateType.LateUpdate));
				}
				if(target.IsFixedUpdate)
				{
					EditorGUILayout.Separator();
					EditorTool.BoldLabel("Fixed Update Changes");
					this.ShowChanges(target.GetChanges(MachineUpdateType.FixedUpdate));
				}
			}
		}

		protected virtual void ShowChanges(ObjectChanges.Changes changes)
		{
			EditorGUILayout.LabelField("Horizontal Speed", changes.horizontalSpeed.ToString());
			EditorGUILayout.LabelField("Vertical Speed", changes.verticalSpeed.ToString());
			EditorGUILayout.LabelField("Position Change", changes.positionChange.ToString());
			EditorGUILayout.LabelField("Rotation Change", changes.rotationChange.ToString());
			EditorGUILayout.LabelField("Scale Change", changes.scaleChange.ToString());
		}
	}
}

