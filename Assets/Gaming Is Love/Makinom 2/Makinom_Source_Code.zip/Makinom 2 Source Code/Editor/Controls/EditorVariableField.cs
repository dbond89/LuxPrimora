
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorVariableField
	{
		private MakinomEditorWindow parent;


		// value
		private string originalValue = "";

		private string nextValue = "";

		private bool setNextValue = false;


		// popup
		private Rect lastBounds;

		private bool firstUse = true;

		private bool isInspector = false;

		public EditorVariableField()
		{

		}

		public void Edit(GUIContent content, ref string value, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			if(this.setNextValue &&
				Event.current.type == EventType.Repaint)
			{
				this.setNextValue = false;
				value = this.nextValue;
				this.nextValue = "";
				GUI.FocusControl("");
				GUI.changed = true;
			}

			if(this.parent == null &&
				baseEditor != null &&
				!baseEditor.isInspector)
			{
				this.parent = baseEditor is BaseEditorTab ?
					((BaseEditorTab)baseEditor).Editor :
					MakinomEditorWindow.Instance;
			}

			// layout
			GUIContent title = content;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				if(attributes != null &&
					attributes.width != null &&
					attributes.width.hideName)
				{
					layout = GUILayout.MaxWidth(Screen.width - EditorGUIUtility.labelWidth - 130);
				}
				else
				{
					layout = attributes.width.GetWidth();
				}
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", title.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
				this.isInspector = true;
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", title.tooltip);
				}
				layout = attributes.width.GetWidth();
			}

			// field
			EditorGUILayout.BeginHorizontal();
			EditorTool.BeginSetting(content.text, false);

			string tmpValue = value;
			value = EditorGUILayout.TextField(title, value, layout);

			if(Maki.EditorSettings.autoVariablePopup)
			{
				// cancel value
				if(this.firstUse &&
					tmpValue != value)
				{
					this.firstUse = false;
					this.originalValue = tmpValue;
				}

				if(GUI.GetNameOfFocusedControl() == content.text)
				{
					if(Event.current.type == EventType.Repaint)
					{
						this.lastBounds = GUILayoutUtility.GetLastRect();
						this.lastBounds.height = 0;
					}
					else if(Event.current.type == EventType.KeyUp &&
						Event.current.keyCode != KeyCode.Return &&
						Event.current.keyCode != KeyCode.KeypadEnter)
					{
						if(this.firstUse)
						{
							this.firstUse = false;
							this.originalValue = tmpValue;
						}
						int textCursor = -1;
						int textSelection = -1;
						TextEditor editor = EditorReflection.Instance.GetTextEditor();
						if(editor != null)
						{
							textCursor = editor.cursorIndex;
							textSelection = editor.selectIndex;
						}

						PopupWindow.Show(this.lastBounds,
							new PopupListWindow(value, this.UpdatePopupList(value, baseEditor), this.lastBounds.width,
								EditorGUIUtility.GUIToScreenPoint(new Vector2(this.lastBounds.x, this.lastBounds.y)),
								textCursor, textSelection,
								this.ValueSelected, this.PopupCanceled, this.PopupClosed, this.UpdatePopupList, baseEditor));
						Event.current.Use();
					}
				}
			}

			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, false);

			// popup
			if(EditorTool.Button(EditorContent.Instance.EditIcon, EditorTool.WIDTH_30))
			{
				List<string> foundVariables = EditorVariables.Instance.Find(value, false);
				List<string> localVariables = new List<string>();
				baseEditor.GetLocalVariables(ref localVariables, value);

				if(foundVariables.Count > 0 ||
					localVariables.Count > 0)
				{
					GenericMenu popup = new GenericMenu();
					if(localVariables.Count > 0)
					{
						localVariables.Sort();
						for(int i = 0; i < localVariables.Count; i++)
						{
							foundVariables.Remove(localVariables[i]);
							popup.AddItem(new GUIContent("Local/" + localVariables[i]), false, this.ContextSelected, localVariables[i]);
						}
					}
					for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
					{
						if(EditorBuildSettings.scenes[i].enabled &&
							EditorBuildSettings.scenes[i].path != "")
						{
							string sceneName = System.IO.Path.GetFileNameWithoutExtension(EditorBuildSettings.scenes[i].path);
							if(sceneName.IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
							{
								foundVariables.Remove(sceneName);
								popup.AddItem(new GUIContent("Scenes/" + sceneName), false, this.ContextSelected, sceneName);
							}
						}
					}
					for(int i = 0; i < foundVariables.Count; i++)
					{
						popup.AddItem(new GUIContent(foundVariables[i]), false, this.ContextSelected, foundVariables[i]);
					}
					popup.ShowAsContext();
				}
			}

			EditorGUILayout.EndHorizontal();
		}

		private void ContextSelected(System.Object userData)
		{
			if(userData is string)
			{
				this.setNextValue = true;
				this.nextValue = (string)userData;
			}
		}

		private void ValueSelected(string value)
		{
			this.setNextValue = true;
			this.nextValue = value;
		}

		private void PopupCanceled()
		{
			this.setNextValue = true;
			this.nextValue = this.originalValue;
		}

		private void PopupClosed()
		{
			this.firstUse = true;
			if(!EditorVariables.Instance.temporary.Contains(this.nextValue))
			{
				EditorVariables.Instance.temporary.Add(this.nextValue);
			}
			if(!this.isInspector &&
				this.parent != null)
			{
				this.parent.Focus();
			}
		}

		private List<string> UpdatePopupList(string value, BaseEditor baseEditor)
		{
			List<string> foundVariables = EditorVariables.Instance.Find(value, false);

			// add scenes
			if(EditorBuildSettings.scenes.Length > 0)
			{
				List<string> scenes = new List<string>();
				for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
				{
					if(EditorBuildSettings.scenes[i].enabled &&
						EditorBuildSettings.scenes[i].path != "")
					{
						string sceneName = System.IO.Path.GetFileNameWithoutExtension(EditorBuildSettings.scenes[i].path);
						if(sceneName.IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
						{
							scenes.Add(sceneName);
							foundVariables.Remove(sceneName);
						}
					}
				}
				if(scenes.Count > 0)
				{
					scenes.Sort();
					if(foundVariables.Count > 0)
					{
						scenes.Add(null);
					}
					foundVariables.InsertRange(0, scenes);
				}
			}

			// add local variables
			List<string> localVariables = new List<string>();
			baseEditor.GetLocalVariables(ref localVariables, value);
			if(localVariables.Count > 0)
			{
				localVariables.Sort();
				for(int i = 0; i < localVariables.Count; i++)
				{
					foundVariables.Remove(localVariables[i]);
				}
				if(foundVariables.Count > 0)
				{
					localVariables.Add(null);
				}
				foundVariables.InsertRange(0, localVariables);
			}

			return foundVariables;
		}
	}
}
