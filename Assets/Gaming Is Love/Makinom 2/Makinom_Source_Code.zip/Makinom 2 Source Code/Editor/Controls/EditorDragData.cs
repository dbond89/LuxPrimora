
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorDragData
	{
		public bool isDragging = false;

		public float lastMove = 0;

		public Rect rect = new Rect(0, 0, 0, 0);
		
		public EditorDragData()
		{

		}
	}
}
