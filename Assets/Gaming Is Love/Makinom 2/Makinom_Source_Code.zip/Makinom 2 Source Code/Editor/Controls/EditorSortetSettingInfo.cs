﻿
using UnityEngine;
using System.Collections.Generic;
using System;
using System.Reflection;
using System.Text;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorSortedSettingInfo
	{
		private List<SettingInfo> values;

		public string[] names;

		public string[] descriptions;

		public string infoHelpText;

		public EditorSortedSettingInfo(List<SettingInfo> values)
		{
			this.values = values;
			this.values.Sort(new SettingInfoSorter());

			StringBuilder builder = new StringBuilder();
			this.names = new string[this.values.Count];
			this.descriptions = new string[this.values.Count];
			for(int i = 0; i < this.values.Count; i++)
			{
				this.names[i] = this.values[i].listName;
				this.descriptions[i] = this.values[i].content.tooltip;
				builder.Append("\n\n- ").
					Append(this.values[i].content.text).Append(":\n").
					Append(this.values[i].content.tooltip);
			}
			this.infoHelpText = builder.ToString();
		}

		public int Count
		{
			get { return this.names != null ? this.names.Length : 0; }
		}

		public int GetIndex(string value)
		{
			if(this.values != null)
			{
				for(int i = 0; i < this.values.Count; i++)
				{
					if(this.values[i].typeString == value)
					{
						return i;
					}
				}
			}
			return -1;
		}

		public string GetValue(int index)
		{
			if(this.values != null &&
				index >= 0 &&
				index < this.values.Count)
			{
				return this.values[index].typeString;
			}
			return "";
		}

		public System.Type GetType(int index)
		{
			if(this.values != null &&
				index >= 0 &&
				index < this.values.Count)
			{
				return this.values[index].type;
			}
			return null;
		}

		private class SettingInfoSorter : IComparer<SettingInfo>
		{
			public SettingInfoSorter()
			{

			}

			public int Compare(SettingInfo x, SettingInfo y)
			{
				if(x.sortIndex >= 0 &&
					y.sortIndex < 0)
				{
					return -1;
				}
				else if(x.sortIndex < 0 &&
					y.sortIndex >= 0)
				{
					return 1;
				}
				else if(x.sortIndex == y.sortIndex)
				{
					string tmpX = x.listName.Contains("/") ?
						x.listName.Substring(0, x.listName.IndexOf("/")) :
						x.listName;

					string tmpY = y.listName.Contains("/") ?
						y.listName.Substring(0, y.listName.IndexOf("/")) :
						y.listName;

					int result = tmpX.CompareTo(tmpY);
					if(result == 0)
					{
						return x.listName.CompareTo(y.listName);
					}
					else
					{
						return result;
					}
				}
				else
				{
					return x.sortIndex.CompareTo(y.sortIndex);
				}
			}
		}
	}
}
