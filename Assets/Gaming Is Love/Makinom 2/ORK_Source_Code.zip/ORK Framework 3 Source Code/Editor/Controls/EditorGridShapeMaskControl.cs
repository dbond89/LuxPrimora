﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public static class EditorGridShapeMaskControl
	{
		private static int CellSize = 25;

		private static int CellOffset = 5;

		private static int CellCombined = 30;


		// GUIStyles
		private static GUIStyle frontLabelStyle;

		private static GUIStyle squareCellStyle;

		private static GUIStyle squareCellCenterStyle;

		private static GUIStyle hexagonalCellStyle;

		private static GUIStyle hexagonalCellCenterStyle;

		public static void Init()
		{
			if(EditorGridShapeMaskControl.frontLabelStyle == null)
			{
				System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();

				EditorGridShapeMaskControl.frontLabelStyle = new GUIStyle(GUI.skin.label);
				EditorGridShapeMaskControl.frontLabelStyle.alignment = TextAnchor.MiddleCenter;
				EditorGridShapeMaskControl.frontLabelStyle.fontStyle = FontStyle.Bold;

				// square grid cells
				EditorGridShapeMaskControl.squareCellStyle = new GUIStyle();
				EditorGridShapeMaskControl.squareCellStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.square_grid_cell.png",
					25, 25);
				EditorGridShapeMaskControl.squareCellStyle.onNormal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.square_grid_cell_selected.png",
					25, 25);
				EditorGridShapeMaskControl.squareCellStyle.fixedWidth = 25;
				EditorGridShapeMaskControl.squareCellStyle.fixedHeight = 25;
				EditorGridShapeMaskControl.squareCellStyle.border = new RectOffset(0, 0, 0, 0);
				EditorGridShapeMaskControl.squareCellStyle.overflow = new RectOffset(0, 0, 0, 0);

				EditorGridShapeMaskControl.squareCellCenterStyle = new GUIStyle(EditorGridShapeMaskControl.squareCellStyle);
				EditorGridShapeMaskControl.squareCellCenterStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.square_grid_cell_center.png",
					25, 25);
				EditorGridShapeMaskControl.squareCellCenterStyle.onNormal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.square_grid_cell_center_selected.png",
					25, 25);

				// hexagonal grid cells
				EditorGridShapeMaskControl.hexagonalCellStyle = new GUIStyle(EditorGridShapeMaskControl.squareCellStyle);
				EditorGridShapeMaskControl.hexagonalCellStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.hexagonal_grid_cell.png",
					25, 25);
				EditorGridShapeMaskControl.hexagonalCellStyle.onNormal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.hexagonal_grid_cell_selected.png",
					25, 25);

				EditorGridShapeMaskControl.hexagonalCellCenterStyle = new GUIStyle(EditorGridShapeMaskControl.squareCellStyle);
				EditorGridShapeMaskControl.hexagonalCellCenterStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.hexagonal_grid_cell_center.png",
					25, 25);
				EditorGridShapeMaskControl.hexagonalCellCenterStyle.onNormal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.hexagonal_grid_cell_center_selected.png",
					25, 25);
			}
		}

		public static void Edit(GridShapeMask mask)
		{
			if(mask != null &&
				mask.cell != null &&
				mask.cell.Length > 0)
			{
				EditorGridShapeMaskControl.Init();

				if(BattleGridType.Square == ORK.BattleGridSettings.type)
				{
					// legend
					EditorGUILayout.BeginHorizontal();

					EditorGUILayout.BeginVertical();
					GUILayout.Label(new GUIContent("Empty Cell", EditorGridShapeMaskControl.squareCellStyle.normal.background));
					GUILayout.Label(new GUIContent("Selected Cell", EditorGridShapeMaskControl.squareCellStyle.onNormal.background));
					EditorGUILayout.EndVertical();

					EditorGUILayout.BeginVertical();
					GUILayout.Label(new GUIContent("Empty Origin Cell", EditorGridShapeMaskControl.squareCellCenterStyle.normal.background));
					GUILayout.Label(new GUIContent("Selected Origin Cell", EditorGridShapeMaskControl.squareCellCenterStyle.onNormal.background));
					EditorGUILayout.EndVertical();

					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();

					EditorGUILayout.Separator();


					// grid display
					int positionOffset = 10 + mask.range * EditorGridShapeMaskControl.CellSize +
						(mask.range - 1) * EditorGridShapeMaskControl.CellOffset;
					int size = positionOffset * 2 + EditorGridShapeMaskControl.CellSize;

					GUILayout.Label("Front", EditorGridShapeMaskControl.frontLabelStyle, GUILayout.Width(size));
					Rect rect = GUILayoutUtility.GetRect(size, size);

					for(int i = 0; i < mask.cell.Length; i++)
					{
						if(mask.cell[i] != null)
						{
							int row = 0;
							int column = 0;
							mask.cell[i].coord.ToOffset(ref row, ref column);

							mask.cell[i].selected = EditorGUI.Toggle(
								new Rect(rect.x + positionOffset + column * EditorGridShapeMaskControl.CellCombined,
									rect.y + positionOffset + row * EditorGridShapeMaskControl.CellCombined,
									EditorGridShapeMaskControl.CellSize, EditorGridShapeMaskControl.CellSize),
								mask.cell[i].selected,
								mask.cell[i].coord.IsZero ? EditorGridShapeMaskControl.squareCellCenterStyle : EditorGridShapeMaskControl.squareCellStyle);
						}
					}
				}
				else if(BattleGridType.Hexagonal == ORK.BattleGridSettings.type)
				{
					EditorGUILayout.HelpBox("All hexagonal grids are displayed as vertical (flat topped) grids.\n" +
						"For horizontal grids, the world space front will be rotated to the left by 30°.",
						MessageType.None);

					// legend
					EditorGUILayout.BeginHorizontal();

					EditorGUILayout.BeginVertical();
					GUILayout.Label(new GUIContent("Empty Cell", EditorGridShapeMaskControl.hexagonalCellStyle.normal.background));
					GUILayout.Label(new GUIContent("Selected Cell", EditorGridShapeMaskControl.hexagonalCellStyle.onNormal.background));
					EditorGUILayout.EndVertical();

					EditorGUILayout.BeginVertical();
					GUILayout.Label(new GUIContent("Empty Origin Cell", EditorGridShapeMaskControl.hexagonalCellCenterStyle.normal.background));
					GUILayout.Label(new GUIContent("Selected Origin Cell", EditorGridShapeMaskControl.hexagonalCellCenterStyle.onNormal.background));
					EditorGUILayout.EndVertical();

					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();

					EditorGUILayout.Separator();


					// grid display
					int positionOffset = 10 + mask.range * EditorGridShapeMaskControl.CellSize +
						(mask.range - 1) * EditorGridShapeMaskControl.CellOffset;
					int size = positionOffset * 2 + EditorGridShapeMaskControl.CellSize;

					GUILayout.Label("Front", EditorGridShapeMaskControl.frontLabelStyle, GUILayout.Width(size));
					Rect rect = GUILayoutUtility.GetRect(size, size);

					int modFactor = (mask.range * 2 + 1) % 2 == 0 ? 1 : 0;

					for(int i = 0; i < mask.cell.Length; i++)
					{
						if(mask.cell[i] != null)
						{
							int row = 0;
							int column = 0;
							if(modFactor == 0)
							{
								mask.cell[i].coord.ToVerticalOdd(ref row, ref column);
							}
							else
							{
								mask.cell[i].coord.ToVerticalEven(ref row, ref column);
							}
							float colMod = (column + modFactor) % 2;

							bool tmp = mask.cell[i].selected;
							mask.cell[i].selected = EditorGUI.Toggle(
								new Rect(rect.x + positionOffset + column * EditorGridShapeMaskControl.CellCombined,
									rect.y + positionOffset + (row + (colMod * 0.5f)) * EditorGridShapeMaskControl.CellCombined,
									EditorGridShapeMaskControl.CellSize, EditorGridShapeMaskControl.CellSize),
								mask.cell[i].selected,
								mask.cell[i].coord.IsZero ? EditorGridShapeMaskControl.hexagonalCellCenterStyle : EditorGridShapeMaskControl.hexagonalCellStyle);
						}
					}
				}

				EditorTool.CheckHelpText("Grid Shape Mask", "Select the grid cells that will be used by this shape mask.", "");

				// all/none selection buttons
				EditorGUILayout.BeginHorizontal();
				if(EditorTool.MicroButton("All", "Selects all cells.", ""))
				{
					mask.SelectAll(true);
				}
				if(EditorTool.MicroButton("None", "Set all cells unselected.", ""))
				{
					mask.SelectAll(false);
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
			}
		}
	}
}
