
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class QuestTypesTab : ORKGenericAssetListTab<QuestTypeAsset, QuestType>
	{
		public QuestTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.QuestTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.QuestTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Quest Settings & Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up basic quest settings, e.g. notifications and layouts, " +
					"and define quest types that are used to separate quests in menus.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/quests/"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings regarding quests.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.QuestSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.QuestSettings;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
