﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public class ORKMakinomEditorExtension : MakinomEditorExtension
	{
		protected Texture2D logoTexture;

		public ORKMakinomEditorExtension()
		{

		}

		public override int Sorting
		{
			get { return 100; }
		}

		[MenuItem("Window/Gaming Is Love/ORK Framework (Makinom)", false, 2500)]
		public static void ShowMakinomEditor()
		{
			MakinomEditorWindow.ShowMakinomEditor();
		}


		/*
		============================================================================
		Editor window functions
		============================================================================
		*/
		protected virtual T GetTabWithSeparator<T>(T tab) where T : BaseEditorTab
		{
			tab.AddSeparator = true;
			return tab;
		}

		protected virtual T GetTabWithSeparator<T>(T tab, string headerText) where T : BaseEditorTab
		{
			tab.AddSeparator = true;
			return tab;
		}

		protected virtual T GetTabWithHeader<T>(T tab) where T : BaseEditorTab
		{
			tab.Header = "ORK Framework";
			return tab;
		}

		protected virtual T GetTabWithHeader<T>(T tab, string headerText) where T : BaseEditorTab
		{
			tab.Header = headerText;
			return tab;
		}

		public override void GetSections(MakinomEditorWindow parent, List<GUIContent> sectionHeaderList,
			List<BaseEditorSection> sectionList, Dictionary<string, BaseEditorSection> sectionLookup)
		{
			System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();

			// base/control section
			BaseEditorSection tmpSection = null;
			if(!sectionLookup.TryGetValue("Base/Control", out tmpSection))
			{
				sectionHeaderList.Add(new GUIContent("Base/Control", EditorContent.LoadImage(assembly,
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.Controls.png", 32, 32)));
				tmpSection = new BaseEditorSection(parent);
				sectionList.Add(tmpSection);
				sectionLookup.Add("Editor", tmpSection);
			}
			tmpSection.Tabs.Add(this.GetTabWithHeader(new ControlMapsTab(parent)));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new AnimationTypesTab(parent)));
			tmpSection.Tabs.Add(new AnimationsTab(parent));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new DamageTypesTab(parent)));


			// game section
			tmpSection = null;
			if(!sectionLookup.TryGetValue("Game", out tmpSection))
			{
				sectionHeaderList.Add(new GUIContent("Game", EditorContent.LoadImage(assembly,
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.Game.png", 32, 32)));
				tmpSection = new BaseEditorSection(parent);
				sectionList.Add(tmpSection);
				sectionLookup.Add("Game", tmpSection);
			}
			tmpSection.Tabs.Add(this.GetTabWithHeader(new DifficultiesTab(parent)));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new QuestTypesTab(parent)));
			tmpSection.Tabs.Add(new QuestsTab(parent));
			tmpSection.Tabs.Add(new QuestTasksTab(parent));
			// world
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new AreaTypesTab(parent)));
			tmpSection.Tabs.Add(new AreasTab(parent));
			tmpSection.Tabs.Add(new TeleportsTab(parent));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new LogTypesTab(parent)));
			tmpSection.Tabs.Add(new LogsTab(parent));
			tmpSection.Tabs.Add(new LogTextsTab(parent));


			// UI section
			tmpSection = null;
			if(!sectionLookup.TryGetValue("UI", out tmpSection))
			{
				sectionHeaderList.Add(new GUIContent("UI", EditorContent.LoadImage(assembly,
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.UI.png", 32, 32)));
				tmpSection = new BaseEditorSection(parent);
				sectionList.Add(tmpSection);
				sectionLookup.Add("UI", tmpSection);
			}
			tmpSection.Tabs.Add(this.GetTabWithHeader(new StartMenuTab(parent)));
			tmpSection.Tabs.Add(new MenuScreensTab(parent));
			tmpSection.Tabs.Add(new BattleMenusTab(parent));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new ShopLayoutsTab(parent)));
			tmpSection.Tabs.Add(new NotificationSettingsTab(parent));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new CombatantSelectionsTab(parent)));
			tmpSection.Tabs.Add(new QuantitySelectionsTab(parent));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new TextDisplaySettingsTab(parent)));
			tmpSection.Tabs.Add(new ShortcutSettingsTab(parent));
			tmpSection.Tabs.Add(new CursorSettingsTab(parent));
			tmpSection.Tabs.Add(new ConsoleTypesTab(parent));


			// template section
			tmpSection = null;
			if(!sectionLookup.TryGetValue("Templates", out tmpSection))
			{
				sectionHeaderList.Add(new GUIContent("Templates", EditorContent.LoadImage(assembly,
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.Templates.png", 32, 32)));
				tmpSection = new BaseEditorSection(parent);
				sectionList.Add(tmpSection);
				sectionLookup.Add("Templates", tmpSection);
			}
			tmpSection.Tabs.Add(this.GetTabWithHeader(new MenuRequirementsTab(parent)));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new StatusConditionTemplatesTab(parent)));
			tmpSection.Tabs.Add(new StatusBonusesTab(parent));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new BattleRangeTemplatesTab(parent)));
			tmpSection.Tabs.Add(this.GetTabWithSeparator(new AvailableEquipmentTemplatesTab(parent)));
			tmpSection.Tabs.Add(new EquipmentSlotSetTemplatesTab(parent));


			// status section
			sectionHeaderList.Add(new GUIContent("Status", EditorContent.LoadImage(assembly,
				"GamingIsLove.ORKFramework.Editor.Images.Icons.Sections.Status.png", 32, 32)));
			tmpSection = new BaseEditorSection(parent,
				new StatusTypesTab(parent), new StatusValuesTab(parent), new StatusDevelopmentsTab(parent),
				this.GetTabWithSeparator(new AttackModifiersTab(parent)), new DefenceModifiersTab(parent),
				this.GetTabWithSeparator(new StatusEffectTypesTab(parent)), new StatusEffectsTab(parent),
				this.GetTabWithSeparator(new AbilityTypesTab(parent)), new AbilitiesTab(parent), new AbilityDevelopmentsTab(parent));
			sectionList.Add(tmpSection);
			sectionLookup.Add("Status", tmpSection);


			// inventory section
			sectionHeaderList.Add(new GUIContent("Inventory", EditorContent.LoadImage(assembly,
				"GamingIsLove.ORKFramework.Editor.Images.Icons.Sections.Inventory.png", 32, 32)));
			tmpSection = new BaseEditorSection(parent,
				new InventorySettingsTab(parent), new InventoryContainersTab(parent),
				this.GetTabWithSeparator(new ItemTypesTab(parent)), new CurrenciesTab(parent), new ItemsTab(parent),
				this.GetTabWithSeparator(new EquipmentSlotsTab(parent)), new EquipmentTab(parent),
				this.GetTabWithSeparator(new AITypesTab(parent)), new AIBehavioursTab(parent), new AIRulesetsTab(parent),
				this.GetTabWithSeparator(new CraftingTypesTab(parent)), new CraftingRecipesTab(parent),
				this.GetTabWithSeparator(new ShopsTab(parent)));
			sectionList.Add(tmpSection);
			sectionLookup.Add("Inventory", tmpSection);


			// combatants section
			sectionHeaderList.Add(new GUIContent("Combatants", EditorContent.LoadImage(assembly,
				"GamingIsLove.ORKFramework.Editor.Images.Icons.Sections.Combatants.png", 32, 32)));
			tmpSection = new BaseEditorSection(parent,
				new FactionsTab(parent), new FactionBenefitsTab(parent),
				this.GetTabWithSeparator(new ClassSlotsTab(parent)), new ClassesTab(parent),
				this.GetTabWithSeparator(new CombatantTypesTab(parent)), new CombatantsTab(parent), new CombatantGroupsTab(parent),
				this.GetTabWithSeparator(new MoveAIsTab(parent)), new FormationsTab(parent), new LootTab(parent),
				this.GetTabWithSeparator(new ResearchTypesTab(parent)), new ResearchTreesTab(parent));
			sectionList.Add(tmpSection);
			sectionLookup.Add("Combatants", tmpSection);


			// battle system section
			sectionHeaderList.Add(new GUIContent("Battles", EditorContent.LoadImage(assembly,
				"GamingIsLove.ORKFramework.Editor.Images.Icons.Sections.BattleSystem.png", 32, 32)));
			tmpSection = new BaseEditorSection(parent,
				new BattleSystemsTab(parent), new BattleCameraTab(parent), new TargetSettingsTab(parent),
				new BattleSpotsTab(parent),
				this.GetTabWithSeparator(new BattleTextsTab(parent)), new BattleEndTab(parent),
				this.GetTabWithSeparator(new BattleAIsTab(parent)), new ActionCombosTab(parent),
				this.GetTabWithHeader(new BattleGridSettingsTab(parent), "Battle Grids"), new BattleGridHighlightsTab(parent),
				new BattleGridCellTypesTab(parent), new BattleGridFormationsTab(parent));
			sectionList.Add(tmpSection);
			sectionLookup.Add("Battle System", tmpSection);


			// default Makinom setup additions
			if(Maki.Data.ProjectAsset.IsEmpty)
			{
				// game states
				GenericAssetList<GameStateAsset> gameStates = EditorDataHandler.Instance.GetAssets<GameStateAsset>();
				gameStates.Add(GameStatesTab.CreateAsset(
					"In Battle", false,
						new GameStateChangeType[] { new GameStateChangeType(new BattleStartGameStateChangeType()) },
						new GameStateChangeType[] { new GameStateChangeType(new BattleEndGameStateChangeType()) }));
				gameStates.Add(GameStatesTab.CreateAsset(
					"In Menu", false,
						new GameStateChangeType[] { new GameStateChangeType(new MenuOpenGameStateChangeType()) },
						new GameStateChangeType[] { new GameStateChangeType(new MenuCloseGameStateChangeType()) }));
				gameStates.Add(GameStatesTab.CreateAsset(
					"In Shop", false,
						new GameStateChangeType[] { new GameStateChangeType(new ShopOpenGameStateChangeType()) },
						new GameStateChangeType[] { new GameStateChangeType(new ShopCloseGameStateChangeType()) }));
			}
		}

		public override void ShowAbout(AboutTab aboutTab)
		{
			if(aboutTab.BeginFoldout("ORK Framework Information", "Displays information about ORK.", "", true))
			{
				EditorGUILayout.BeginHorizontal();
				if(this.logoTexture == null)
				{
					this.logoTexture = EditorContent.LoadImage(
						System.AppDomain.CurrentDomain.GetAssemblies(),
						"GamingIsLove.ORKFramework.Editor.Images.ORK3_logo_300.png", 300, 150);
				}
				if(this.logoTexture != null)
				{
					GUILayout.Label(this.logoTexture);
				}

				EditorGUILayout.Separator();
				EditorGUILayout.BeginVertical();

#if Unity_2019
				EditorTool.BoldLabel("Version: " + ORK.VERSION + " for Unity 2019/2020/2021/2022");
#else
				EditorTool.BoldLabel("Version: " + ORK.VERSION);
#endif
				EditorTool.Label("© 2021 Gaming is Love e.U. All rights reserved.");

				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Full Licence");

				EditorTool.Separator(4);


				// buttons
				EditorGUILayout.BeginHorizontal();
				if(EditorTool.MediumButton("Visit Website", "Opens the ORK Framework website in your default browser.", ""))
				{
					Application.OpenURL("https://orkframework.com/");
				}
				if(EditorTool.MediumButton("Getting Started", "Opens the ORK Framework getting started documentation (online) in your default browser.", ""))
				{
					Application.OpenURL("https://orkframework.com/guide/documentation/getting-started/introduction/");
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorGUILayout.BeginHorizontal();
				if(EditorTool.MediumButton("Documentation", "Opens the ORK Framework documentation (online) in your default browser.", ""))
				{
					Application.OpenURL("https://orkframework.com/guide/documentation/");
				}
				if(EditorTool.MediumButton("Tutorials", "Opens the ORK Framework tutorials (online) in your default browser.", ""))
				{
					Application.OpenURL("https://orkframework.com/guide/tutorials/");
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorTool.Separator(1);

				EditorGUILayout.BeginHorizontal();
				if(EditorTool.MediumButton("Community Forum", "Get help, give help or show your work - join the ORK Community!", ""))
				{
					Application.OpenURL("https://forum.orkframework.com/");
				}
				if(EditorTool.MediumButton("Contact (email)", "Send us an email!\n" +
					"Let us know if you have any problems, " +
					"feature requests or just want to tell us how awesome ORK is!", ""))
				{
					Application.OpenURL("mailto:contact@orkframework.com");
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();


				EditorGUILayout.EndVertical();
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Separator();
			}
			aboutTab.EndFoldout();
		}


		/*
		============================================================================
		Setting extensions (display only)
		============================================================================
		*/
		public override IBaseData GameControls
		{
			get { return ORK.GameControls; }
		}

		public override IBaseData GameSettings
		{
			get { return ORK.GameSettings; }
		}

		public override IBaseData UISettings
		{
			get { return ORK.UISettings; }
		}

		public override IBaseData SaveGameDataSettings
		{
			get { return ORK.SaveGameSettings; }
		}

		public override IBaseData PlayerPrefsGameOptionsSettings
		{
			get { return ORK.SaveGameSettings.playerPrefsGameOptions; }
		}


		/*
		============================================================================
		Additional functions
		============================================================================
		*/
		public override void ShowSaveGameFileInfo()
		{
			EditorTool.BoldLabel("ORK Framework Information");
			EditorGUILayout.HelpBox("Player Combatant:\n" +
				"<playername> = name, <playerlevel> = level\n" +
				"<playerclass> = class, <playerclasslevel> = class level\n" +
				"Other Information:\n" +
				"<area> = current area",
				MessageType.Info);
		}

		// test
		private string formulaSingleResult = "";

		private List<string> formulaUserKeys = new List<string>();

		private List<string> formulaTargetKeys = new List<string>();

		private Dictionary<string, string> formulaResult = new Dictionary<string, string>();

		private FormulaTest formulaTest;

		private Vector2 resultScroll = Vector2.zero;

		public override void ShowFormulaTest(FormulasTab tab, FormulaAsset formula)
		{
			if(tab.BeginFoldout("Combatant Test", "Run a test calculation using defined combatants.", "", true))
			{
				if(this.formulaTest == null)
				{
					this.formulaTest = new FormulaTest();
				}

				if(this.formulaResult.Count == 0)
				{
					EditorGUILayout.LabelField("Result", this.formulaSingleResult);
				}
				else
				{
					// target headers
					EditorGUILayout.BeginHorizontal();
					GUILayout.Label("", EditorStyles.boldLabel, EditorTool.WIDTH_150);
					for(int j = 0; j < this.formulaTargetKeys.Count; j++)
					{
						GUILayout.Label(this.formulaTargetKeys[j], EditorStyles.boldLabel, EditorTool.WIDTH_150);
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();

					// user lines
					for(int i = 0; i < this.formulaUserKeys.Count; i++)
					{
						EditorGUILayout.BeginHorizontal();
						GUILayout.Label(this.formulaUserKeys[i], EditorStyles.boldLabel, EditorTool.WIDTH_150);

						for(int j = 0; j < this.formulaTargetKeys.Count; j++)
						{
							string key = this.formulaUserKeys[i] + ", " + this.formulaTargetKeys[j];

							GUILayout.Label(new GUIContent(this.formulaResult[key], key), EditorStyles.label, EditorTool.WIDTH_150);
						}
						GUILayout.FlexibleSpace();
						EditorGUILayout.EndHorizontal();
					}
				}
				if(EditorTool.Button("Calculate", "Calculate this formula using the defined combatants.", ""))
				{
					this.formulaTest.Calculate(formula, ref this.formulaSingleResult,
						this.formulaResult, this.formulaUserKeys, this.formulaTargetKeys);
				}

				EditorGUILayout.Separator();

				EditorAutomation.Automate(this.formulaTest, tab);

				EditorGUILayout.Separator();
			}
			tab.EndFoldout();
		}


		/*
		============================================================================
		Scene wizard functions
		============================================================================
		*/
		public override void ShowSceneWizard(SceneWizard wizard)
		{
			// overview
			if(SceneWizard.SceneWizardMode.Overview == wizard.Mode)
			{
				if(wizard.Button(new GUIContent("Add ORK Game Starter", wizard.GetCustomIcon("Assets/Gizmos/GamingIsLove/ORKFramework/Components/ORKGameStarter Icon.png"))))
				{
					wizard.SetProject();
					wizard.Mode = SceneWizard.SceneWizardMode.Custom;
					wizard.CustomMode = 1001;
				}
			}
			// custom
			else if(SceneWizard.SceneWizardMode.Custom == wizard.Mode)
			{
				// ORK game starter
				if(wizard.CustomMode == 1001)
				{
					wizard.ShowGameStarterSetup<ORKGameStarter>(wizard.GetCustomIcon("Assets/Gizmos/GamingIsLove/ORKFramework/Components/ORKGameStarter Icon.png"), "ORK Game Starter");
				}
			}
		}


		/*
		============================================================================
		Extension manager functions
		============================================================================
		*/
		public override void GetExtensionManagerFile(List<System.Uri> downloads, List<string> path)
		{
			downloads.Add(new System.Uri("https://orkframework.com/resources/downloads/ork3/ORK3ExtensionList.txt"));
			path.Add(MakinomAssetHelper.DOWNLOAD_PATH + "ORK3ExtensionList.txt");
		}


		/*
		============================================================================
		Editor general settings display
		Return true if found/used.
		============================================================================
		*/
		public override bool InstanceCallback(BaseEditor editor, string info, System.Object instance)
		{
			if(info == "button:AbilityLearnToAbilityDevelopment")
			{
				if(instance is LearnAbilitySetting)
				{
					LearnAbilitySetting learn = instance as LearnAbilitySetting;
					if(learn.atLevel.Length > 0)
					{
						EditorGUILayout.Separator();
						GenericAssetList<AbilityDevelopmentAsset> assetList = EditorDataHandler.Instance.GetAssets<AbilityDevelopmentAsset>();
						if(EditorTool.Button(new GUIContent("Create Ability Development", EditorContent.Instance.AddIcon),
							"Creates a new ability development using the defined abilities " +
							"and adds it to the combatant's ability development list.", ""))
						{
							AbilityDevelopmentAsset asset = ScriptableObject.CreateInstance<AbilityDevelopmentAsset>();
							asset.Settings = new AbilityDevelopment("New");
							asset.Settings.atLevel = learn.atLevel;
							assetList.Add(asset);

							AssetSelection<AbilityDevelopmentAsset> dev = new AssetSelection<AbilityDevelopmentAsset>();
							dev.Source.EditorAsset = asset;
							ArrayHelper.Add(ref learn.abilityDevelopment, dev);

							learn.atLevel = new LearnAbility[0];
						}
					}
				}
				return true;
			}
			else if(info == "button:CustomBattleRangeToTemplate")
			{
				if(instance is UseRange)
				{
					EditorGUILayout.Separator();
					GenericAssetList<BattleRangeTemplateAsset> assetList = EditorDataHandler.Instance.GetAssets<BattleRangeTemplateAsset>();
					if(EditorTool.Button(new GUIContent("Create Battle Range Template", EditorContent.Instance.AddIcon),
						"Creates a new battle range template using the defined range settings.", ""))
					{
						UseRange useRange = instance as UseRange;

						BattleRangeTemplateAsset asset = ScriptableObject.CreateInstance<BattleRangeTemplateAsset>();
						asset.Settings = new BattleRangeTemplate("New");
						asset.Settings.range = useRange.custom;
						assetList.Add(asset);

						useRange.type = BattleRangeType.Template;
						useRange.template = new AssetSelection<BattleRangeTemplateAsset>();
						useRange.template.Source.EditorAsset = asset;
					}
				}
				return true;
			}
			else if(info == "editor:GridShapeMask")
			{
				if(instance is GridRangeSetting)
				{
					GridRangeSetting range = instance as GridRangeSetting;
					if(GridShapeType.Mask == range.gridShapeType)
					{
						if(editor.BeginFoldout("Grid Mask", "Select the cells that will be used.", "", true))
						{
							if(EditorTool.Button("Create Mask", "Creates the mask using the defined range.", ""))
							{
								range.gridShapeMask = new GridShapeMask(range.gridRange);
							}
							EditorGridShapeMaskControl.Edit(range.gridShapeMask);
						}
						editor.EndFoldout();
					}
				}
				return true;
			}
			else if(info == "button:availableequipment:slots")
			{
				AvailableEquipment setting = instance as AvailableEquipment;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<EquipmentSlotAsset>> list = new List<AssetSelection<EquipmentSlotAsset>>();
						GenericAssetList<EquipmentSlotAsset> equipmentSlots = EditorDataHandler.Instance.GetAssets<EquipmentSlotAsset>();
						for(int i = 0; i < equipmentSlots.Count; i++)
						{
							AssetSelection<EquipmentSlotAsset> newSlot = new AssetSelection<EquipmentSlotAsset>();
							newSlot.Source.EditorAsset = equipmentSlots.Assets[i];
							list.Add(newSlot);
						}
						setting.equipSlot = list.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						setting.equipSlot = new AssetSelection<EquipmentSlotAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
				return true;
			}
			else if(info == "button:availableequipment:equipment")
			{
				AvailableEquipment setting = instance as AvailableEquipment;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all equipment.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<EquipmentAsset>> equips = new List<AssetSelection<EquipmentAsset>>();
						GenericAssetList<EquipmentAsset> equipment = EditorDataHandler.Instance.GetAssets<EquipmentAsset>();
						for(int i = 0; i < equipment.Count; i++)
						{
							AssetSelection<EquipmentAsset> newEquip = new AssetSelection<EquipmentAsset>();
							newEquip.Source.EditorAsset = equipment.Assets[i];
							equips.Add(newEquip);
						}
						setting.equipment = equips.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all equipment.", "",
						EditorTool.WIDTH_150))
					{
						setting.equipment = new AssetSelection<EquipmentAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
				return true;
			}
			else if(info == "button:availableequipment:itemtypes")
			{
				AvailableEquipment setting = instance as AvailableEquipment;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all item types.", "",
						EditorTool.WIDTH_150))
					{
						List<AvailableEquipmentItemType> types = new List<AvailableEquipmentItemType>();
						GenericAssetList<ItemTypeAsset> itemTypes = EditorDataHandler.Instance.GetAssets<ItemTypeAsset>();
						for(int i = 0; i < itemTypes.Count; i++)
						{
							AvailableEquipmentItemType newType = new AvailableEquipmentItemType();
							newType.itemType.Source.EditorAsset = itemTypes.Assets[i];
							types.Add(newType);
						}
						setting.itemTypes = types.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all item types.", "",
						EditorTool.WIDTH_150))
					{
						setting.itemTypes = new AvailableEquipmentItemType[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
				return true;
			}
			else if(info == "button:statusbonus:attackmodifierbonus")
			{
				StatusBonusSetting bonus = instance as StatusBonusSetting;
				if(bonus != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all attack modifier attributes a bonus of 0.", "",
						EditorTool.WIDTH_150))
					{
						List<AttackModifierBonus> startValues = new List<AttackModifierBonus>();
						GenericAssetList<AttackModifierAsset> modifiers = EditorDataHandler.Instance.GetAssets<AttackModifierAsset>();
						for(int i = 0; i < modifiers.Count; i++)
						{
							for(int j = 0; j < modifiers.Assets[i].Settings.attribute.Length; j++)
							{
								AttackModifierBonus newValue = new AttackModifierBonus();
								newValue.modifier.modifier.Source.EditorAsset = modifiers.Assets[i];
								newValue.modifier.index = j;
								newValue.bonus = 0;
								startValues.Add(newValue);
							}
						}
						bonus.attackModifierBonus = startValues.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all attack modifier bonuses.", "",
						EditorTool.WIDTH_150))
					{
						bonus.attackModifierBonus = new AttackModifierBonus[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
				return true;
			}
			else if(info == "button:statusbonus:defencemodifierbonus")
			{
				StatusBonusSetting bonus = instance as StatusBonusSetting;
				if(bonus != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all defence modifier attributes a bonus of 0.", "",
						EditorTool.WIDTH_150))
					{
						List<DefenceModifierBonus> startValues = new List<DefenceModifierBonus>();
						GenericAssetList<DefenceModifierAsset> modifiers = EditorDataHandler.Instance.GetAssets<DefenceModifierAsset>();
						for(int i = 0; i < modifiers.Count; i++)
						{
							for(int j = 0; j < modifiers.Assets[i].Settings.attribute.Length; j++)
							{
								DefenceModifierBonus newValue = new DefenceModifierBonus();
								newValue.modifier.modifier.Source.EditorAsset = modifiers.Assets[i];
								newValue.modifier.index = j;
								newValue.bonus = 0;
								startValues.Add(newValue);
							}
						}
						bonus.defenceModifierBonus = startValues.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all defence modifier bonuses.", "",
						EditorTool.WIDTH_150))
					{
						bonus.defenceModifierBonus = new DefenceModifierBonus[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
				return true;
			}
			return false;
		}
	}
}
