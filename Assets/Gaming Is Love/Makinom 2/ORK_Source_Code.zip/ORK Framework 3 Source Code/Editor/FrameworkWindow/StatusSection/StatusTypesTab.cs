﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class StatusTypesTab : ORKGenericAssetListTab<StatusTypeAsset, StatusType>
	{
		public StatusTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.StatusTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.StatusTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Status Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Status types are used to separate status values.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/status-values/"; }
		}
	}
}

