
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class MoveAIsTab : ORKGenericAssetListTab<MoveAIAsset, MoveAISetting>
	{
		public MoveAIsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Move AIs"; }
		}

		public override string HelpText
		{
			get
			{
				return "Move AIs are used by combatants to detect enemies and determine movement target positions.\n" +
					"The actual movement is handled by the combatant's movement component.\n" +
					"The default movement component is set up in 'Combatants > Combatants > General Settings', " +
					"each combatant can optionally override the default component.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/move-ai/"; }
		}

		public override void ShowSettings()
		{
			base.ShowSettings();

			MoveAISetting moveAI = this.CurrentSettings;
			if(moveAI != null &&
				moveAI.useDetection)
			{
				// target check order
				for(int i = 0; i < moveAI.targetPositionCheck.targetCheck.Length; i++)
				{
					if(i == 0)
					{
						moveAI.targetPositionCheck.targetCheck[i].distance = 0;
					}
					else if(moveAI.targetPositionCheck.targetCheck[i].distance <
						moveAI.targetPositionCheck.targetCheck[i - 1].distance)
					{
						moveAI.targetPositionCheck.targetCheck[i].distance =
							moveAI.targetPositionCheck.targetCheck[i - 1].distance;
					}
				}
			}
		}
	}
}

