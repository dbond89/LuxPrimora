﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleRangeTemplatesTab : ORKGenericAssetListTab<BattleRangeTemplateAsset, BattleRangeTemplate>
	{
		public BattleRangeTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				BattleRangeTemplateAsset asset = ScriptableObject.CreateInstance<BattleRangeTemplateAsset>();
				asset.Settings = new BattleRangeTemplate("No Range");
				this.assetList.Add(asset);
				this.assetList.Add(BattleRangeTemplatesTab.CreateAsset("Range 1", 1));
				this.assetList.Add(BattleRangeTemplatesTab.CreateAsset("Range 2", 2));
				this.assetList.Add(BattleRangeTemplatesTab.CreateAsset("Range 3", 3));
				this.assetList.Add(BattleRangeTemplatesTab.CreateAsset("Range 4", 4));
				this.assetList.Add(BattleRangeTemplatesTab.CreateAsset("Range 5", 5));
			}
		}

		private static BattleRangeTemplateAsset CreateAsset(string name, float range)
		{
			BattleRangeTemplateAsset asset = ScriptableObject.CreateInstance<BattleRangeTemplateAsset>();
			asset.Settings = new BattleRangeTemplate(name, range);
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Range Templates"; }
		}

		public override string HelpText
		{
			get
			{
				return "Battle range templates are used by target selection templates, abilities and items as use/affect ranges.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/battle-ranges/"; }
		}
	}
}
