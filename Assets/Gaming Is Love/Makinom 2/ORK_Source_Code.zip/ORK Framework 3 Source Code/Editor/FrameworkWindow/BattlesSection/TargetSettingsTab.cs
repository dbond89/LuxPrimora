﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class TargetSettingsTab : ORKBaseEditorTab
	{
		public TargetSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Target Settings"; }
		}

		public override string HelpText
		{
			get { return "Set up how target selection will be handled."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/target-selection/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.TargetSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.TargetSettings; }
		}
	}
}
