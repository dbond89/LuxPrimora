﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class BattleGridBaseInspector : BaseInspector
	{
		protected enum GridEditorMode { Select, Move, Rotate, Paint, Connections };

		protected class GridEditorSettings : BaseData
		{
			[EditorHelp("Mode", "Select the mode of the grid editor:\n" +
				"- Select: Select cells.\n" +
				"- Move: Move cells.\n" +
				"- Rotate: Rotate cells.\n" +
				"- Paint: Paint cell types on cells.\n" +
				"- Connections: Change connections between cells.")]
			public GridEditorMode mode = GridEditorMode.Select;

			[EditorHelp("Cell Type", "Select the grid cell type that will be painted.")]
			[EditorCondition("mode", GridEditorMode.Paint)]
			[EditorLabel("Hold 'CTRL' while clicking to pick a cell's cell type instead of painting.\n" +
				"Holding 'Shift' will pick/paint the shift cell type.")]
			public AssetSelection<BattleGridCellTypeAsset> cellType = new AssetSelection<BattleGridCellTypeAsset>();

			[EditorHelp("Shift Cell Type", "Select the grid cell type that will be painted when holding shift.")]
			public AssetSelection<BattleGridCellTypeAsset> shiftCellType = new AssetSelection<BattleGridCellTypeAsset>();

			[EditorHelp("Brush Size (Cells)", "Define the size of the brush used for painting (in cells).")]
			[EditorLimit(0.5f, 10.0f)]
			[EditorEndCondition]
			public float brushSize = 1;

			public GridEditorSettings()
			{

			}
		}

		protected static GridEditorSettings settings = new GridEditorSettings();

		protected BattleGridComponent grid;

		protected int undo = -1;

		protected GUIStyle deploymentStyle;

		protected Vector2 cursorLabelOffset = new Vector2(20, 20);


		// cell connection
		protected int connectionIndex = -1;

		protected BattleGridCellComponent connectionCell = null;

		protected BattleGridCellComponent connectToCell = null;

		protected void ShowGridSettings(BattleGridCellComponent cell)
		{
			if(this.grid != null &&
				this.grid.cellRow != null &&
				this.grid.cellRow.Length > 0 &&
				!Application.isPlaying)
			{
				if(this.baseEditor.BeginFoldout("Grid Setup", "", "", true))
				{
					this.grid.autoShowGrid = EditorGUILayout.Toggle("Auto Show (Scene Load)", this.grid.autoShowGrid);
					EditorGUILayout.Separator();

					// editor setup
					EditorTool.BoldLabel("Editor Setup");
					EditorGUILayout.LabelField("Grid Cells", (this.grid.cellRow.Length * this.grid.cellRow[0].cell.Length).ToString());

					bool showingPrefabs = this.grid.showEditorGrid && this.grid.showEditorPrefabs;
					this.grid.showEditorGrid = EditorGUILayout.Toggle("Show Grid (Editor)", this.grid.showEditorGrid);
					if(this.grid.showEditorGrid)
					{
						this.grid.showEditorPrefabs = EditorGUILayout.Toggle("Show Prefabs (Editor)", this.grid.showEditorPrefabs);
						if(this.grid.showEditorPrefabs)
						{
							this.grid.showEditorUnselected = EditorGUILayout.Toggle("Show Unselected (Editor)", this.grid.showEditorUnselected);
						}
						this.grid.showDeploymentInfo = EditorGUILayout.Toggle("Show Deployment Info (Editor)", this.grid.showDeploymentInfo);
						EditorGUILayout.Separator();

						EditorAutomation.Automate(BattleGridBaseInspector.settings, this.baseEditor);

						// connections
						if(BattleGridBaseInspector.settings.mode == GridEditorMode.Connections)
						{
							if(!this.grid.connectionsInitialized)
							{
								this.grid.InitConnections();
							}
							if(cell != null)
							{
								for(int i = 0; i < cell.connections.Length; i++)
								{
									cell.connections[i] = (BattleGridCellComponent)EditorGUILayout.ObjectField(
										"Connection " + i, cell.connections[i], typeof(BattleGridCellComponent), true);
								}
								if(EditorTool.Button(new GUIContent("Reset Connections")))
								{
									Undo.RecordObject(cell, "Reset connections on " + cell.name);
									cell.InitConnections();
								}
								if(cell.connections != null &&
									EditorTool.Button(new GUIContent("Remove Connections")))
								{
									Undo.RecordObject(cell, "Remove connections on " + cell.name);

									for(int i = 0; i < cell.connections.Length; i++)
									{
										cell.connections[i] = null;
									}
								}
							}
							else
							{
								if(EditorTool.Button(new GUIContent("Reset All Connections")))
								{
									Undo.SetCurrentGroupName("Reset all connections on " + target.name);
									int undo = Undo.GetCurrentGroup();
									Undo.RegisterFullObjectHierarchyUndo(this.grid.gameObject,
										"Reset all connections on " + this.grid.name);

									this.grid.InitConnections();

									Undo.CollapseUndoOperations(undo);
								}
								if(EditorTool.Button(new GUIContent("Remove Blocked Cell Connections")))
								{
									Undo.SetCurrentGroupName("Remove blocked cell connections on " + target.name);
									int undo = Undo.GetCurrentGroup();
									Undo.RegisterFullObjectHierarchyUndo(this.grid.gameObject,
										"Remove blocked cell connections on " + this.grid.name);

									this.grid.RemoveBlockedConnections();

									Undo.CollapseUndoOperations(undo);
								}
							}
						}
					}
					// destroy prefabs
					else if(showingPrefabs &&
						!Application.isPlaying)
					{
						this.grid.EditorDestroyPrefabs();
					}

					EditorGUILayout.Separator();
				}
				this.baseEditor.EndFoldout();
			}
		}


		/*
		============================================================================
		Grid cell display functions
		============================================================================
		*/
		void OnEnable()
		{
			if(target is BattleGridComponent)
			{
				this.grid = (BattleGridComponent)target;
			}
			else if(target is BattleGridCellComponent)
			{
				this.grid = ((BattleGridCellComponent)target).parentGrid;
			}

			if(this.grid != null &&
				this.grid.showEditorGrid &&
				this.grid.showEditorPrefabs &&
				this.grid.cellRow != null &&
				!Application.isPlaying)
			{
				this.grid.EditorShowPrefabs();
			}
		}

		void OnDisable()
		{
			if(this.grid != null &&
				this.grid.showEditorGrid &&
				this.grid.showEditorPrefabs &&
				!this.grid.showEditorUnselected &&
				this.grid.cellRow != null &&
				!Application.isPlaying)
			{
				this.grid.EditorDestroyPrefabs();
			}
		}

		protected virtual bool Raycast(out Vector3 position, Vector2 cursorOffset)
		{
			Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition + cursorOffset);
			position = ray.origin;
			RaycastOutput hit;
			if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit,
				this.grid.settings.rayDistance, this.grid.settings.rayLayerMask))
			{
				position = hit.point;
				return true;
			}
			else if(SceneView.lastActiveSceneView.in2DMode)
			{
				return true;
			}
			return false;
		}

		public void OnSceneGUI()
		{
			if(this.grid != null &&
				DragAndDrop.objectReferences.Length == 0 &&
				ORK.Initialized &&
				!Application.isPlaying &&
				!Event.current.alt)
			{
				if(this.grid.showEditorGrid && this.grid.cellRow != null)
				{
					if(this.deploymentStyle == null)
					{
						this.deploymentStyle = new GUIStyle(EditorContent.Instance.BoxSlimStyle);
						this.deploymentStyle.padding = new RectOffset(5, 0, 5, 0);
						this.deploymentStyle.fontSize = 10;
					}

					float neighbourAngleOffset = ORK.BattleGridSettings.IsHorizontalHex ? -30 : 0;

					Color tmpColor = Handles.color;
					Handles.color = Color.blue;

					bool cellVisible = true;
					Vector3 cellViewport = Vector3.zero;
					Camera sceneCamera = SceneView.lastActiveSceneView.camera;

					// paint mode
					bool mouseDown = false;
					Vector3 worldMousePosition = Vector3.zero;
					Vector2 cellSize = ORK.BattleGridSettings.CellDistance;
					float brush = BattleGridBaseInspector.settings.brushSize * ((cellSize.x + cellSize.y) / 4.0f);

					// paint
					if(BattleGridBaseInspector.settings.mode == GridEditorMode.Paint)
					{
						Vector3 position = Vector3.zero;
						if(this.Raycast(out position, Vector2.zero))
						{
							Vector3 labelPosition = Vector3.zero;
							if(!this.Raycast(out labelPosition, this.cursorLabelOffset))
							{
								labelPosition = position;
							}
							if(Event.current.control)
							{
								Handles.color = Color.white;
								Handles.Label(labelPosition, Event.current.shift ? "Pick Shift" : "Pick",
									this.deploymentStyle);
							}
							else
							{
								Handles.Label(labelPosition, Event.current.shift ?
									BattleGridBaseInspector.settings.shiftCellType.ToString() :
									BattleGridBaseInspector.settings.cellType.ToString(),
									this.deploymentStyle);
							}
							Handles.CircleHandleCap(0, position,
								sceneCamera.transform.rotation, brush,
								Event.current.type);
							Handles.color = Color.blue;

							if(Event.current.type == EventType.MouseDown &&
								Event.current.button == 0)
							{
								Undo.SetCurrentGroupName("Paint battle grid on " + target.name);
								this.undo = Undo.GetCurrentGroup();
								Undo.RegisterFullObjectHierarchyUndo(this.grid.gameObject,
									 "Paint battle grid on " + target.name);
							}
							else if(this.undo >= 0 &&
								Event.current.type == EventType.MouseUp)
							{
								Undo.CollapseUndoOperations(this.undo);
								this.undo = -1;
							}

							if((Event.current.type == EventType.MouseDown ||
								Event.current.type == EventType.MouseDrag ||
								Event.current.type == EventType.MouseUp) &&
								Event.current.button == 0 &&
								!Event.current.alt)
							{
								mouseDown = true;
								worldMousePosition = position;
							}
						}
					}

					if(this.connectionIndex >= 0 &&
						this.connectionCell != null)
					{
						Handles.color = Color.cyan;
						Handles.CircleHandleCap(0, this.connectionCell.transform.position,
							this.connectionCell.transform.rotation * Quaternion.LookRotation(Vector3.up),
							0.5f, EventType.Repaint);

						if(this.connectToCell == null ||
							this.connectToCell == this.connectionCell)
						{
							Handles.color = Color.red;
							Handles.DotHandleCap(0, this.connectionCell.transform.position,
								this.connectionCell.transform.rotation * Quaternion.LookRotation(Vector3.up),
								0.25f, EventType.Repaint);
						}
						else
						{
							Handles.color = Color.green;
							if(this.connectionCell.connections[this.connectionIndex] != null)
							{
								Handles.CircleHandleCap(0, this.connectionCell.connections[this.connectionIndex].transform.position,
									this.connectionCell.connections[this.connectionIndex].transform.rotation * Quaternion.LookRotation(Vector3.up),
									0.5f, EventType.Repaint);
							}

							Handles.color = Color.green;
							Handles.DrawLine(this.connectionCell.transform.position, this.connectToCell.transform.position);
							Handles.DotHandleCap(0, this.connectToCell.transform.position,
								this.connectToCell.transform.rotation * Quaternion.LookRotation(Vector3.up),
								0.25f, EventType.Repaint);
						}
						Handles.color = Color.blue;

						if(Event.current.type == EventType.KeyDown &&
							Event.current.keyCode == KeyCode.Escape)
						{
							this.connectionIndex = -1;
							this.connectionCell = null;
							this.connectToCell = null;
						}
						else if(Event.current.type == EventType.MouseUp)
						{
							if(Event.current.button == 0)
							{
								if(this.connectToCell == this.connectionCell)
								{
									Undo.RecordObject(this.connectionCell, "Remove connection " + this.connectionIndex + " on " + this.connectionCell.name);
									this.connectionCell.connections[this.connectionIndex] = null;
								}
								else
								{
									Undo.RecordObject(this.connectionCell, "Change connection " + this.connectionIndex + " on " + this.connectionCell.name);
									this.connectionCell.connections[this.connectionIndex] = this.connectToCell;
								}
							}
							this.connectionIndex = -1;
							this.connectionCell = null;
							this.connectToCell = null;
						}
					}

					for(int i = 0; i < this.grid.cellRow.Length; i++)
					{
						if(this.grid.cellRow[i] != null)
						{
							for(int j = 0; j < this.grid.cellRow[i].cell.Length; j++)
							{
								if(this.grid.cellRow[i].cell[j] != null)
								{
									if(this.grid.showEditorPrefabs)
									{
										this.grid.cellRow[i].cell[j].EditorShowPrefab();
									}
									else if(this.grid.cellRow[i].cell[j].PrefabInstance != null)
									{
										GameObject.DestroyImmediate(this.grid.cellRow[i].cell[j].PrefabInstance);
									}

									cellVisible = false;
									if(sceneCamera != null)
									{
										cellViewport = sceneCamera.WorldToViewportPoint(this.grid.cellRow[i].cell[j].transform.position);
										if(cellViewport.x >= -0.1f && cellViewport.x <= 1.1f &&
											cellViewport.y >= -0.1f && cellViewport.y <= 1.1f &&
											cellViewport.z >= 0)
										{
											cellVisible = true;
										}
									}

									if(cellVisible)
									{
										// cell spawn rotation
										if(this.grid.cellRow[i].cell[j].settings.setSpawnRotation)
										{
											Handles.color = Color.yellow;
											Handles.ArrowHandleCap(0, this.grid.cellRow[i].cell[j].transform.position,
												Quaternion.Euler(this.grid.cellRow[i].cell[j].SpawnRotation),
												0.5f, EventType.Repaint);
											Handles.color = Color.blue;
										}

										if(this.grid.showDeploymentInfo &&
											this.grid.cellRow[i].cell[j].IsDeployment)
										{
											Handles.color = Color.green;
											Handles.Label(this.grid.cellRow[i].cell[j].transform.position,
												this.grid.cellRow[i].cell[j].Deployment.EditorDeployString(), this.deploymentStyle);
										}
										else
										{
											Handles.color = Color.blue;
										}

										// select
										if(BattleGridBaseInspector.settings.mode == GridEditorMode.Select)
										{

											Handles.FreeMoveHandle(this.grid.cellRow[i].cell[j].transform.position,
												this.grid.cellRow[i].cell[j].transform.rotation,
												0.1f * HandleUtility.GetHandleSize(this.grid.cellRow[i].cell[j].transform.position),
												Vector3.zero, delegate (int controlID, Vector3 position, Quaternion rotation, float size, EventType eventType)
												{
													Handles.SphereHandleCap(controlID, position, rotation, size, eventType);

													if(GUIUtility.hotControl == controlID)
													{
														Selection.objects = new Object[] { this.grid.cellRow[i].cell[j].gameObject };
													}
												});
										}
										// move
										else if(BattleGridBaseInspector.settings.mode == GridEditorMode.Move)
										{
											EditorGUI.BeginChangeCheck();
											Vector3 tmpPosition = Handles.PositionHandle(
												this.grid.cellRow[i].cell[j].transform.position,
												this.grid.cellRow[i].cell[j].transform.rotation);

											if(EditorGUI.EndChangeCheck())
											{
												Undo.RecordObject(this.grid.cellRow[i].cell[j].transform, "Move battle grid cell " + i + ", " + j);
												this.grid.cellRow[i].cell[j].transform.position = tmpPosition;
												GUI.changed = true;
											}
										}
										// rotate
										else if(BattleGridBaseInspector.settings.mode == GridEditorMode.Rotate)
										{
											EditorGUI.BeginChangeCheck();
											Quaternion tmpRotation = Handles.RotationHandle(
												this.grid.cellRow[i].cell[j].transform.rotation,
												this.grid.cellRow[i].cell[j].transform.position);

											if(EditorGUI.EndChangeCheck())
											{
												Undo.RecordObject(this.grid.cellRow[i].cell[j].transform, "Rotate battle grid cell " + i + ", " + j);
												this.grid.cellRow[i].cell[j].transform.rotation = tmpRotation;
												GUI.changed = true;
											}
										}
										// paint
										else if(BattleGridBaseInspector.settings.mode == GridEditorMode.Paint)
										{
											bool isCell = false;
											if(Event.current.shift ?
												this.grid.cellRow[i].cell[j].settings.cellType.Is(BattleGridBaseInspector.settings.shiftCellType.StoredAsset) :
												this.grid.cellRow[i].cell[j].settings.cellType.Is(BattleGridBaseInspector.settings.cellType.StoredAsset))
											{
												isCell = true;
												Handles.color = Color.blue;
											}
											else
											{
												Handles.color = Color.gray;
											}

											int controlID = GUIUtility.GetControlID(FocusType.Passive);
											Handles.SphereHandleCap(controlID, this.grid.cellRow[i].cell[j].transform.position,
												this.grid.cellRow[i].cell[j].transform.rotation,
												0.1f * HandleUtility.GetHandleSize(this.grid.cellRow[i].cell[j].transform.position),
												Event.current.type);

											if(Event.current.type == EventType.Layout)
											{
												HandleUtility.AddDefaultControl(controlID);
											}
											else if(mouseDown)
											{
												if(VectorHelper.Distance(worldMousePosition,
														this.grid.cellRow[i].cell[j].transform.position, true,
														ORK.BattleGridSettings.horizontalPlane) <
													ORK.BattleGridSettings.cellSize * 0.25f + brush)
												{
													if(Event.current.shift)
													{
														if(!isCell)
														{
															// pick
															if(Event.current.control)
															{
																BattleGridBaseInspector.settings.shiftCellType.Source.EditorAsset = this.grid.cellRow[i].cell[j].settings.cellType.Source.EditorAsset;
																BattleGridBaseInspector.settings.shiftCellType.ResetStoredAsset();
																mouseDown = false;
															}
															// paint
															else if(BattleGridBaseInspector.settings.shiftCellType.StoredAsset != null)
															{
																this.grid.cellRow[i].cell[j].settings.cellType.Source.EditorAsset = BattleGridBaseInspector.settings.shiftCellType.StoredAsset;
																this.grid.cellRow[i].cell[j].settings.cellType.ResetStoredAsset();
																this.grid.cellRow[i].cell[j].ClearSettings();
																if(this.grid.cellRow[i].cell[j].PrefabInstance != null)
																{
																	GameObject.DestroyImmediate(this.grid.cellRow[i].cell[j].PrefabInstance);
																}
															}
														}
													}
													else if(!isCell)
													{
														// pick
														if(Event.current.control)
														{
															BattleGridBaseInspector.settings.cellType.Source.EditorAsset = this.grid.cellRow[i].cell[j].settings.cellType.Source.EditorAsset;
															BattleGridBaseInspector.settings.cellType.ResetStoredAsset();
															mouseDown = false;
														}
														// paint
														else if(BattleGridBaseInspector.settings.cellType.StoredAsset != null)
														{
															this.grid.cellRow[i].cell[j].settings.cellType.Source.EditorAsset = BattleGridBaseInspector.settings.cellType.StoredAsset;
															this.grid.cellRow[i].cell[j].settings.cellType.ResetStoredAsset();
															this.grid.cellRow[i].cell[j].ClearSettings();
															if(this.grid.cellRow[i].cell[j].PrefabInstance != null)
															{
																GameObject.DestroyImmediate(this.grid.cellRow[i].cell[j].PrefabInstance);
															}
														}
													}
												}
											}
										}
										// connections
										else if(BattleGridBaseInspector.settings.mode == GridEditorMode.Connections)
										{
											// selection handle
											Handles.FreeMoveHandle(this.grid.cellRow[i].cell[j].transform.position,
												this.grid.cellRow[i].cell[j].transform.rotation,
												0.1f * HandleUtility.GetHandleSize(this.grid.cellRow[i].cell[j].transform.position),
												Vector3.zero, delegate (int controlID, Vector3 position, Quaternion rotation, float size, EventType eventType)
												{
													Handles.SphereHandleCap(controlID, position, rotation, size, eventType);

													if(GUIUtility.hotControl == controlID)
													{
														Selection.objects = new Object[] { this.grid.cellRow[i].cell[j].gameObject };
													}
												});

											// neighbours
											for(int k = 0; k < this.grid.cellRow[i].cell[j].connections.Length; k++)
											{
												if(this.grid.cellRow[i].cell[j].connections[k] != null)
												{
													Handles.color = Color.cyan;
													Vector3 direction = VectorHelper.GetDirection(
														this.grid.cellRow[i].cell[j].transform.position,
														this.grid.cellRow[i].cell[j].connections[k].transform.position);

													EditorGUI.BeginChangeCheck();
													Vector3 tmpPosition = Handles.FreeMoveHandle(
														this.grid.cellRow[i].cell[j].transform.position, Quaternion.identity,
														0.5f, Vector3.zero, delegate (int controlID, Vector3 position, Quaternion rotation, float size, EventType eventType)
														{
															Handles.ArrowHandleCap(controlID, this.grid.cellRow[i].cell[j].transform.position,
																this.grid.cellRow[i].cell[j].transform.rotation *
																	Quaternion.LookRotation(direction),
																size, eventType);
														});
													if(EditorGUI.EndChangeCheck())
													{
														this.connectionIndex = k;
														this.connectionCell = this.grid.cellRow[i].cell[j];

														Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
														Vector3 position = Vector3.zero;
														if(this.Raycast(out position, Vector2.zero))
														{
															this.connectToCell = this.grid.GetNearestCell(position, ORK.BattleGridSettings.cellSize * 1.1f, null);
														}
														else
														{
															this.connectToCell = null;
														}
													}

													if(this.grid.cellRow[i].cell[j] == target)
													{
														Handles.DrawLine(this.grid.cellRow[i].cell[j].transform.position, this.grid.cellRow[i].cell[j].connections[k].transform.position);
														Handles.Label(this.grid.cellRow[i].cell[j].transform.TransformPointUnscaled(direction.normalized * 0.5f),
															k.ToString());
													}
												}
												else
												{
													Handles.color = Color.red;
													EditorGUI.BeginChangeCheck();
													Vector3 tmpPosition = Handles.FreeMoveHandle(
														this.grid.cellRow[i].cell[j].transform.position, Quaternion.identity,
														0.5f, Vector3.zero, delegate (int controlID, Vector3 position, Quaternion rotation, float size, EventType eventType)
														{
															Handles.ArrowHandleCap(controlID, this.grid.cellRow[i].cell[j].transform.position,
																Quaternion.Euler(this.grid.cellRow[i].cell[j].transform.eulerAngles +
																	new Vector3(0, (360.0f / this.grid.cellRow[i].cell[j].connections.Length) * k + neighbourAngleOffset, 0)),
																size, eventType);
														});
													if(EditorGUI.EndChangeCheck())
													{
														this.connectionIndex = k;
														this.connectionCell = this.grid.cellRow[i].cell[j];

														Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
														Vector3 position = Vector3.zero;
														if(this.Raycast(out position, Vector2.zero))
														{
															this.connectToCell = this.grid.GetNearestCell(position, ORK.BattleGridSettings.cellSize * 1.1f, null);
														}
														else
														{
															this.connectToCell = null;
														}
													}
												}
											}
											Handles.color = Color.blue;
										}
									}
								}
							}
						}
					}

					Handles.color = tmpColor;
				}
			}

			if(BattleGridBaseInspector.settings.mode == GridEditorMode.Paint)
			{
				SceneView.lastActiveSceneView.Repaint();
			}
		}
	}
}
