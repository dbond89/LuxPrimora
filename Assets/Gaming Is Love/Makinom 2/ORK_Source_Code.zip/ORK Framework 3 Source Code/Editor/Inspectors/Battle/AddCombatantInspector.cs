
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(AddCombatant))]
public class AddCombatantInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as AddCombatant);
	}

	protected virtual void ComponentSetup(AddCombatant target)
	{
		Undo.RecordObject(target, "Change to 'Add Combatant' on " + target.name);
		this.BaseInit(true);

		// remember combatants
		this.ShowGlobalSceneGUID(target, "Remember Combatant", "Get New ID",
			"Remembering the combatant will keep it's status and position and restore it when re-entering the scene.");

		EditorAutomation.Automate(target.settings, this.baseEditor);


		// waypoint settings
		if(this.baseEditor.BeginFoldout("Waypoint Settings",
			"Optionally define waypoints the combatant's move AI will use.", "", false))
		{
			target.settings.randomWaypointOrder = EditorGUILayout.Toggle(
				new GUIContent("Random Order", "Use the waypoints in random order."),
				target.settings.randomWaypointOrder);

			EditorGUI.indentLevel++;
			this.ShowSerializedProperty("waypoints");
			EditorGUI.indentLevel--;

			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();


		// start settings
		this.ShowBaseCondition(target);

		this.EndSetup();
	}
}