
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using GamingIsLove.ORKFramework.AI;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(CombatantSpawner))]
public class CombatantSpawnerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as CombatantSpawner);
	}

	protected virtual void ComponentSetup(CombatantSpawner target)
	{
		Undo.RecordObject(target, "Change to 'Combatant Spawner' on " + target.name);
		this.BaseInit(true);

		// scene ID
		this.ShowSceneID<BaseBattleComponent>(target,
			"The scene ID is used to keep track of finished battles. " +
			"If battles share the same ID (in a scene), their finished state will be shared.\n" +
			"The scene ID is used scene-wide, i.e. not in different scenes.");

		// remember combatants
		this.ShowSceneGUID(target, "Remember Combatants", "Get New Spawner ID",
			"Remembering combatants will keep their status, position and respawn times and restore it when re-entering the scene.");

		if(target.settings.spawnRandom &&
			target.settings.useChanceSelection)
		{
			float totalChance = 0;
			for(int i = 0; i < target.settings.combatant.Length; i++)
			{
				totalChance += target.settings.combatant[i].combatant.chance;
			}
			EditorGUILayout.LabelField("Total Chance", totalChance.ToString("0.0") + " of " + Maki.GameSettings.maxRandomRange.ToString("0.0"));
		}

		EditorAutomation.Automate(target.settings, this.baseEditor);


		// spawn settings
		if(this.baseEditor.BeginFoldout("Spawn Settings",
			"Define where combatants will spawn.", "", false))
		{
			this.ShowSerializedProperty("otherCollider");
			this.ShowSerializedProperty("otherCollider2D");

			target.settings.maxSpawnPerFrame = EditorGUILayout.IntField(
				new GUIContent("Max Spawn Per Frame", "The maximum number of spawns per frame."),
				target.settings.maxSpawnPerFrame);
			if(target.settings.maxSpawnPerFrame < 1)
			{
				target.settings.maxSpawnPerFrame = 1;
			}

			target.settings.useNavMeshPositions = EditorGUILayout.Toggle(
				new GUIContent("Use NavMesh Positions", "Combatants will spawn at the nearest NavMesh position to their found spawn position.\n" +
					"If no NavMesh is used in the scene or no position found, their original found spawn position is used."),
				target.settings.useNavMeshPositions);
			if(target.settings.useNavMeshPositions)
			{
				EditorGUI.indentLevel++;
				target.settings.navMeshSampleDistance = EditorGUILayout.FloatField(
					new GUIContent("Sample Distance", "Define the distance in which the nearest position on the NavMesh will be searched."),
					target.settings.navMeshSampleDistance);
				target.settings.navMeshSampleAreaMask = EditorGUILayout.IntField(
					new GUIContent("Area Mask", "A mask specifying which NavMesh areas are allowed when finding the nearest point.\n" +
						"Defaults to all areas (-1)."),
					target.settings.navMeshSampleAreaMask);
				EditorGUI.indentLevel--;
			}

			bool areaSpawn = false;
			if(target.HasCollider())
			{
				target.settings.spawnAtPosition = EditorGUILayout.Toggle(
					new GUIContent("Spawn At Position", "Spawn the combatants at defined positions (using game objects in the scene)."),
					target.settings.spawnAtPosition);
				if(!target.settings.spawnAtPosition)
				{
					areaSpawn = true;
					EditorTool.LayerMaskField("Layer Mask", ref target.settings.layerMask, GUILayout.ExpandWidth(true));
					target.settings.roundSpawnPosition = (Rounding)EditorGUILayout.EnumPopup("Position Rounding",
						target.settings.roundSpawnPosition);
					EditorGUILayout.HelpBox("The combatants will be spawned randomly within the attached collider's bounds. " +
						"Spawn positions are found with raycasts using the defined layer mask.\n" +
						"Remove the collider to spawn combatants at defined positions (or use the 'Spawn At Position' setting.",
						MessageType.Info);
					target.spawnPoint = new GameObject[0];
				}
			}
			if(!areaSpawn)
			{
				target.settings.roundSpawnPosition = Rounding.None;
				EditorGUILayout.HelpBox("Combatants will be spawned randomly at one of the defined game objects.\n" +
					"If no game objects are used, the combatants will spawn at " +
					"the position of this combatant spawner.\n" +
					"Attach a collider (enable 'Is Trigger' to make it passable by the player) to randomly spawn combatants within an area.",
					MessageType.Info);

				EditorGUI.indentLevel++;
				this.ShowSerializedProperty("spawnPoint");
				EditorGUI.indentLevel--;
			}
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		// waypoint settings
		if(this.baseEditor.BeginFoldout("Waypoint Settings",
			"Optionally define waypoints the combatant's move AI will use.", "", false))
		{
			target.settings.randomWaypointOrder = EditorGUILayout.Toggle(
				new GUIContent("Random Order", "Use the waypoints in random order."),
				target.settings.randomWaypointOrder);

			EditorGUI.indentLevel++;
			this.ShowSerializedProperty("waypoints");
			EditorGUI.indentLevel--;

			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();


		// start settings
		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}
