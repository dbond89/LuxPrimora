﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(SmoothFollow))]
public class SmoothFollowInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as SmoothFollow);
	}

	protected virtual void ComponentSetup(SmoothFollow target)
	{
		Undo.RecordObject(target, "Change to 'Smooth Follow' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}