﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

[CustomEditor(typeof(LevelZone))]
public class LevelZoneInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ShowSettings(target as LevelZone);
	}

	private void ShowSettings(LevelZone target)
	{
		Undo.RecordObject(target, "Change to 'Level Zone' on " + target.name);
		this.BaseInit(true);

		if(target.GetComponent<Collider>() == null && 
			target.GetComponent<Collider2D>() == null)
		{
			EditorGUILayout.HelpBox("This level zone defines levels for combatants spawned in the whole scene.\n" + 
				"If you add additional level zones with colliders, they'll still manage the levels of combatants spawned within them.", 
				MessageType.Info);
		}
		else
		{
			EditorGUILayout.HelpBox("This level zone defines levels for combatants that are spawned within the bounds of the zone's collider.", 
				MessageType.Info);
		}

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}