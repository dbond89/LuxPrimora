﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	[EditorSettingInfo("Shop Interaction", "")]
	public class SceneWizard_AddComponent_ShopInteraction : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<ShopInteraction>();
		}
	}

	[EditorSettingInfo("Item Collector", "")]
	public class SceneWizard_AddComponent_ItemCollector : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			if(!Maki.Instantiated)
			{
				Maki.Initialize(MakinomAssetHelper.LoadProjectAsset());
			}
			SceneObjectHelper.AddToSelection<ItemCollector>();
		}
	}

	[EditorSettingInfo("Object HUD", "")]
	public class SceneWizard_AddComponent_ObjectHUD : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<ObjectHUDComponent>();
		}
	}

	[EditorSettingInfo("Battle 2D", "")]
	public class SceneWizard_AddComponent_Battle2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<BattleComponent> list = SceneObjectHelper.AddToSelection<BattleComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddCircleTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Battle 3D", "")]
	public class SceneWizard_AddComponent_Battle3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<BattleComponent> list = SceneObjectHelper.AddToSelection<BattleComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddSphereTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Battle Grid", "")]
	public class SceneWizard_AddComponent_BattleGrid : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<BattleGridComponent>();
		}
	}

	[EditorSettingInfo("Add Combatant", "")]
	public class SceneWizard_AddComponent_AddCombatant : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<AddCombatant>();
		}
	}

	[EditorSettingInfo("Combatant Spawner", "")]
	public class SceneWizard_AddComponent_CombatantSpawner : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<CombatantSpawner>();
		}
	}

	[EditorSettingInfo("Combatant Despawner", "")]
	public class SceneWizard_AddComponent_CombatantDespawner : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<CombatantDespawner>();
		}
	}

	[EditorSettingInfo("Combatant Trigger 2D", "")]
	public class SceneWizard_AddComponent_CombatantTrigger2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<CombatantTriggerComponent> list = SceneObjectHelper.AddToSelectionSimple<CombatantTriggerComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddCircleTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Combatant Trigger 3D", "")]
	public class SceneWizard_AddComponent_CombatantTrigger3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<CombatantTriggerComponent> list = SceneObjectHelper.AddToSelectionSimple<CombatantTriggerComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddSphereTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Block Combatant Spawn 2D", "")]
	public class SceneWizard_AddComponent_BlockCombatantSpawn2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<BlockCombatantSpawn> list = SceneObjectHelper.AddToSelectionSimple<BlockCombatantSpawn>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Block Combatant Spawn 3D", "")]
	public class SceneWizard_AddComponent_BlockCombatantSpawn3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<BlockCombatantSpawn> list = SceneObjectHelper.AddToSelectionSimple<BlockCombatantSpawn>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Equipment Viewer", "")]
	public class SceneWizard_AddComponent_EquipmentViewer : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<EquipmentViewer>();
		}
	}

	[EditorSettingInfo("Area 2D", "")]
	public class SceneWizard_AddComponent_Area2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<AreaComponent> list = SceneObjectHelper.AddToSelectionSimple<AreaComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddCircleTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Area 3D", "")]
	public class SceneWizard_AddComponent_Area3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<AreaComponent> list = SceneObjectHelper.AddToSelectionSimple<AreaComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddSphereTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Level Zone", "")]
	public class SceneWizard_AddComponent_LevelZone : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<LevelZone>();
		}
	}

	[EditorSettingInfo("Level Zone 2D", "")]
	public class SceneWizard_AddComponent_LevelZone2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<LevelZone> list = SceneObjectHelper.AddToSelectionSimple<LevelZone>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddCircleTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Level Zone 3D", "")]
	public class SceneWizard_AddComponent_LevelZone3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<LevelZone> list = SceneObjectHelper.AddToSelectionSimple<LevelZone>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddSphereTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Point Of Interest (Move AI)", "")]
	public class SceneWizard_AddComponent_PointOfInterest : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<PointOfInterest>();
		}
	}

	[EditorSettingInfo("Move AI Area 2D", "")]
	public class SceneWizard_AddComponent_MoveAIArea2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<MoveAIArea> list = SceneObjectHelper.AddToSelectionSimple<MoveAIArea>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Move AI Area 3D", "")]
	public class SceneWizard_AddComponent_MoveAIArea3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<MoveAIArea> list = SceneObjectHelper.AddToSelectionSimple<MoveAIArea>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Move AI Range 2D", "")]
	public class SceneWizard_AddComponent_MoveAIRange2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<MoveAIRangeComponent> list = SceneObjectHelper.AddToSelectionSimple<MoveAIRangeComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Move AI Range 3D", "")]
	public class SceneWizard_AddComponent_MoveAIRange3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<MoveAIRangeComponent> list = SceneObjectHelper.AddToSelectionSimple<MoveAIRangeComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Move AI Hiding Area 2D", "")]
	public class SceneWizard_AddComponent_MoveAIHidingArea2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<MoveAIHidingAreaComponent> list = SceneObjectHelper.AddToSelectionSimple<MoveAIHidingAreaComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Move AI Hiding Area 3D", "")]
	public class SceneWizard_AddComponent_MoveAIHidingArea3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<MoveAIHidingAreaComponent> list = SceneObjectHelper.AddToSelectionSimple<MoveAIHidingAreaComponent>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("No Random Patrol 2D", "")]
	public class SceneWizard_AddComponent_NoRandomPatrol2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<NoRandomPatrol> list = SceneObjectHelper.AddToSelectionSimple<NoRandomPatrol>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger3D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("No Random Patrol 3D", "")]
	public class SceneWizard_AddComponent_NoRandomPatrol3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<NoRandomPatrol> list = SceneObjectHelper.AddToSelectionSimple<NoRandomPatrol>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].GetComponent<Collider2D>() == null)
				{
					ORKUnityMenuUtility.AddBoxTrigger2D(list[i].gameObject);
				}
			}
		}
	}

	[EditorSettingInfo("Damage Dealer 2D", "")]
	public class SceneWizard_AddComponent_DamageDealer2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<DamageDealer> list = SceneObjectHelper.AddToSelectionSimple<DamageDealer>();
			for(int i = 0; i < list.Count; i++)
			{
				ORKUnityMenuUtility.Add2DPhysics(list[i].gameObject);
			}
		}
	}

	[EditorSettingInfo("Damage Dealer 3D", "")]
	public class SceneWizard_AddComponent_DamageDealer3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<DamageDealer> list = SceneObjectHelper.AddToSelectionSimple<DamageDealer>();
			for(int i = 0; i < list.Count; i++)
			{
				ORKUnityMenuUtility.Add3DPhysics(list[i].gameObject);
			}
		}
	}

	[EditorSettingInfo("Damage Zone 2D", "")]
	public class SceneWizard_AddComponent_DamageZone2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<DamageZone> list = SceneObjectHelper.AddToSelectionSimple<DamageZone>();
			for(int i = 0; i < list.Count; i++)
			{
				ORKUnityMenuUtility.Add2DPhysics(list[i].gameObject);
			}
		}
	}

	[EditorSettingInfo("Damage Zone 3D", "")]
	public class SceneWizard_AddComponent_DamageZone3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			List<DamageZone> list = SceneObjectHelper.AddToSelectionSimple<DamageZone>();
			for(int i = 0; i < list.Count; i++)
			{
				ORKUnityMenuUtility.Add3DPhysics(list[i].gameObject);
			}
		}
	}
}
