﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Has Combatant Trigger", "Checks if a combatant has combatant triggers.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class HasCombatantTriggerNode : BaseAICheckNode
	{
		// combatant
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;


		// tags
		[EditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Tags")]
		public Needed needed = Needed.All;

		[EditorWidth(hideName=true)]
		[EditorSeparator]
		[EditorArray("Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] tags = new string[0];

		public HasCombatantTriggerNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any,
					BattleAISettings.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Object.Triggers.Count > 0 &&
					(this.tags.Length == 0 ||
						this.CheckTags(list[i].Object.Triggers)))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTags(List<CombatantTriggerComponent> list)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						list[i].CheckTags(this.tags, this.needed))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("In Combatant Trigger", "Checks if a combatant is within one of the " +
		"user's combatant triggers (or the user in another combatant's trigger).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class InCombatantTriggerNode : BaseAICheckNode
	{
		// combatant
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[EditorHelp("In Target's Trigger", "Check if the user is in the target's trigger.\n" +
			"If disabled, checks if the target is in the user's trigger.", "")]
		[EditorSeparator]
		public bool inTargetTrigger = false;



		// tags
		[EditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Tags")]
		public Needed needed = Needed.All;

		[EditorWidth(hideName=true)]
		[EditorSeparator]
		[EditorArray("Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] tags = new string[0];

		public InCombatantTriggerNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, call.user, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any, call.user,
					BattleAISettings.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					(this.inTargetTrigger ?
						this.CheckTrigger(list[i], user) :
						this.CheckTrigger(user, list[i])))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTrigger(Combatant user, Combatant combatant)
		{
			List<CombatantTriggerComponent> list = user.Object.Triggers;
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						(this.tags.Length == 0 ||
							list[i].CheckTags(this.tags, this.needed)) &&
						list[i].Contains(combatant))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType +
				(this.inTargetTrigger ?
					" found: In target's trigger" :
					" found: In user's trigger");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Combatant Trigger Time", "Checks if a combatant is within one of the " +
		"user's combatant triggers for a defined amount of time (or the user in another combatant's trigger).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CombatantTriggerTimeNode : BaseAICheckNode
	{
		// combatant
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[EditorHelp("In Target's Trigger", "Check if the user is in the target's trigger.\n" +
			"If disabled, checks if the target is in the user's trigger.", "")]
		[EditorSeparator]
		public bool inTargetTrigger = false;

		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();



		// tags
		[EditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Tags")]
		public Needed needed = Needed.All;

		[EditorWidth(hideName=true)]
		[EditorSeparator]
		[EditorArray("Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] tags = new string[0];

		public CombatantTriggerTimeNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, call, call.user, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call, call.user, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any, call, call.user,
					BattleAISettings.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					(this.inTargetTrigger ?
						this.CheckTrigger(call, list[i], user) :
						this.CheckTrigger(call, user, list[i])))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTrigger(BattleAICall call, Combatant user, Combatant combatant)
		{
			call.checkTarget = combatant;
			List<CombatantTriggerComponent> list = user.Object.Triggers;
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						(this.tags.Length == 0 ||
							list[i].CheckTags(this.tags, this.needed)))
					{
						float time = list[i].GetTime(combatant);
						if(time >= 0 &&
							this.check.Check(time, call))
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found: " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}
}
