﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveAIHunting : BaseData
	{
		// hunting settings
		[EditorHelp("Use Hunting", "The hunting settings are enabled.\n" +
			"If disabled, the combatant won't react to enemy combatants.\n" +
			"Please note that only aggressive combatants will hunt enemies.", "")]
		public bool enabled = false;

		[EditorHelp("Use Target Change", "Allow changing targets if another detected target is nearer than the current target.", "")]
		[EditorCondition("enabled", true)]
		public bool useTargetChange = false;

		[EditorHelp("Stopped Look At Target", "Look at the target while the combatant is stopped.", "")]
		public bool stoppedLookAtTarget = false;


		// detection schematic
		[EditorHelp("Detection Schematic", "Select a schematic asset that will be started when the combatant detects a target and starts hunting it.\n" + 
			"The combatant will be used as 'Machine Object', the detected target as 'Starting Object'.", "")]
		[EditorSeparator]
		public AssetSource<MakinomSchematicAsset> detectionSchematic = new AssetSource<MakinomSchematicAsset>();

		[EditorHelp("Wait", "Wait for the detection schematic to finish before starting to hunt the target.", "")]
		[EditorCondition("detectionSchematic.HasAsset", true)]
		[EditorEndCondition]
		[EditorIndent]
		public bool detectionWaitForSchematic = false;


		// hunting range
		[EditorHelp("Use Hunting Range", "The combatant will only hunt within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the hunting range, the combatant will return to its start position.\n" +
			"If disabled, there is no limit to the hunting range.", "")]
		[EditorFoldout("Hunting Range", "Optionally only hunt within a defined range of the combatant's start position.", "")]
		public bool useRange = false;

		[EditorEndFoldout]
		[EditorCondition("useRange", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public RangeValue range;


		// stop range
		[EditorHelp("Use Stop Range", "The combatant will stop when being within a defined range to the target.\n" +
			"If disabled, the combatant will keep running toward the target.", "")]
		[EditorFoldout("Stop Range", "Optionally stop hunting being within a defined range to the target.", "")]
		public bool useStopRange = false;

		[EditorCondition("useStopRange", true)]
		[EditorAutoInit]
		public RangeValue stopRange;

		[EditorHelp("Use Action Range", "The use range of a selected action is used when moving into range.\n" +
			"A combatant will only move into range when the used action is out of range to the target.\n" +
			"If the action doesn't have a use range, the stop range will be used.", "")]
		public bool useActionStopRange = false;

		// target angle
		[EditorSeparator]
		[EditorTitleLabel("Stop Angle")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public MoveAIStopAngle stopAngle = new MoveAIStopAngle();


		// conditions
		[EditorHelp("Conditions Needed", "Select if all or just one condition must be valid to hunt the target.", "")]
		[EditorFoldout("Hunting Conditions", "Optionally only hunt when defined conditions are valid.", "")]
		public Needed needed = Needed.One;

		[EditorEndFoldout]
		[EditorEndCondition]
		[EditorArray("Add Hunting Condition", "Adds a hunting condition.\n" +
			"You can use multiple conditions to determine if the combatant hunts the target.", "",
			"Remove", "Removes this hunting condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Hunting Condition", "Hunting conditions determine if the combatant hunts the target.", ""
			})]
		public MoveCondition[] condition = new MoveCondition[0];

		public MoveAIHunting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useStopAngle"))
			{
				this.stopAngle.SetData(data);
			}
		}


		/*
		============================================================================
		Hunting functions
		============================================================================
		*/
		public bool IsHunting(Combatant combatant, Combatant target)
		{
			if(this.enabled && combatant.IsAggressive)
			{
				return MoveCondition.Check(combatant, target, this.condition, this.needed);
			}
			return false;
		}

		public bool IsInRange(Vector3 startPosition, Combatant combatant)
		{
			return !this.useRange ||
				this.range == null ||
				this.range.InRange(startPosition, combatant.GameObject);
		}

		public bool IsOutOfRange(Vector3 startPosition, Combatant combatant)
		{
			return this.useRange &&
				this.range != null &&
				this.range.OutOfRange(startPosition, combatant.GameObject);
		}

		public void Use(MoveAIComponent moveAI)
		{
			if(this.enabled)
			{
				Vector3 targetPosition = this.GetTargetPosition(moveAI);

				// change target
				if(this.useTargetChange &&
					moveAI.DetectedTargets.Count > 1)
				{
					for(int i = 0; i < moveAI.DetectedTargets.Count; i++)
					{
						if(moveAI.DetectedTargets[i] == moveAI.TargetCombatant)
						{
							break;
						}
						else if(this.IsHunting(moveAI.Combatant, moveAI.DetectedTargets[i]))
						{
							moveAI.SetTarget(moveAI.DetectedTargets[i], MoveAIMode.Hunt);
							return;
						}
					}
				}

				// stop range
				if(this.useStopRange &&
					moveAI.HuntStopRange.InRange(targetPosition, moveAI.Combatant.GameObject, true, 0.1f))
				{
					moveAI.targetPosTimeout = -1;
					moveAI.Stop();
					return;
				}

				// out of range
				if(this.IsOutOfRange(moveAI.startPosition, moveAI.Combatant))
				{
					moveAI.targetLostTimeout = -1;
					moveAI.ClearTarget(false);

					moveAI.SetMode(MoveAIMode.Waypoint);
					moveAI.SetMovePosition(moveAI.startPosition);
					return;
				}
			}

			if(!moveAI.IsTargetLost())
			{
				moveAI.UpdateTargetPosition(true);
			}
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public Vector3 GetTargetPosition(MoveAIComponent moveAI)
		{
			if(moveAI.TargetCombatant != null &&
				moveAI.TargetCombatant.GameObject != null)
			{
				if(this.enabled &&
					this.useStopRange)
				{
					MoveAIStopAngle stopAngle = moveAI.StopAngle != null ? moveAI.StopAngle : this.stopAngle;
					if(stopAngle.useStopAngle)
					{
						return moveAI.HuntStopRange.GetAngledPosition(
							moveAI.TargetCombatant.GameObject,
							stopAngle.stopAngle, stopAngle.stopAngleLocal,
							moveAI.settings.horizontalPlane);
					}
					else
					{
						return Vector3.MoveTowards(
							moveAI.TargetCombatant.GameObject.transform.position,
							moveAI.Combatant.GameObject.transform.position,
							moveAI.HuntStopRange.GetInRangeDistance(
								moveAI.Combatant.GameObject, moveAI.TargetCombatant.GameObject));
					}
				}
				return moveAI.TargetCombatant.GameObject.transform.position;
			}
			else
			{
				return moveAI.Combatant.GameObject.transform.position;
			}
		}

		public bool ReachedTarget(MoveAIComponent moveAI)
		{
			if(this.enabled &&
				this.useStopRange)
			{
				if(moveAI.HuntStopRange.InRange(this.GetTargetPosition(moveAI), moveAI.Combatant.GameObject, true, 0.1f))
				{
					return true;
				}
				return false;
			}
			return true;
		}
	}
}
