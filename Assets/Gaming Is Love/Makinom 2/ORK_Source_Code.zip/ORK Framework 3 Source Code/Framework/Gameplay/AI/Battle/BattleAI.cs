﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public class BattleAIAsset : MakinomGenericAsset<BattleAI>
	{
		public BattleAIAsset()
		{

		}

		public override string DataName
		{
			get { return "Battle AI"; }
		}
	}

	public class BattleAI : BaseIndexData
	{
		public BattleAISettings setting = new BattleAISettings();

		public BattleAI()
		{

		}

		public BattleAI(string n)
		{
			this.setting.name = n;
		}

		public override string EditorName
		{
			get { return this.setting.name; }
			set { this.setting.name = value; }
		}

		public virtual BaseAction GetAction(BattleAICall call)
		{
			return this.setting.GetAction(call);
		}
	}
}
