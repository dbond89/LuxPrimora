﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Game State", "Check if game states are active or inactive.")]
	public class GameStateMoveConditionType : BaseMoveConditionType
	{
		public GameStateCondition gameStates = new GameStateCondition();

		public GameStateMoveConditionType()
		{

		}

		public override string ToString()
		{
			return "Game State";
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			return this.gameStates.Check();
		}
	}
}
