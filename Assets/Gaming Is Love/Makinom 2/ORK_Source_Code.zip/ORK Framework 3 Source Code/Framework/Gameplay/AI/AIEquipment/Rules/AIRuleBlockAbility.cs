﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRuleBlockAbility : BaseData
	{
		// abilities
		[EditorHelp("Block All Abilities", "All abilities are blocked, except for the defined abilities.\n" +
			"If disabled, all abilities are allowed, except for the defined abilities.", "")]
		[EditorFoldout("Block Abilities", "Define abilities that will be blocked from use for the battle AI.\n" +
			"The combatant can still use the abilities (e.g. if the player manually uses them), only the AI can't use them.", "")]
		public bool blockAllAbilities = false;

		[EditorHelp("Block Ability Use", "Select the ability that will be blocked from using.\n" +
			"If 'Block All Abilities' is enabled, the defined abilities will be allowed.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Ability", "Adds an ability that will be blocked from using (or allowed, when using 'Block All Abilities').", "",
			"Remove", "Removes the ability.", "",
			isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Ability", "Select the ability that will be used.", ""
			})]
		public AssetSelection<AbilityAsset>[] ability = new AssetSelection<AbilityAsset>[0];


		// ability types
		[EditorHelp("Block All Types", "All ability types are blocked, except for the defined types.\n" +
			"If disabled, all ability types are allowed, except for the defined types.", "")]
		[EditorFoldout("Block Ability Types", "Define ability types that will be blocked from use for the battle AI, " +
			"abilities of the blocked types will be blocked from use.\n" +
			"The combatant can still use the abilities (e.g. if the player manually uses them), only the AI can't use them.", "")]
		public bool blockAllAbilityTypes = false;

		[EditorHelp("Use Sub-Types", "The sub-types of the defined ability types will also be checked.", "")]
		public bool useSubTypes = false;

		[EditorHelp("Block Ability Type Use", "Select the ability type that will be blocked.\n" +
			"A combatant can't use any ability of the selected type.\n" +
			"If 'Block All Types' is enabled, the defined ability types will be allowed.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Ability Type", "Adds an ability type that will be blocked from using (or allowed, when using 'Block All Types').", "",
			"Remove", "Removes the ability type.", "",
			isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Ability Type", "Select the ability type that will be used.", ""
			})]
		public AssetSelection<AbilityTypeAsset>[] abilityType = new AssetSelection<AbilityTypeAsset>[0];

		public AIRuleBlockAbility()
		{

		}

		public bool CanUse(AbilityShortcut ability)
		{
			// blocked abilities
			if(this.blockAllAbilities)
			{
				for(int i = 0; i < this.ability.Length; i++)
				{
					if(this.ability[i].Is(ability.Setting))
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				for(int i = 0; i < this.ability.Length; i++)
				{
					if(this.ability[i].Is(ability.Setting))
					{
						return false;
					}
				}
			}

			// blocked ability types
			if(this.blockAllAbilityTypes)
			{
				for(int i = 0; i < this.abilityType.Length; i++)
				{
					if(this.abilityType[i].StoredAsset != null && 
						ability.Setting.IsType(this.abilityType[i].StoredAsset.Settings, this.useSubTypes))
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				for(int i = 0; i < this.abilityType.Length; i++)
				{
					if(this.abilityType[i].StoredAsset != null &&
						ability.Setting.IsType(this.abilityType[i].StoredAsset.Settings, this.useSubTypes))
					{
						return false;
					}
				}
			}
			return true;
		}
	}
}
