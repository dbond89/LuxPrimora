﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIBehaviourAsset : MakinomGenericAssetWithType<AIBehaviour, AITypeAsset>
	{
		public AIBehaviourAsset()
		{

		}

		public override string DataName
		{
			get { return "AI Behaviour"; }
		}
	}

	[TextCode(typeof(AIBehaviourAsset), "AI Behaviour", "<aibehaviour.",
		new string[] { "<aibehaviour.name=", "<aibehaviour.shortname=", "<aibehaviour.description=", "<aibehaviour.icon=", "<aibehaviour.custom guid=\"",
			"<aibehaviour.type.name=", "<aibehaviour.type.shortname=", "<aibehaviour.type.description=", "<aibehaviour.type.icon=", "<aibehaviour.type.custom guid=\"",
			"<aibehaviour.inventory=", "<aibehaviour.equipped=", "<statistic.created.aibehaviour=", "<statistic.gained.aibehaviour=" },
		new string[] { "Name", "Short Name", "Description", "Icon", "Custom Content",
			"Type Name", "Type Short Name", "Type Description", "Type Icon", "Type Custom Content",
			"In Inventory", "Equipped", "Statistic Created", "Statistic Gained" })]
	[EditorLanguageExport("AIBehaviour")]
	public class AIBehaviour : BaseLanguageDataWithSubType<AITypeAsset, AIType>, IPortraitContent, ITextCode
	{
		// base settings
		[EditorHelp("AI Type", "Select the AI type of this AI behaviour.\n" +
			"This is the AI type the AI behaviour will belong to and that's used for the behaviour's type text codes.\n" +
			"Add secondary AI types to list the behaviour under multiple AI types in menus or other type checks.", "")]
		[EditorFoldout("Item Settings", "Define the base settings of this AI behaviour.", "")]
		public AssetSelection<AITypeAsset> type = new AssetSelection<AITypeAsset>();

		[EditorHelp("AI Type", "Select the AI type that'll be used as a secondary AI type.\n" +
			"Secondary AI types are used to list AI behaviours under multiple AI types in menus or other type checks.", "")]
		[EditorArray("Add Secondary AI Type", "Adds a secondary AI type.\n" +
			"Secondary AI types are used to list AI behaviours under multiple AI types in menus or other type checks.", "",
			"Remove", "Removes the secondary AI type.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Secondary AI Type", "Select the AI type that will be used as a secondary AI type.\n" +
				"Secondary AI types are used to list AI behaviours under multiple AI types in menus or other type checks.", ""
			})]
		public AssetSelection<AITypeAsset>[] secondaryAIType = new AssetSelection<AITypeAsset>[0];

		[EditorHelp("Use Quantity", "This AI behaviour uses quantity mechanics.\n" +
			"I.e. it can be collected multiple times and each unit " +
			"will be unavailable while being equipped on an AI behaviour slot.\n" +
			"If disabled, the AI behaviour can only be collected once and " +
			"equipping it on a slot doesn't make it unavailable for other combatants/slots.", "")]
		[EditorSeparator]
		public bool useQuantity = false;

		[EditorHelp("Keep 0 Quantity", "Select if this AI behaviour overrides the default 'Keep 0 Quantity' setting:\n" +
			"- Default: Uses the default setting defined in the item type or 'Inventory > Inventory Settings'.\n" +
			"- Yes: This AI behaviour will remain in the inventory with a quantity of 0 when removed.\n" +
			"- No: This AI behaviour will be removed completely.")]
		[EditorCondition("useQuantity", true)]
		[EditorEndCondition]
		public ToggleSettingOverride keepZeroQuantity = ToggleSettingOverride.Default;

		// sympathy
		[EditorHelp("Sympathy Change", "Additional to the faction's take item sympathy change, this value will be added to the change.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		[EditorSeparator]
		public float sympathyChange = 0;

		// chance
		[EditorHelp("Chance (%)", "The chance this AI behaviour will be used.", "")]
		public FloatValue<GameObjectSelection> chanceValue = new FloatValue<GameObjectSelection>(100);

		// price settings
		[EditorFoldout("Price Settings", "Set the prices for buying and selling this AI behaviour.", "")]
		[EditorEndFoldout]
		public PriceSettings price = new PriceSettings();

		// prefab settings
		[EditorHelp("Own Prefab", "Override the default item prefab defined in the inventory settings.")]
		[EditorFoldout("Prefab Settings", "Define the prefab used to display this AI behaviour in a scene.\n" +
			"Optionally use conditional prefabs to display different prefabs based on variable conditions.", "")]
		public bool ownPrefab = false;

		[EditorEndFoldout]
		[EditorCondition("ownPrefab", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ItemPrefabSettings prefabSettings;


		// schematics
		[EditorHelp("Own Inventory Schematics", "This AI behaviour overrides the default inventory schematics ('Inventory > Inventory Settings').")]
		[EditorFoldout("Schematic Settings", "Define custom schematics that are used by this AI behaviour.")]
		public bool ownInventorySchematics = false;

		[EditorCondition("ownInventorySchematics", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public InventorySchematics inventorySchematics;

		// custom schematics
		[EditorFoldout("Custom Schematics", "Custom schematics can be used on an instance of this AI behaviour " +
			"in other schematics using a 'Custom Selected Data Schematic' node.\n" +
			"The AI behaviour is available as (local) selected data via the key 'action'.", "")]
		[EditorEndFoldout(3)]
		[EditorArray("Add Custom Schematic", "Adds a custom schematic.", "",
			"Remove", "Removes the custom schematic.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Custom Schematic", "Define the schematic assets that will be performed when using a " +
				"'Custom Selected Data Schematic' node with a matching key on an instance of this AI behaviour.\n" +
				"The AI behaviour is available as (local) selected data via the key 'action'.", ""
		})]
		public KeySchematicSetting[] customSchematic = new KeySchematicSetting[0];


		// UI settings
		// custom UI
		[EditorHelp("Own Shortcut UI", "Use a different shortcut UI setup for this AI behaviour.")]
		[EditorFoldout("UI Settings", "Define UI related settings for this AI behaviour.", "",
			"Custom Shortcut UI", "Optionally override the default shortcut UI setup for this AI behaviour.", "")]
		public bool ownShortcutUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownShortcutUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings shortcutUI;

		// portraits
		[EditorFoldout("Portraits", "The AI behaviour can display a portrait in menus when it's selected.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Portrait", "Adds a portrait.", "",
			"Remove", "Removes this portrait.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Portrait", "Define the portrait that will be used.", ""
			})]
		public TypePrefabViewPortrait[] portrait = new TypePrefabViewPortrait[0];

		// information overrides
		// custom number format
		[EditorHelp("Own Number Format", "This AI behaviour overrides the default number formats defined in the text display settings.", "")]
		[EditorFoldout("Information Overrides", "Optionally override notifications or console texts for this AI behaviour.", "",
			"Number Format", "This AI behaviour can optionally override the default number format defined in 'UI > Text Display Settings'.", "",
			initialState = false)]
		public bool ownNumberFormat = false;

		[EditorFoldout("Quantity Format", "The format used to display the quantity of this AI behaviour.", "")]
		[EditorEndFoldout(2)]
		[EditorCondition("ownNumberFormat", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AdvancedNumberFormat quantityFormat;

		// notifications
		[EditorHelp("Own Notifications", "This AI behaviour overrides the default item notifications.", "")]
		[EditorFoldout("Notification Settings", "AI behaviours can override the default item notifications.", "")]
		public bool ownNotifications = false;

		[EditorFoldout("AI Behaviour Added", "This notification will be displayed " +
			"when this AI behaviour is added to the player.", "")]
		[EditorEndFoldout]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<quantity> = quantity")]
		[EditorCondition("ownNotifications", true)]
		[EditorAutoInit]
		public AINotification addedNotification;

		[EditorFoldout("AI Behaviour Removed", "This notification will be displayed " +
			"when this AI behaviour is removed from the player.", "")]
		[EditorEndFoldout(2)]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<quantity> = quantity")]
		[EditorEndCondition]
		[EditorAutoInit]
		public AINotification removedNotification;

		// console texts
		[EditorHelp("Own Add Text", "This AI behaviour overrides the default console add text.", "")]
		[EditorFoldout("Console Texts", "An AI behaviour can override the default console texts.", "")]
		public bool ownConsoleAdd = false;

		[EditorFoldout("Add Text", "The text displayed for adding this AI behaviour to the player.", "")]
		[EditorEndFoldout]
		[EditorCondition("ownConsoleAdd", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ConsoleTextAI consoleAdd;

		[EditorHelp("Own Remove Text", "This AI behaviour overrides the default console remove text.", "")]
		[EditorSeparator]
		public bool ownConsoleRemove = false;

		[EditorFoldout("Remove Text", "The text displayed for removing this AI behaviour from the player.", "")]
		[EditorEndFoldout(4)]
		[EditorCondition("ownConsoleRemove", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ConsoleTextAI consoleRemove;


		// move AI
		[EditorHelp("Change On Use", "Only change the move AI when an action of this AI behaviour is used.", "")]
		[EditorFoldout("AI Behaviour Settings", "Define move AI and equip/use conditions for this AI behaviour.", "",
			"Move AI Settings", "Equipping this AI behaviour can influence the move AI of the combatant.", "")]
		public bool moveAIChangeOnUse = false;

		[EditorSeparator]
		[EditorEndFoldout]
		public MoveAIChange moveAIChange = new MoveAIChange();

		// equip conditions
		[EditorHelp("Single Equip", "A combatant can only equip one AI behaviour of this kind.\n" +
			"If disabled, a combatant can equip this AI behaviour multiple times on different slots.", "")]
		[EditorFoldout("Equip Conditions", "Equipping this AI behaviour on an AI behaviour slot " +
			"can depend on valid conditions, e.g. combatant status or variable conditions.\n" +
			"The combatant equipping the AI behaviour is used for the checks.", "")]
		public bool singleEquip = true;

		[EditorHelp("Auto Unequip", "Automatically unequip this AI behaviour when the equip conditions are no longer valid.", "")]
		[EditorCondition("equipConditions.Has", true)]
		[EditorEndCondition]
		public bool autoUnequip = false;

		[EditorSeparator]
		[EditorEndFoldout]
		public CombatantGeneralConditionSettings equipConditions = new CombatantGeneralConditionSettings();

		// user conditions
		[EditorFoldout("User Conditions", "Using this AI behaviour can depend on valid conditions, " +
			"e.g. combatant status or variable conditions.", "")]
		[EditorEndFoldout(2)]
		public CombatantGeneralConditionSettings userConditions = new CombatantGeneralConditionSettings();


		// battle AI
		[EditorFoldout("Battle AI Settings", "Define the battle AIs used by this AI behaviour.")]
		[EditorEndFoldout]
		[EditorArray("Add Battle AI", "Adds a battle AI to this AI behaviour.\n" +
			"The battle AIs will be used in the order they're added (i.e. starting with 'Battle AI 0').", "",
			"Remove", "Removes this battle AI.", "", isMove = true, isCopy = true,
			removeCheckField = "battleAI",
			foldout = true, foldoutText = new string[] {
				"Battle AI", "Define the battle AI that will be used and conditions that must be met.", ""
			})]
		public BattleAISelection[] battleAI = new BattleAISelection[0];

		public AIBehaviour()
		{

		}

		public AIBehaviour(string name) : base(name)
		{

		}

		public virtual ItemPrefabSettings Prefab
		{
			get
			{
				return this.ownPrefab ?
					this.prefabSettings : ORK.InventorySettings.prefabSettings;
			}
		}

		public KeySchematicSetting GetCustomSchematic(string callKey)
		{
			for(int i = 0; i < this.customSchematic.Length; i++)
			{
				if(this.customSchematic[i].callKey == callKey)
				{
					return this.customSchematic[i];
				}
			}
			return null;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public bool CanEquip(Combatant user)
		{
			return (!this.singleEquip || !user.AI.IsAIBehaviourEquipped(this)) &&
				this.equipConditions.Check(user);
		}

		public bool CheckEquipConditions(Combatant user)
		{
			return this.equipConditions.Check(user);
		}

		public bool CheckConditions(Combatant user)
		{
			return Maki.GameSettings.CheckRandom(this.chanceValue.GetValue(user.Call)) &&
				this.userConditions.Check(user);
		}

		public BaseAction GetAction(BattleAICall call)
		{
			BaseAction action = null;
			if(this.CheckConditions(call.user))
			{
				for(int i = 0; i < this.battleAI.Length; i++)
				{
					action = this.battleAI[i].GetAction(call);
					if(action != null)
					{
						break;
					}
				}
			}
			// action move AI changes
			if(action != null &&
				this.moveAIChangeOnUse)
			{
				this.moveAIChange.Change(call.user);
			}
			return action;
		}

		public bool ChangeMoveAI(Combatant user)
		{
			if(!this.moveAIChangeOnUse &&
				this.CheckConditions(user))
			{
				if(this.moveAIChange.Change(user))
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public override AITypeAsset TypeAsset
		{
			get { return this.type.StoredAsset; }
		}

		public override bool IsType(AIType type, bool checkParent)
		{
			if(base.IsType(type, checkParent))
			{
				return true;
			}
			else
			{
				for(int i = 0; i < this.secondaryAIType.Length; i++)
				{
					if(this.secondaryAIType[i].StoredAsset != null &&
						this.secondaryAIType[i].StoredAsset.Settings.IsType(type, checkParent))
					{
						return true;
					}
				}
			}
			return false;
		}

		public override void GetType(List<AIType> addToList)
		{
			base.GetType(addToList);
			for(int i = 0; i < this.secondaryAIType.Length; i++)
			{
				if(this.secondaryAIType[i].StoredAsset != null &&
					!addToList.Contains(this.secondaryAIType[i].StoredAsset.Settings))
				{
					addToList.Add(this.secondaryAIType[i].StoredAsset.Settings);
				}
			}
		}

		public AIType GetSecondaryType(int index)
		{
			if(index < this.secondaryAIType.Length &&
				this.secondaryAIType[index].StoredAsset != null)
			{
				return this.secondaryAIType[index].StoredAsset.Settings;
			}
			return null;
		}

		public ItemType ItemType
		{
			get { return this.TypeData != null ? this.TypeData.ItemType : null; }
		}

		public virtual bool IsItemType(ItemType type, bool checkParent)
		{
			return this.TypeData != null &&
				this.TypeData.IsItemType(type, checkParent);
		}

		public virtual void GetItemType(List<ItemType> addToList)
		{
			if(this.TypeData != null)
			{
				this.TypeData.GetItemType(addToList);
			}
		}

		public IPortrait GetPortrait(PortraitTypeAsset portraitType)
		{
			TypePrefabViewPortrait found = TypePrefabViewPortrait.GetPortrait(portraitType, this.portrait);
			this.Prefab.SetPortraitPrefab(found, null);
			return found;
		}

		public string FormatQuantity(int value)
		{
			if(this.ownNumberFormat)
			{
				return this.quantityFormat.FormatInt(value);
			}
			else if(this.TypeData != null &&
				this.TypeData.behaviourOwnNumberFormat)
			{
				return this.TypeData.behaviourQuantityFormat.FormatInt(value);
			}
			else
			{
				return ORK.TextDisplaySettings.numberFormatting.aiBehaviourQuantityFormat.FormatInt(value);
			}
		}

		public string GetTextCode(int index)
		{
			if(index == 10)
			{
				return this.FormatQuantity(ORK.Game.ActiveGroup.Inventory.AIBehaviours.GetCount(this));
			}
			else if(index == 11)
			{
				return this.FormatQuantity(ORK.Game.ActiveGroup.Inventory.AIBehaviours.GetEquippedCount(this));
			}
			else if(index == 12)
			{
				return this.FormatQuantity(ORK.Statistic.GetCreatedAIBehaviour(this.ID));
			}
			else if(index == 13)
			{
				return this.FormatQuantity(ORK.Statistic.GetGainedAIBehaviour(this.ID));
			}
			return "";
		}
	}
}
