﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Group Size", "Checks the target's group size.")]
	public class GroupSizeMoveConditionType : BaseMoveConditionType
	{
		[EditorHelp("Only Battle Group", "Only the target's battle group is used for the size check.\n" +
			"If disabled, the whole size of the whole group is used (i.e. all available group members).", "")]
		public bool groupSizeOnlyBattle = true;

		[EditorSeparator]
		public ValueCheck<GameObjectSelection> valueCheck = new ValueCheck<GameObjectSelection>(1);

		public GroupSizeMoveConditionType()
		{

		}

		public override string ToString()
		{
			return "Group Size " + this.valueCheck.ToString();
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			DataCall call = this.valueCheck.NeedsCall ? new DataCall(combatant, target) : null;
			if(this.groupSizeOnlyBattle)
			{
				return this.valueCheck.Check(target.Group.BattleSize, call);
			}
			else
			{
				return this.valueCheck.Check(target.Group.Size, call);
			}
		}
	}
}
