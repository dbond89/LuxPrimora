﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public delegate void BattleAICheckSingleTargets(BattleAICall call, List<Combatant> list, List<Combatant> foundTargets);

	public delegate void BattleAICheckSingleTargets2(BattleAICall call, Combatant user, List<Combatant> list, List<Combatant> foundTargets);

	public class BattleAISingleTargetSettings : BaseData
	{
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		public BattleAITargetSettings targetSettings = new BattleAITargetSettings();

		public BattleAISingleTargetSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override string ToString()
		{
			return this.targetSettings + ", " + this.foundType + " found";
		}

		public virtual void Use(BattleAICall call, BattleAICheckSingleTargets check)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				check(call, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				check(call, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			check(call, this.targetSettings.GetTargetList(call), call.foundTargets);
		}

		public virtual void Use(BattleAICall call, Combatant user, BattleAICheckSingleTargets2 check)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				check(call, user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				check(call, user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			check(call, user, this.targetSettings.GetTargetList(call), call.foundTargets);
		}
	}
}
