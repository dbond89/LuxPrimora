﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRulesetSlot : ISaveData, IContent
	{
		protected LanguageContentInformation slotContent;

		protected Combatant owner;

		protected int index = 0;

		protected bool blocked = false;

		protected AIRulesetShortcut ruleset;

		public List<VariableHandler> unregisterHandlers;

		public AIRulesetSlot(Combatant owner, int index)
		{
			this.owner = owner;
			this.index = index;
			this.slotContent = ORK.AIRulesets.GetSlotContent(this.index);
		}

		public virtual Combatant Owner
		{
			get { return this.owner; }
		}

		public virtual int Index
		{
			get { return this.index; }
		}

		public virtual bool Blocked
		{
			get { return this.blocked; }
			set { this.blocked = value; }
		}

		public virtual bool Equipped
		{
			get { return this.ruleset != null; }
		}

		public virtual AIRulesetShortcut AIRuleset
		{
			get { return this.ruleset; }
			set { this.ruleset = value; }
		}

		public virtual void Unequip()
		{
			if(this.ruleset != null)
			{
				this.owner.AI.UnequipAIRulesetSlot(this.index, true, true);
			}
		}

		public virtual void Equip(AIRulesetShortcut ruleset)
		{
			if(ruleset != null)
			{
				this.owner.AI.EquipAIRuleset(ruleset.Setting, this.index, true, true, true);
			}
			else
			{
				this.Unequip();
			}
		}

		public virtual bool IsHighlighted
		{
			get { return ORK.Game.Previews.HighlightedAIRulesetSlot == this; }
		}

		public virtual void SetHighlighted()
		{
			ORK.Game.Previews.HighlightedAIRulesetSlot = this;
		}


		/*
		============================================================================
		Register condition functions
		============================================================================
		*/
		public virtual void CheckSlot()
		{
			if(this.Equipped &&
				this.AIRuleset.Setting.equipConditions.Has &&
				this.AIRuleset.Setting.autoUnequip &&
				!this.AIRuleset.Setting.CanEquip(this.owner))
			{
				this.owner.AI.UnequipAIRulesetSlot(this.index, true, true);
			}
		}

		public virtual void Register()
		{
			if(this.Equipped)
			{
				if(this.AIRuleset.Setting.equipConditions.Has &&
					this.AIRuleset.Setting.autoUnequip &&
					ORK.Access.Combatant.HasStatusAuthority)
				{
					this.AIRuleset.Setting.equipConditions.conditions.Register(
						this.owner.Call, this.CheckSlot, ref this.unregisterHandlers);
				}
			}
		}

		public virtual void Unregister()
		{
			if(this.Equipped &&
				this.AIRuleset.Setting.equipConditions.Has &&
				this.AIRuleset.Setting.autoUnequip &&
				ORK.Access.Combatant.HasStatusAuthority)
			{
				this.AIRuleset.Setting.equipConditions.conditions.Unregister(
					this.owner.Call, this.CheckSlot, this.unregisterHandlers);
				Maki.Pooling.VariableHandlerLists.Add(this.unregisterHandlers);
				this.unregisterHandlers = null;
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual int ID
		{
			get { return this.index; }
		}

		public virtual string GetName()
		{
			return this.slotContent.GetName().
				Replace("<slotindex>", ORK.AIRulesets.GetFormattedSlotIndex(this.index));
		}

		public virtual string GetShortName()
		{
			return this.slotContent.GetShortName().
				Replace("<slotindex>", ORK.AIRulesets.GetFormattedSlotIndex(this.index));
		}

		public virtual string GetDescription()
		{
			return this.slotContent.GetDescription().
				Replace("<slotindex>", ORK.AIRulesets.GetFormattedSlotIndex(this.index));
		}

		public virtual Sprite GetIconSprite()
		{
			return this.slotContent.GetIconSprite();
		}

		public virtual Texture GetIconTexture()
		{
			return this.slotContent.GetIconTexture();
		}

		public virtual string GetIconTextCode()
		{
			return this.slotContent.GetIconTextCode();
		}

		public virtual string GetCustomContent(string contentKey)
		{
			return this.slotContent.GetCustomContent(contentKey).
				Replace("<slotindex>", ORK.AIRulesets.GetFormattedSlotIndex(this.index));
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public virtual DataObject SaveGame()
		{
			DataObject data = new DataObject();

			if(this.ruleset != null)
			{
				data.Set("ruleset", this.ruleset.SaveGame());
			}

			data.Set("blocked", this.blocked);

			return data;
		}

		public virtual void LoadGame(DataObject data)
		{
			this.ruleset = null;
			if(data != null)
			{
				DataObject tmpRuleset = data.GetFile("ruleset");
				if(tmpRuleset != null)
				{
					this.ruleset = new AIRulesetShortcut();
					this.ruleset.LoadGame(tmpRuleset);
					if(this.ruleset.ID < 0 ||
						this.ruleset.ID >= ORK.AIRulesets.Count)
					{
						this.ruleset = null;
					}
				}

				data.Get("blocked", ref this.blocked);
			}
		}
	}
}
