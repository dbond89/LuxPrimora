﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Class Level", "Checks the target's class level.")]
	public class ClassLevelMoveConditionType : BaseMoveConditionType
	{
		[EditorHelp("Use Offset", "The defined level value is added to the combatant's level for the check.\n" +
			"If disabled, only the defined level value is used.", "")]
		public bool levelOffset = true;

		[EditorHelp("Average Level", "Use the target's average group level for the check.\n" +
			"If disabled, the target's level is used.", "")]
		public bool levelAverage = false;

		[EditorHelp("Only Battle Group", "Only the target's battle group is used for the average level.\n" +
			"If disabled, the whole group is used.", "")]
		[EditorCondition("levelAverage", true)]
		[EditorEndCondition]
		public bool levelOnlyBattle = true;

		[EditorSeparator]
		public ValueCheck<GameObjectSelection> valueCheck = new ValueCheck<GameObjectSelection>(1);

		public ClassLevelMoveConditionType()
		{

		}

		public override string ToString()
		{
			return "Class Level " + this.valueCheck.ToString();
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			DataCall call = this.valueCheck.NeedsCall ? new DataCall(combatant, target) : null;
			if(this.levelAverage)
			{
				if(this.levelOnlyBattle)
				{
					return this.levelOffset ?
						this.valueCheck.Check(target.Group.AverageBattleClassLevel, combatant.Class.Level, call) :
						this.valueCheck.Check(target.Group.AverageBattleClassLevel, call);
				}
				else
				{
					return this.levelOffset ?
						this.valueCheck.Check(target.Group.AverageClassLevel, combatant.Class.Level, call) :
						this.valueCheck.Check(target.Group.AverageClassLevel, call);
				}
			}
			else
			{
				return this.levelOffset ?
					this.valueCheck.Check(target.Class.Level, combatant.Class.Level, call) :
					this.valueCheck.Check(target.Class.Level, call);
			}
		}
	}
}
