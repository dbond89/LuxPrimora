﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Research Tree", "The combatant must or mustn't know the defined research tree or have it completed.")]
	public class ResearchTreeStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Research Tree", "Select the research tree that will be used.", "")]
		public AssetSelection<ResearchTreeAsset> researchTree = new AssetSelection<ResearchTreeAsset>();

		[EditorHelp("Research Tree State", "Select the state that will be checked:\n" +
			"- Known: The combatant must know the research tree.\n" +
			"- Unknown: The combatant mustn't know the research tree.\n" +
			"- Complete: The combatant must know the research tree and fully researched all research items.", "")]
		public ResearchTreeStateCheck researchTreeState = ResearchTreeStateCheck.Known;

		public ResearchTreeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.researchTree.ToString() + " is " + this.researchTreeState;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.researchTree.StoredAsset != null &&
				combatant.Research.CheckTreeState(this.researchTree.StoredAsset.Settings, this.researchTreeState);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Research.ChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Research.ChangedSimple -= notify;
		}
	}
}
