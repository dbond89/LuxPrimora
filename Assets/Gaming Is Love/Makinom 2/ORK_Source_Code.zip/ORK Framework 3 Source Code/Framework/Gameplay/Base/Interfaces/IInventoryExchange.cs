﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface IInventoryExchange
	{
		Combatant GetOwner();

		IContent GetContent();

		void CheckDataChanged(bool checkCurrency, bool checkItems, bool checkEquipment,
			bool checkAIBehaviours, bool checkAIRulesets, bool checkCraftingRecipes);

		float Space
		{
			get;
		}

		float TotalSpace
		{
			get;
		}

		bool IsEmpty
		{
			get;
		}

		event Notify Changed;


		/*
		============================================================================
		Item type functions
		============================================================================
		*/
		List<ItemType> GetItemTypes(bool onlySellable,
			bool addCurrency, bool addEmptyCurrency, bool addItems, 
			bool addEquipment, LevelValueCheck equipmentLevelCheck,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes);

		List<ItemType> GetItemTypes(ItemType parentType, bool onlySellable,
			bool addCurrency, bool addEmptyCurrency, bool addItems, 
			bool addEquipment, LevelValueCheck equipmentLevelCheck,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes);

		bool HasNewItemTypes(bool checkParent, List<ItemType> types, bool onlySellable,
			bool addItems, bool addEquipment, LevelValueCheck equipmentLevelCheck,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes);

		bool HasItemType(bool checkParent, ItemType itemType, bool onlySellable,
			bool addCurrency, bool addEmptyCurrency, bool addItems,
			bool addEquipment, LevelValueCheck equipmentLevelCheck,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes, bool checkNewContent);


		/*
		============================================================================
		Inventory functions
		============================================================================
		*/
		void GetAll(bool addCurrency, bool addEmptyCurrency, bool addItems, 
			bool addEquipment, LevelValueCheck equipmentLevelCheck,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes,
			ItemType itemType, bool checkParent, ref List<IInventoryShortcut> list);

		bool AddAccess(IShortcut item, bool showNotification, bool showConsole, bool markNewContent);

		void RemoveAccess(IShortcut item, int quantity, bool showNotification, bool showConsole);

		void DropAccess(IShortcut item, int quantity, bool showNotification, bool showConsole);

		bool CanCollect(IShortcut item, int quantity);

		int GetAllowedQuantity(IShortcut shortcut, int quantity);

		int GetCount(IShortcut item);

		bool HasEnoughCurrency(Currency currency, int quantity);

		int GetCurrency(Currency currency);
	}
}
