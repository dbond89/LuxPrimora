
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Animations
{
	public class AnimationAsset : MakinomGenericAsset<AnimationSetting>
	{
		public AnimationAsset()
		{

		}

		public override string DataName
		{
			get { return "Animation"; }
		}
	}

	public class AnimationSetting : BaseIndexData
	{
		[EditorHelp("Name", "The name of this animation settings.", "")]
		[EditorFoldout("Base Settings", "Set the base settings of this animation settings.", "")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Random First Start Time", "The first animation will start at a random time.\n" +
			"Only used by 'Legacy' and 'Mecanim' animations.", "")]
		[EditorEndFoldout]
		public bool randomFirstStartTime = false;


		// legacy animations
		[EditorFoldout("Legacy Settings", "Settings and animations for legacy animations.\n" +
			"If a combatant uses the legacy animation system, this settings and animations will be used.", "")]
		[EditorEndFoldout]
		[EditorCallback("button:loadlegacyanimationfromprefab", EditorCallbackType.Before)]
		[EditorArray("Add Legacy Animation", "Adds a legacy animation.", "",
			"Remove", "Removes this legacy animation.", "", isCopy = true, isMove = true,
			removeCheckField = "type",
			foldout = true, foldoutText = new string[] {"Legacy Animation", "Define the legacy animation's settings.\n" +
				"An animation type that isn't defined by the animation settings will not be used/overridden by this animation settings.", ""})]
		public ORKLegacyAnimation[] legacy = new ORKLegacyAnimation[0];


		// mecanim animations
		// mecanim base settings
		[EditorHelp("Set Animator Speed", "Set the speed of the mecanim animator.", "")]
		[EditorFoldout("Mecanim Settings", "Settings and animations for mecanim.\n" +
			"If a combatant uses the mecanim animation system, this settings and animations will be used.", "",
			"Auto Parameters", "Automatically set parameters of an animator based on a combatant's movement.", "")]
		public bool mSetSpeed = false;

		[EditorHelp("Speed Value", "Define the playback speed.\n" +
			"1 is the normal playback speed, above 1 will play faster, below 1 will play slower.")]
		[EditorIndent]
		[EditorCondition("mSetSpeed", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<GameObjectSelection> mSpeedValue;

		// auto parameters
		[EditorSeparator]
		[EditorEndFoldout]
		public MecanimAutoParameters autoParameters = new MecanimAutoParameters();

		// change animator controller
		[EditorHelp("Change Animator Controller", "Change the animator controller of the combatant's 'Animator' component.\n" +
			"Supports animator controllers and animator override controllers.\n" +
			"When changing animator controllers, make sure to also change it back to the original in the combatant's standard animation setup.")]
		[EditorFoldout("Change Animator Controller", "Optionally change the animator controller of the combatant's 'Animator' component.\n" +
			"Supports animator controllers and animator override controllers.\n" +
			"When changing animator controllers, make sure to also change it back to the original in the combatant's standard animation setup.", "")]
		public bool changeAnimatorController = false;

		[EditorHelp("Animator Controller", "Select the animator controller or animator override controller that will be used.")]
		[EditorEndFoldout]
		[EditorCondition("changeAnimatorController", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<RuntimeAnimatorController> animatorController;

		// mecanim animations
		[EditorCallback("button:loadmecanimanimationfromprefab", EditorCallbackType.Before)]
		[EditorArray("Add Mecanim Animation", "Adds a mecanim animation.\n" +
			"Mecanim animations are used to set parameters of the animator to trigger the animation.", "",
			"Remove", "Removes this mecanim animation.", "", isCopy = true, isMove = true,
			removeCheckField = "type",
			foldout = true, foldoutText = new string[] {"Mecanim Animation", "Define the mecanim animation's settings.\n" +
				"Mecanim animations are used to set parameters of the animator to trigger the animation.\n" +
				"An animation type that isn't defined by the animation settings will not be used/overridden by this animation settings.", ""})]
		public ORKMecanimAnimation[] mecanim = new ORKMecanimAnimation[0];

		// mecanim state checks
		[EditorEndFoldout]
		[EditorArray("Add State Check", "Adds a mecanim animation state check.\n" +
			"State checks are used to set parameters when a defined animation is playing.", "",
			"Remove", "Removes this state check.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {"State Check", "Define the active state that will be checked and the parameters that will be set.\n" +
				"State checks are used to set parameters when a defined animation is playing.\n" +
				"The state check is executed every Update call on each combatant using mecanim animations.", ""})]
		public MecanimStateCheck[] mecanimStateCheck = new MecanimStateCheck[0];


		// custom animations
		[EditorFoldout("Custom Settings", "Settings and animations for custom animations.\n" +
			"If a combatant uses a custom animation system, this settings and animations will be used.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Custom Animation", "Adds a custom animation.", "",
			"Remove", "Removes this custom animation.", "", isCopy = true, isMove = true,
			removeCheckField = "type",
			foldout = true, foldoutText = new string[] {"Custom Animation", "Define the custom animation's settings.\n" +
				"Custom animations will use reflection to call functions of the custom animation component defined by the combatant.\n" +
				"An animation type that isn't defined by the animation settings will not be used/overridden by this animation settings.", ""})]
		public CustomAnimation[] custom = new CustomAnimation[0];

		public AnimationSetting()
		{

		}

		public AnimationSetting(string name) : base(name)
		{
			this.name = name;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("mSetAutoHorizontal"))
			{
				this.autoParameters.SetData(data);
			}
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}


		/*
		============================================================================
		Legacy animation functions
		============================================================================
		*/
		public void LegacyInit(Combatant combatant, Animation animation)
		{
			for(int i = 0; i < this.legacy.Length; i++)
			{
				this.legacy[i].Init(combatant, animation);
			}
		}

		public bool LegacyPlay(out AnimInfo info, Animation animation, AnimationTypeAsset type, Combatant user, bool randomFirstTime)
		{
			for(int i = 0; i < this.legacy.Length; i++)
			{
				if(this.legacy[i].type.Is(type))
				{
					this.legacy[i].RemoveStop(user);
					info = this.legacy[i].Play(animation,
						randomFirstTime && this.randomFirstStartTime);
					return true;
				}
			}
			info = AnimInfo.None;
			return false;
		}

		public bool LegacyStop(Animation animation, AnimationTypeAsset type, Combatant user)
		{
			for(int i = 0; i < this.legacy.Length; i++)
			{
				if(type == null || this.legacy[i].type.Is(type))
				{
					this.legacy[i].Stop(animation, user);
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Mecanim animation functions
		============================================================================
		*/
		public void MecanimInit(Combatant combatant, Animator animator)
		{
			if(this.mSetSpeed)
			{
				animator.speed = this.mSpeedValue.GetValue(combatant.Call) * ORK.Game.AnimationFactor;
			}
		}

		public bool MecanimPlay(out AnimInfo info, Animator animator, AnimationTypeAsset type, bool randomFirstTime)
		{
			for(int i = 0; i < this.mecanim.Length; i++)
			{
				if(this.mecanim[i].type.Is(type))
				{
					info = this.mecanim[i].Play(animator,
						randomFirstTime && this.randomFirstStartTime);
					return true;
				}
			}
			info = AnimInfo.None;
			return false;
		}

		public bool MecanimStop(Animator animator, AnimationTypeAsset type)
		{
			for(int i = 0; i < this.mecanim.Length; i++)
			{
				if(type == null || this.mecanim[i].type.Is(type))
				{
					this.mecanim[i].Stop(animator);
					return true;
				}
			}
			return false;
		}

		public void CheckMecanimStates(Animator animator)
		{
			for(int i = 0; i < this.mecanimStateCheck.Length; i++)
			{
				this.mecanimStateCheck[i].Check(animator);
			}
		}


		/*
		============================================================================
		Custom animation functions
		============================================================================
		*/
		public void CustomInit(Component behaviour)
		{
			/*for(int i=0; i<this.custom.Length; i++)
			{
				this.custom[i].Init(combatant, behaviour);
			}*/
		}

		public bool CustomPlay(out AnimInfo info, Combatant combatant, Component behaviour, AnimationTypeAsset type)
		{
			info = new AnimInfo(AnimationSystem.Custom, "", 0);
			for(int i = 0; i < this.custom.Length; i++)
			{
				if(this.custom[i].type.Is(type))
				{
					this.custom[i].Play(combatant, behaviour);
					return true;
				}
			}
			return false;
		}

		public bool CustomStop(Combatant combatant, Component behaviour, AnimationTypeAsset type)
		{
			for(int i = 0; i < this.custom.Length; i++)
			{
				if(type == null || this.custom[i].type.Is(type))
				{
					this.custom[i].Stop(combatant, behaviour);
					return true;
				}
			}
			return false;
		}
	}
}
