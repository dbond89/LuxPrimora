﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public static class GeneralConditionExtensions
	{
		public static bool ContainsCondition<T>(this GeneralConditionSetting<T> setting, ResearchTreeSetting researchTree, int researchItemIndex) where T : IObjectSelection, new()
		{
			for(int i = 0; i < setting.condition.Length; i++)
			{
				if(setting.condition[i].settings is GeneralConditionTemplateGeneralCondition<T>)
				{
					GeneralConditionTemplateGeneralCondition<T> condition = (GeneralConditionTemplateGeneralCondition<T>)setting.condition[i].settings;
					if(condition.template.StoredAsset != null &&
						condition.template.StoredAsset.Settings.condition.ContainsCondition(researchTree, researchItemIndex))
					{
						return true;
					}
				}
				else if(setting.condition[i].settings is CombatantStatusGeneralCondition<T>)
				{
					CombatantStatusGeneralCondition<T> condition = (CombatantStatusGeneralCondition<T>)setting.condition[i].settings;
					for(int j = 0; j < condition.conditions.condition.Length; j++)
					{
						if(condition.conditions.condition[j].ContainsCondition(researchTree, researchItemIndex))
						{
							return true;
						}
					}
				}
			}
			return false;
		}
	}
}
