
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Combatants;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Status Value", "A combatant's current, base or maximum status value is used.", "")]
	[NodeInfo("Combatant")]
	public class StatusValueNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("From All", "Use all combatants stored in selected data.", "")]
		[EditorSeparator]
		[EditorCondition("origin.origin", StatusOrigin.Selected)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool fromAllSelectedData = false;

		[EditorHelp("Status Value", "Select the status value that will be used as value.\n" +
			"You can use the current value or maximum value of the status value.", "")]
		[EditorSeparator]
		public AssetSelection<StatusValueAsset> status = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Value Origin", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.\n" +
			"- To Maximum: The difference between maximum and current value.", "")]
		public StatusValueOrigin svOrigin = StatusValueOrigin.Current;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorHelp("Multi Value Use", "Select how values of multiple combatants will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[EditorCondition("combatantScope", MenuCombatantScope.Battle)]
		[EditorCondition("combatantScope", MenuCombatantScope.Group)]
		[EditorCondition("combatantScope", MenuCombatantScope.NonBattle)]
		[EditorCondition("combatantScope", MenuCombatantScope.BattleReserve)]
		[EditorCondition("combatantScope", MenuCombatantScope.NonBattleReserve)]
		[EditorCondition("combatantScope", MenuCombatantScope.GroupBattleSorted)]
		[EditorCondition("fromAllSelectedData", true)]
		[EditorEndCondition]
		public MultiFloatValueUse multiValueType = MultiFloatValueUse.Add;

		public StatusValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("wholeGroup"))
			{
				bool tmp = false;
				data.Get("wholeGroup", ref tmp);
				if(tmp)
				{
					tmp = false;
					data.Get("onlyBattle", ref tmp);
					this.combatantScope = tmp ? MenuCombatantScope.Battle : MenuCombatantScope.Group;
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.status.StoredAsset != null)
			{
				if(StatusOrigin.Selected == this.origin.origin &&
					this.fromAllSelectedData)
				{
					List<Combatant> combatants = this.origin.selectedData.GetSelectedData<Combatant>(call, ORKSelectedDataHelper.GetCombatants);
					List<float> values = new List<float>();

					for(int i = 0; i < combatants.Count; i++)
					{
						if(combatants[i] != null)
						{
							if(MenuCombatantScope.Current == this.combatantScope)
							{
								if(StatusValueOrigin.Base == this.svOrigin)
								{
									values.Add(combatants[i].Status.Get(this.status.StoredAsset.Settings).GetBaseValue());
								}
								else if(StatusValueOrigin.Current == this.svOrigin)
								{
									values.Add(combatants[i].Status.Get(this.status.StoredAsset.Settings).GetValue());
								}
								else if(StatusValueOrigin.Maximum == this.svOrigin)
								{
									values.Add(combatants[i].Status.Get(this.status.StoredAsset.Settings).GetMaxValue());
								}
								else if(StatusValueOrigin.ToMaximum == this.svOrigin)
								{
									StatusValue sv = combatants[i].Status.Get(this.status.StoredAsset.Settings);
									values.Add(sv.GetMaxValue() - sv.GetValue());
								}
							}
							else
							{
								List<Combatant> group = new List<Combatant>();
								combatants[i].Group.GetMembers(this.combatantScope, ref group);
								for(int j = 0; j < group.Count; j++)
								{
									if(group[j] != null)
									{
										if(StatusValueOrigin.Base == this.svOrigin)
										{
											values.Add(group[j].Status.Get(this.status.StoredAsset.Settings).GetBaseValue());
										}
										else if(StatusValueOrigin.Current == this.svOrigin)
										{
											values.Add(group[j].Status.Get(this.status.StoredAsset.Settings).GetValue());
										}
										else if(StatusValueOrigin.Maximum == this.svOrigin)
										{
											values.Add(group[j].Status.Get(this.status.StoredAsset.Settings).GetMaxValue());
										}
										else if(StatusValueOrigin.ToMaximum == this.svOrigin)
										{
											StatusValue sv = group[j].Status.Get(this.status.StoredAsset.Settings);
											values.Add(sv.GetMaxValue() - sv.GetValue());
										}
									}
								}
							}
						}
					}

					float value = 0;
					if(values.Count > 0)
					{
						value = ValueHelper.GetMultiValue(values, this.multiValueType);
					}
					this.formulaOperator.Use(ref call.result, value);
				}
				else
				{
					Combatant c = this.origin.GetCombatant(call);
					if(c != null)
					{
						float value = 0;
						if(MenuCombatantScope.Current == this.combatantScope)
						{
							if(StatusValueOrigin.Base == this.svOrigin)
							{
								value = c.Status.Get(this.status.StoredAsset.Settings).GetBaseValue();
							}
							else if(StatusValueOrigin.Current == this.svOrigin)
							{
								value = c.Status.Get(this.status.StoredAsset.Settings).GetValue();
							}
							else if(StatusValueOrigin.Maximum == this.svOrigin)
							{
								value = c.Status.Get(this.status.StoredAsset.Settings).GetMaxValue();
							}
							else if(StatusValueOrigin.ToMaximum == this.svOrigin)
							{
								StatusValue sv = c.Status.Get(this.status.StoredAsset.Settings);
								value = sv.GetMaxValue() - sv.GetValue();
							}
						}
						else
						{
							List<Combatant> group = new List<Combatant>();
							c.Group.GetMembers(this.combatantScope, ref group);
							value = this.GetGroupValue(group);
						}
						this.formulaOperator.Use(ref call.result, value);
					}
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			if(this.status.StoredAsset != null)
			{
				if(StatusOrigin.Selected == this.origin.origin &&
					this.fromAllSelectedData)
				{
					List<Combatant> combatants = this.origin.selectedData.GetSelectedData<Combatant>(call, ORKSelectedDataHelper.GetCombatants);
					List<float> values = new List<float>();

					for(int i = 0; i < combatants.Count; i++)
					{
						if(combatants[i] != null)
						{
							if(MenuCombatantScope.Current == this.combatantScope)
							{
								if(StatusValueOrigin.Base == this.svOrigin)
								{
									values.Add(combatants[i].Status.Get(this.status.StoredAsset.Settings).GetBaseValue());
								}
								else if(StatusValueOrigin.Current == this.svOrigin)
								{
									values.Add(combatants[i].Status.Get(this.status.StoredAsset.Settings).GetPreviewValue(false));
								}
								else if(StatusValueOrigin.Maximum == this.svOrigin)
								{
									values.Add(combatants[i].Status.Get(this.status.StoredAsset.Settings).GetPreviewMaxValue());
								}
								else if(StatusValueOrigin.ToMaximum == this.svOrigin)
								{
									StatusValue sv = combatants[i].Status.Get(this.status.StoredAsset.Settings);
									values.Add(sv.GetPreviewMaxValue() - sv.GetPreviewValue(false));
								}
							}
							else
							{
								List<Combatant> group = new List<Combatant>();
								combatants[i].Group.GetMembers(this.combatantScope, ref group);
								for(int j = 0; j < group.Count; j++)
								{
									if(group[j] != null)
									{
										if(StatusValueOrigin.Base == this.svOrigin)
										{
											values.Add(group[j].Status.Get(this.status.StoredAsset.Settings).GetBaseValue());
										}
										else if(StatusValueOrigin.Current == this.svOrigin)
										{
											values.Add(group[j].Status.Get(this.status.StoredAsset.Settings).GetPreviewValue(false));
										}
										else if(StatusValueOrigin.Maximum == this.svOrigin)
										{
											values.Add(group[j].Status.Get(this.status.StoredAsset.Settings).GetPreviewMaxValue());
										}
										else if(StatusValueOrigin.ToMaximum == this.svOrigin)
										{
											StatusValue sv = group[j].Status.Get(this.status.StoredAsset.Settings);
											values.Add(sv.GetPreviewMaxValue() - sv.GetPreviewValue(false));
										}
									}
								}
							}
						}
					}

					float value = 0;
					if(values.Count > 0)
					{
						value = ValueHelper.GetMultiValue(values, this.multiValueType);
					}
					this.formulaOperator.Use(ref call.result, value);
				}
				else
				{
					Combatant c = this.origin.GetCombatant(call);
					if(c != null)
					{
						float value = 0;
						if(MenuCombatantScope.Current == this.combatantScope)
						{
							if(StatusValueOrigin.Base == this.svOrigin)
							{
								value = c.Status.Get(this.status.StoredAsset.Settings).GetBaseValue();
							}
							else if(StatusValueOrigin.Current == this.svOrigin)
							{
								value = c.Status.Get(this.status.StoredAsset.Settings).GetPreviewValue(false);
							}
							else if(StatusValueOrigin.Maximum == this.svOrigin)
							{
								value = c.Status.Get(this.status.StoredAsset.Settings).GetPreviewMaxValue();
							}
							else if(StatusValueOrigin.ToMaximum == this.svOrigin)
							{
								StatusValue sv = c.Status.Get(this.status.StoredAsset.Settings);
								value = sv.GetPreviewMaxValue() - sv.GetPreviewValue(false);
							}
						}
						else
						{
							List<Combatant> group = new List<Combatant>();
							c.Group.GetMembers(this.combatantScope, ref group);
							value = this.GetGroupValuePreview(group);
						}
						this.formulaOperator.Use(ref call.result, value);
					}
				}
			}
			return this.next;
		}

		private float GetGroupValue(List<Combatant> list)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(StatusValueOrigin.Base == this.svOrigin)
					{
						values.Add(list[i].Status.Get(this.status.StoredAsset.Settings).GetBaseValue());
					}
					else if(StatusValueOrigin.Current == this.svOrigin)
					{
						values.Add(list[i].Status.Get(this.status.StoredAsset.Settings).GetValue());
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin)
					{
						values.Add(list[i].Status.Get(this.status.StoredAsset.Settings).GetMaxValue());
					}
					else if(StatusValueOrigin.ToMaximum == this.svOrigin)
					{
						StatusValue sv = list[i].Status.Get(this.status.StoredAsset.Settings);
						values.Add(sv.GetMaxValue() - sv.GetValue());
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, this.multiValueType);
			}
			return 0;
		}

		private float GetGroupValuePreview(List<Combatant> list)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(StatusValueOrigin.Base == this.svOrigin)
					{
						values.Add(list[i].Status.Get(this.status.StoredAsset.Settings).GetBaseValue());
					}
					else if(StatusValueOrigin.Current == this.svOrigin)
					{
						values.Add(list[i].Status.Get(this.status.StoredAsset.Settings).GetPreviewValue(false));
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin)
					{
						values.Add(list[i].Status.Get(this.status.StoredAsset.Settings).GetPreviewMaxValue());
					}
					else if(StatusValueOrigin.ToMaximum == this.svOrigin)
					{
						StatusValue sv = list[i].Status.Get(this.status.StoredAsset.Settings);
						values.Add(sv.GetPreviewMaxValue() - sv.GetPreviewValue(false));
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, this.multiValueType);
			}
			return 0;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() + " " +
				this.svOrigin + " " + this.status.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Random Status Value", "A random value between two status values of combatants is used.", "")]
	[NodeInfo("Combatant")]
	public class RandomStatusValueNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorHelp("As Int", "The random value will be used as an integer (i.e. whole number).\n" +
			"If disabled, the random value will be a float.", "")]
		public bool asInt = false;


		// value 1
		[EditorFoldout("Status Value 1", "Settings for the 1st status value.", "")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Status Value 1", "Select the status value that will be used as value.\n" +
			"You can use the current value, base value or maximum value of the status value.", "")]
		[EditorSeparator]
		public AssetSelection<StatusValueAsset> status = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Value Origin 1", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.\n" +
			"- To Maximum: The difference between maximum and current value.", "")]
		public StatusValueOrigin svOrigin = StatusValueOrigin.Current;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorHelp("Multi Value Use", "Select how values of multiple combatants will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public MultiFloatValueUse multiValueType = MultiFloatValueUse.Add;


		// value 2
		[EditorFoldout("Status Value 2", "Settings for the 2nd status value.", "")]
		public FormulaStatusOrigin origin2 = new FormulaStatusOrigin();

		[EditorHelp("Status Value 2", "Select the status value that will be used as value.\n" +
			"You can use the current value, base value or maximum value of the status value.", "")]
		[EditorSeparator]
		public AssetSelection<StatusValueAsset> status2 = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Value Origin 2", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.\n" +
			"- To Maximum: The difference between maximum and current value.", "")]
		public StatusValueOrigin svOrigin2 = StatusValueOrigin.Current;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		public MenuCombatantScope combatantScope2 = MenuCombatantScope.Current;

		[EditorHelp("Multi Value Use 2", "Select how values of multiple combatants will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public MultiFloatValueUse multiValueType2 = MultiFloatValueUse.Add;

		public RandomStatusValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("wholeGroup"))
			{
				bool tmp = false;
				data.Get("wholeGroup", ref tmp);
				if(tmp)
				{
					tmp = false;
					data.Get("onlyBattle", ref tmp);
					this.combatantScope = tmp ? MenuCombatantScope.Battle : MenuCombatantScope.Group;
				}
				tmp = false;
				data.Get("wholeGroup2", ref tmp);
				if(tmp)
				{
					tmp = false;
					data.Get("onlyBattle2", ref tmp);
					this.combatantScope2 = tmp ? MenuCombatantScope.Battle : MenuCombatantScope.Group;
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.status.StoredAsset != null)
			{
				Combatant c = this.origin.GetCombatant(call);
				if(c != null)
				{
					float value = 0;
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						if(StatusValueOrigin.Base == this.svOrigin)
						{
							value = c.Status.Get(this.status.StoredAsset.Settings).GetBaseValue();
						}
						else if(StatusValueOrigin.Current == this.svOrigin)
						{
							value = c.Status.Get(this.status.StoredAsset.Settings).GetValue();
						}
						else if(StatusValueOrigin.Maximum == this.svOrigin)
						{
							value = c.Status.Get(this.status.StoredAsset.Settings).GetMaxValue();
						}
						else if(StatusValueOrigin.ToMaximum == this.svOrigin)
						{
							StatusValue sv = c.Status.Get(this.status.StoredAsset.Settings);
							value = sv.GetMaxValue() - sv.GetValue();
						}
					}
					else
					{
						List<Combatant> group = new List<Combatant>();
						c.Group.GetMembers(this.combatantScope, ref group);
						value = this.GetGroupValue(group, this.multiValueType, this.svOrigin, this.status.StoredAsset.Settings);
					}

					c = this.origin2.GetCombatant(call);
					if(c != null)
					{
						float value2 = 0;
						if(MenuCombatantScope.Current == this.combatantScope2)
						{
							if(this.status2.StoredAsset != null)
							{
								if(StatusValueOrigin.Base == this.svOrigin2)
								{
									value2 = c.Status.Get(this.status2.StoredAsset.Settings).GetBaseValue();
								}
								else if(StatusValueOrigin.Current == this.svOrigin2)
								{
									value2 = c.Status.Get(this.status2.StoredAsset.Settings).GetValue();
								}
								else if(StatusValueOrigin.Maximum == this.svOrigin2)
								{
									value2 = c.Status.Get(this.status2.StoredAsset.Settings).GetMaxValue();
								}
								else if(StatusValueOrigin.ToMaximum == this.svOrigin2)
								{
									StatusValue sv = c.Status.Get(this.status2.StoredAsset.Settings);
									value2 = sv.GetMaxValue() - sv.GetValue();
								}
							}
						}
						else
						{
							List<Combatant> group = new List<Combatant>();
							c.Group.GetMembers(this.combatantScope2, ref group);
							value = this.GetGroupValue(group, this.multiValueType2, this.svOrigin2, this.status2.StoredAsset.Settings);
						}

						if(value < value2)
						{
							this.formulaOperator.Use(ref call.result,
								this.asInt ? (int)UnityWrapper.Range(value, value2) : UnityWrapper.Range(value, value2));
						}
						else if(value > value2)
						{
							this.formulaOperator.Use(ref call.result,
								this.asInt ? (int)UnityWrapper.Range(value2, value) : UnityWrapper.Range(value2, value));
						}
						else
						{
							this.formulaOperator.Use(ref call.result, this.asInt ? (int)value : value);
						}
					}
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			if(this.status.StoredAsset != null)
			{
				Combatant c = this.origin.GetCombatant(call);
				if(c != null)
				{
					float value = 0;
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						if(StatusValueOrigin.Base == this.svOrigin)
						{
							value = c.Status.Get(this.status.StoredAsset.Settings).GetBaseValue();
						}
						else if(StatusValueOrigin.Current == this.svOrigin)
						{
							value = c.Status.Get(this.status.StoredAsset.Settings).GetPreviewValue(false);
						}
						else if(StatusValueOrigin.Maximum == this.svOrigin)
						{
							value = c.Status.Get(this.status.StoredAsset.Settings).GetPreviewMaxValue();
						}
						else if(StatusValueOrigin.ToMaximum == this.svOrigin)
						{
							StatusValue sv = c.Status.Get(this.status.StoredAsset.Settings);
							value = sv.GetPreviewMaxValue() - sv.GetPreviewValue(false);
						}
					}
					else
					{
						List<Combatant> group = new List<Combatant>();
						c.Group.GetMembers(this.combatantScope, ref group);
						value = this.GetGroupValuePreview(group, this.multiValueType, this.svOrigin, this.status.StoredAsset.Settings);
					}

					c = this.origin2.GetCombatant(call);
					if(c != null)
					{
						float value2 = 0;
						if(MenuCombatantScope.Current == this.combatantScope2)
						{
							if(this.status2.StoredAsset != null)
							{
								if(StatusValueOrigin.Base == this.svOrigin2)
								{
									value2 = c.Status.Get(this.status2.StoredAsset.Settings).GetBaseValue();
								}
								else if(StatusValueOrigin.Current == this.svOrigin2)
								{
									value2 = c.Status.Get(this.status2.StoredAsset.Settings).GetPreviewValue(false);
								}
								else if(StatusValueOrigin.Maximum == this.svOrigin2)
								{
									value2 = c.Status.Get(this.status2.StoredAsset.Settings).GetPreviewMaxValue();
								}
								else if(StatusValueOrigin.ToMaximum == this.svOrigin2)
								{
									StatusValue sv = c.Status.Get(this.status2.StoredAsset.Settings);
									value = sv.GetPreviewMaxValue() - sv.GetPreviewValue(false);
								}
							}
						}
						else
						{
							List<Combatant> group = new List<Combatant>();
							c.Group.GetMembers(this.combatantScope2, ref group);
							value = this.GetGroupValuePreview(group, this.multiValueType2, this.svOrigin2, this.status2.StoredAsset.Settings);
						}

						if(value < value2)
						{
							this.formulaOperator.Use(ref call.result,
								this.asInt ? (int)UnityWrapper.Range(value, value2) : UnityWrapper.Range(value, value2));
						}
						else if(value > value2)
						{
							this.formulaOperator.Use(ref call.result,
								this.asInt ? (int)UnityWrapper.Range(value2, value) : UnityWrapper.Range(value2, value));
						}
						else
						{
							this.formulaOperator.Use(ref call.result, this.asInt ? (int)value : value);
						}
					}
				}
			}
			return this.next;
		}

		private float GetGroupValue(List<Combatant> list, MultiFloatValueUse multiUse, StatusValueOrigin tmpSVOrigin, StatusValueSetting svSetting)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(StatusValueOrigin.Base == tmpSVOrigin)
					{
						values.Add(list[i].Status.Get(svSetting).GetBaseValue());
					}
					else if(StatusValueOrigin.Current == tmpSVOrigin)
					{
						values.Add(list[i].Status.Get(svSetting).GetValue());
					}
					else if(StatusValueOrigin.Maximum == tmpSVOrigin)
					{
						values.Add(list[i].Status.Get(svSetting).GetMaxValue());
					}
					else if(StatusValueOrigin.ToMaximum == tmpSVOrigin)
					{
						StatusValue sv = list[i].Status.Get(svSetting);
						values.Add(sv.GetMaxValue() - sv.GetValue());
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, multiUse);
			}
			return 0;
		}

		private float GetGroupValuePreview(List<Combatant> list, MultiFloatValueUse multiUse, StatusValueOrigin tmpSVOrigin, StatusValueSetting svSetting)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(StatusValueOrigin.Base == tmpSVOrigin)
					{
						values.Add(list[i].Status.Get(svSetting).GetBaseValue());
					}
					else if(StatusValueOrigin.Current == tmpSVOrigin)
					{
						values.Add(list[i].Status.Get(svSetting).GetPreviewValue(false));
					}
					else if(StatusValueOrigin.Maximum == tmpSVOrigin)
					{
						values.Add(list[i].Status.Get(svSetting).GetPreviewMaxValue());
					}
					else if(StatusValueOrigin.ToMaximum == tmpSVOrigin)
					{
						StatusValue sv = list[i].Status.Get(svSetting);
						values.Add(sv.GetPreviewMaxValue() - sv.GetPreviewValue(false));
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, multiUse);
			}
			return 0;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() + " " +
				this.svOrigin + " " + this.status.ToString() + " ~ " +
				this.origin2.ToString() + " " + this.svOrigin2 + " " + this.status2.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Attack Modifier Attribute", "A combatant's current attack modifier attribute value is used.", "")]
	[NodeInfo("Combatant")]
	public class AttackModifierAttributeNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public AttackModifierAttributeSelection attackModifier = new AttackModifierAttributeSelection();

		public AttackModifierAttributeNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				this.formulaOperator.Use(ref call.result,
					this.attackModifier.GetValue(c, ModifierGetValue.CurrentValue));
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				this.formulaOperator.Use(ref call.result,
					this.attackModifier.GetValue(c, ModifierGetValue.PreviewValue));
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() + " " + this.attackModifier.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Defence Modifier Attribute", "A combatant's current defence modifier attribute value is used.", "")]
	[NodeInfo("Combatant")]
	public class DefenceModifierAttributeNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public DefenceModifierAttributeSelection defenceModifier = new DefenceModifierAttributeSelection();

		public DefenceModifierAttributeNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				this.formulaOperator.Use(ref call.result,
					this.defenceModifier.GetValue(c, ModifierGetValue.CurrentValue));
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				this.formulaOperator.Use(ref call.result,
					this.defenceModifier.GetValue(c, ModifierGetValue.PreviewValue));
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() + " " + this.defenceModifier.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Level", "A combatant's current or maximum level (or class level) is used.", "")]
	[NodeInfo("Combatant")]
	public class LevelNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Class Level", "The class level of the combatant is used.\n" +
			"If disabled, the base level is used.", "")]
		[EditorSeparator]
		public bool useClass = false;

		[EditorHelp("Use Maximum", "The maximum level is used.\n" +
			"If disabled, the current level is used.", "")]
		public bool useMax = false;

		[EditorHelp("Use Average", "Use the average level of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		public LevelNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useClass)
				{
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ? c.Group.AverageBattleMaxClassLevel : c.Group.AverageBattleClassLevel;
						}
						else
						{
							value = this.useMax ? c.Group.AverageMaxClassLevel : c.Group.AverageClassLevel;
						}
					}
					else
					{
						value = this.useMax ? c.Class.MaxLevel : c.Class.Level;
					}
				}
				else
				{
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ? c.Group.AverageBattleMaxLevel : c.Group.AverageBattleLevel;
						}
						else
						{
							value = this.useMax ? c.Group.AverageMaxLevel : c.Group.AverageLevel;
						}
					}
					else
					{
						value = this.useMax ? c.Status.MaxLevel : c.Status.Level;
					}
				}
				this.formulaOperator.Use(ref call.result, value);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() +
				(this.useAverage ? " Avg. " : " ") + (this.useMax ? "Max " : "") +
				(this.useClass ? "Class Level" : "Level");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Class Slot Level", "A combatant's current or maximum class level of a class equipped on a class slot is used.", "")]
	[NodeInfo("Combatant")]
	public class ClassSlotLevelNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Class Slot", "Select the class slot that will be used.\n" +
			"The used value will be 0 if the class slot isn't available on the combatant or no class is equipped on it.")]
		[EditorSeparator]
		public AssetSelection<ClassSlotAsset> classSlot = new AssetSelection<ClassSlotAsset>();

		[EditorHelp("Use Maximum", "The maximum level is used.\n" +
			"If disabled, the current level is used.", "")]
		public bool useMax = false;

		[EditorHelp("Use Average", "Use the average level of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		public ClassSlotLevelNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					List<Combatant> group = this.onlyBattle ? c.Group.GetBattle() : c.Group.GetGroup();
					if(group.Count > 0)
					{
						int lvl = 0;
						for(int i = 0; i < group.Count; i++)
						{
							lvl += this.GetLevel(group[i]);
						}
						value = lvl / group.Count;
					}
				}
				else
				{
					value = this.GetLevel(c);
				}
				this.formulaOperator.Use(ref call.result, value);
			}
			return this.next;
		}

		protected virtual int GetLevel(Combatant c)
		{
			ClassSlot slot = c.Class.GetSlot(this.classSlot.StoredAsset.Settings);
			if(slot != null &&
				slot.Available &&
				slot.Equipped)
			{
				return this.useMax ? slot.Class.MaxLevel : slot.Class.Level;
			}
			return 0;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() +
				(this.useAverage ? " Avg. " : " ") + (this.useMax ? "Max " : "") +
				this.classSlot.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Turn", "A combatant's current turn number is used.", "")]
	[NodeInfo("Combatant")]
	public class TurnNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Average", "Use the average turn number of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		public TurnNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = c.Group.AverageBattleTurn;
					}
					else
					{
						value = c.Group.AverageTurn;
					}
				}
				else
				{
					value = c.Battle.Turn;
				}
				this.formulaOperator.Use(ref call.result, value);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() +
				(this.useAverage ? " Avg. Turn" : " Turn");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Turn", "Checks a combatant's turn.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckTurnNode : BaseFormulaCheckNode
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Average", "Use the average turn number of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;


		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckTurnNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = this.check.Check(
					this.useAverage ?
						(this.onlyBattle ? c.Group.AverageBattleTurn : c.Group.AverageTurn) :
						c.Battle.Turn,
					call);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Turn Value", "A combatant's current turn value is used.\n" +
		"The turn value is used in to generate the turn order in 'Turn Based Battles' using 'Multi Turns'.", "")]
	[NodeInfo("Combatant")]
	public class TurnValueNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		public TurnValueNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = c.Group.AverageBattleTurnValue;
					}
					else
					{
						value = c.Group.AverageTurnValue;
					}
				}
				else
				{
					value = c.Battle.TurnValue;
				}
				this.formulaOperator.Use(ref call.result, value);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() +
				(this.useAverage ? " Avg. Turn Value" : " Turn Value");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Turn Value", "Checks a combatant's turn value.\n" +
		"The turn value is used to generate the turn order in 'Turn Based Battles' using 'Multi Turns'.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Check", "Combatant")]
	public class CheckTurnValueNode : BaseFormulaCheckNode
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckTurnValueNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = this.check.Check(
					this.useAverage ?
						(this.onlyBattle ? c.Group.AverageBattleTurnValue : c.Group.AverageTurnValue) :
						c.Battle.TurnValue,
					call);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Action Bar", "A combatant's current action bar is used.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant.", "")]
	[NodeInfo("Combatant")]
	public class ActionBarNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Used Action Bar", "Use the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.", "")]
		public bool usedActionBar = false;

		[EditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		public ActionBarNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = this.usedActionBar ?
							c.Group.AverageBattleUsedActionBar :
							c.Group.AverageBattleActionBar;
					}
					else
					{
						value = this.usedActionBar ?
							c.Group.AverageUsedActionBar :
							c.Group.AverageActionBar;
					}
				}
				else
				{
					value = this.usedActionBar ?
						c.Battle.UsedActionBar :
						c.Battle.ActionBar;
				}
				this.formulaOperator.Use(ref call.result, value);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() +
				(this.useAverage ?
					(this.usedActionBar ? " Avg. Used Action Bar" : " Avg. Action Bar") :
					(this.usedActionBar ? " Used Action Bar" : " Action Bar"));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Action Bar", "Checks a combatant's action bar.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Check", "Combatant")]
	public class CheckActionBarNode : BaseFormulaCheckNode
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Used Action Bar", "Check the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.\n" +
			"E.g. use this to check if a combatant already chose actions by checking if the used action bar equals 0.", "")]
		public bool usedActionBar = false;

		[EditorHelp("Use Average", "Use the average action bar value of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckActionBarNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = this.check.Check(
					this.useAverage ?
						(this.onlyBattle ?
							(this.usedActionBar ?
								c.Group.AverageBattleUsedActionBar :
								c.Group.AverageBattleActionBar) :
							(this.usedActionBar ?
								c.Group.AverageUsedActionBar :
								c.Group.AverageActionBar)) :
						(this.usedActionBar ?
							c.Battle.UsedActionBar :
							c.Battle.ActionBar),
					call);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Action Time", "A combatant's current action time is used.\n" +
		"The action time is an optional feature to limit the time a combatant has to perform actions.", "")]
	[NodeInfo("Combatant")]
	public class ActionTimeNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Maximum", "Use the maximum action time of the combatant.", "")]
		public bool useMax = false;

		[EditorHelp("Use Average", "Use the average action time of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		public ActionTimeNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = this.useMax ?
							c.Group.AverageBattleActionTimeMax :
							c.Group.AverageBattleActionTime;
					}
					else
					{
						value = this.useMax ?
							c.Group.AverageActionTimeMax :
							c.Group.AverageActionTime;
					}
				}
				else
				{
					value = this.useMax ?
						c.Battle.ActionTimeMax :
						c.Battle.ActionTime;
				}
				this.formulaOperator.Use(ref call.result, value);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() +
				(this.useAverage ? " Avg. Action Time" : " Action Time") +
				(this.useMax ? " Max" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Action Time", "Checks a combatant's action time.\n" +
		"The action time is an optional feature to limit the time a combatant has to perform actions.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Check", "Combatant")]
	public class CheckActionTimeNode : BaseFormulaCheckNode
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Maximum", "Use the maximum action time of the combatant.", "")]
		public bool useMax = false;

		[EditorHelp("Use Average", "Use the average action time of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckActionTimeNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = this.check.Check(
					this.useMax ?
						(this.useAverage ?
							(this.onlyBattle ? c.Group.AverageBattleActionTimeMax : c.Group.AverageActionTimeMax) :
							c.Battle.ActionTimeMax) :
						(this.useAverage ?
							(this.onlyBattle ? c.Group.AverageBattleActionTime : c.Group.AverageActionTime) :
							c.Battle.ActionTime),
					call);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Grid Move Range", "A combatant's current grid move range is used (only available in grid battles).", "")]
	[NodeInfo("Combatant")]
	public class MoveRangeNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Maximum", "Use the maximum move range of the combatant.", "")]
		public bool useMax = false;

		[EditorHelp("Use Average", "Use the average move range of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		public MoveRangeNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ORK.Battle.Grid != null)
			{
				Combatant c = this.origin.GetCombatant(call);
				if(c != null)
				{
					float value = 0;
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ?
								c.Group.AverageBattleGridMoveRangeMax :
								c.Group.AverageBattleGridMoveRange;
						}
						else
						{
							value = this.useMax ?
								c.Group.AverageGridMoveRangeMax :
								c.Group.AverageGridMoveRange;
						}
					}
					else
					{
						value = this.useMax ?
							c.Battle.GridMoveRangeMax :
							c.Battle.GridMoveRange;
					}
					this.formulaOperator.Use(ref call.result, value);
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() +
				(this.useAverage ? " Avg. Move Range" : " Move Range") +
				(this.useMax ? " Max" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Grid Move Range", "Checks a combatant's current grid move range (only available in grid battles).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Check", "Combatant")]
	public class CheckMoveRangeNode : BaseFormulaCheckNode
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Maximum", "Use the maximum move range of the combatant.", "")]
		public bool useMax = false;

		[EditorHelp("Use Average", "Use the average move range of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckMoveRangeNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			if(ORK.Battle.Grid != null)
			{
				Combatant c = this.origin.GetCombatant(call);
				if(c != null)
				{
					check = this.check.Check(
						this.useMax ?
							(this.useAverage ?
								(this.onlyBattle ? c.Group.AverageBattleGridMoveRangeMax : c.Group.AverageGridMoveRangeMax) :
								c.Battle.GridMoveRangeMax) :
							(this.useAverage ?
								(this.onlyBattle ? c.Group.AverageBattleGridMoveRange : c.Group.AverageGridMoveRange) :
								c.Battle.GridMoveRange),
						call);
				}
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Inventory Space", "A combatant's used (occupied) or maximum inventory space is used.", "")]
	[NodeInfo("Combatant")]
	public class InventorySpaceNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Use Maximum", "The maximum inventory space is used.\n" +
			"If disabled, the currently used (occupied) inventory space is used.", "")]
		public bool useMax = false;

		public InventorySpaceNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useMax)
				{
					value = c.Inventory.TotalSpace;
				}
				else
				{
					value = c.Inventory.Space;
				}
				this.formulaOperator.Use(ref call.result, value);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() + (this.useMax ? " Max" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Inventory Quantity", "The quantity of an item, equipment, currency, " +
		"AI behaviour or AI ruleset in a combatant's inventory is used.", "")]
	[NodeInfo("Combatant")]
	public class InventoryQuantityNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// item selection
		[EditorSeparator]
		[EditorTitleLabel("Item Settings")]
		public ItemSelection item = new ItemSelection();

		public InventoryQuantityNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null)
			{
				this.formulaOperator.Use(ref call.result,
					this.item.GetInventoryCount(combatant.Inventory));
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() + ": " + this.item.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Status", "Checks a combatant for defined status conditions, e.g. status value.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckStatusNode : BaseFormulaCheckNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorSeparator]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorHelp("Combatants Needed", "Either all or only one combatant must match the defined status conditions.", "")]
		[EditorCondition("combatantScope", MenuCombatantScope.Current)]
		[EditorElseCondition]
		[EditorEndCondition]
		public Needed combatantsNeeded = Needed.All;


		// status conditions
		[EditorSeparator]
		[EditorTitleLabel("Status Conditions")]
		public StatusConditionSettings statusConditions = new StatusConditionSettings();

		public CheckStatusNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = true;
			bool any = false;

			Combatant combatant = this.origin.GetCombatant(call);
			if(combatant != null)
			{
				any = true;

				if(MenuCombatantScope.Current == this.combatantScope)
				{
					if(!this.statusConditions.Check(combatant))
					{
						check = false;
					}
				}
				else
				{
					check = Needed.All == this.combatantsNeeded;
					List<Combatant> group = new List<Combatant>();
					combatant.Group.GetMembers(this.combatantScope, ref group);
					for(int i = 0; i < group.Count; i++)
					{
						if(this.statusConditions.Check(group[i]))
						{
							if(Needed.One == this.combatantsNeeded)
							{
								check = true;
								break;
							}
						}
						else if(Needed.All == this.combatantsNeeded)
						{
							check = false;
							break;
						}
					}
				}
			}

			if(any && check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}

		public override int CalculatePreview(FormulaCall call)
		{
			bool check = true;
			bool any = false;

			Combatant combatant = this.origin.GetCombatant(call);
			if(combatant != null)
			{
				any = true;
				if(MenuCombatantScope.Current == this.combatantScope)
				{
					if(!this.statusConditions.CheckPreview(combatant))
					{
						check = false;
					}
				}
				else
				{
					check = Needed.All == this.combatantsNeeded;
					List<Combatant> group = new List<Combatant>();
					combatant.Group.GetMembers(this.combatantScope, ref group);
					for(int i = 0; i < group.Count; i++)
					{
						if(this.statusConditions.CheckPreview(group[i]))
						{
							if(Needed.One == this.combatantsNeeded)
							{
								check = true;
								break;
							}
						}
						else if(Needed.All == this.combatantsNeeded)
						{
							check = false;
							break;
						}
					}
				}
			}

			if(any && check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			string text = this.origin.ToString() + ": " + this.statusConditions.needed;
			for(int i = 0; i < this.statusConditions.condition.Length; i++)
			{
				text += "\n- " + this.statusConditions.condition[i].ToString();
			}
			return text;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Status Fork", "Checks a combatant for certain status conditions.\n" +
		"If a status condition is valid, it's next node will be executed.\n" +
		"If no status condition is valid, 'Failed' will be executed.", "")]
	[NodeInfo("Check", "Combatant")]
	public class StatusForkNode : BaseFormulaNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorArray("Add Status Condition", "Add a status condition.", "",
			"Remove", "Remove the status condition.", "", isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Status Condition", "Define the status condition that must be valid.", ""
		})]
		[EditorLabel("Using 'Local' variable origin in conditions will use the checked combatant's object variables.")]
		public StatusConditionNextNode[] condition = new StatusConditionNextNode[] { new StatusConditionNextNode() };

		public StatusForkNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					if(this.condition[i].Check(c))
					{
						return this.condition[i].next;
					}
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					if(this.condition[i].CheckPreview(c))
					{
						return this.condition[i].next;
					}
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1) + ": " + this.condition[index - 1].ToString();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Equipment Durability", "The durability of an equipment stored in selected data is used.", "")]
	[NodeInfo("Combatant")]
	public class EquipmentDurabilityNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorHelp("Use Max Durability", "Use the maximum durability of the equipment.", "")]
		public bool useMaxDurability = false;

		[EditorSeparator]
		[EditorTitleLabel("Selected Data")]
		public SelectedData<FormulaObjectSelection> selectedData = new SelectedData<FormulaObjectSelection>();

		[EditorHelp("Use First", "Use the durability of the first found durable equipment stored in the defined selected data.\n" +
			"If disabled, the durability of all stored equipment will be used.", "")]
		public bool useFirst = false;

		public EquipmentDurabilityNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			List<EquipShortcut> equipment = this.selectedData.GetSelectedData<EquipShortcut>(call, ORKSelectedDataHelper.GetEquipment);
			float value = 0;
			for(int i = 0; i < equipment.Count; i++)
			{
				if(equipment[i] != null &&
					equipment[i].UseDurability)
				{
					value += this.useMaxDurability ?
						equipment[i].MaxDurability :
						equipment[i].Durability;
					if(this.useFirst)
					{
						break;
					}
				}
			}
			this.formulaOperator.Use(ref call.result, value);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.selectedData.ToString() +
				(this.useFirst ? " (First)" : " (All)");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Is Player", "Checks a combatant is the player or a member of the player group.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class IsPlayerNode : BaseFormulaCheckNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Player/Member", "If enabled, checks if the combatant is the player combatant.\n" +
			"If disabled, checks if the combatant is a member of the active player group.", "")]
		public bool isPlayer = true;

		public IsPlayerNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);

			if(c != null &&
				(this.isPlayer ?
					ORK.Game.PlayerHandler.IsPlayer(c) :
					c.IsPlayerControlled()))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() +
				(this.isPlayer ? ": Player" : ": Member");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Is Enemy", "Checks if user and target are enemies.\n" +
		"If the check is valid, 'Enemies' will be executed, otherwise 'Allies'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class IsEnemyNode : BaseFormulaCheckNode
	{
		[EditorTitleLabel("User")]
		public FormulaStatusOrigin userOrigin = new FormulaStatusOrigin(StatusOrigin.User);

		[EditorSeparator]
		[EditorTitleLabel("Target")]
		public FormulaStatusOrigin targetOrigin = new FormulaStatusOrigin(StatusOrigin.Target);

		public IsEnemyNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = this.userOrigin.GetCombatant(call);
			Combatant target = this.targetOrigin.GetCombatant(call);
			if(user != null && target != null &&
				user.IsEnemy(target))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Enemies";
			}
			else if(index == 1)
			{
				return "Allies";
			}
			return "";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Battle Statistic", "A defined battle statistic value of a combatant is used.\n" +
		"Requires using the 'Combatant Battle Statistics' settings defined in 'Battle System > Battle Settings'.", "")]
	[NodeInfo("Combatant")]
	public class BattleStatisticNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorSeparator]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorHelp("Multi Value Use", "Select how values of multiple combatants will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[EditorCondition("combatantScope", MenuCombatantScope.Current)]
		[EditorElseCondition]
		[EditorEndCondition]
		public MultiFloatValueUse multiValueType = MultiFloatValueUse.Add;


		// statistic
		[EditorHelp("Statistic Key", "The key used to identify the statistic value.", "")]
		[EditorSeparator]
		[EditorWidth(true)]
		public string statisticKey = "";

		[EditorHelp("Value Source", "Select which statistic value will be used:\n" +
			"- Decrease Received: A value decrease the combatant received (e.g. received damage).\n" +
			"- Decrease Given: A value decrease the combatant gave (e.g. dealt damage).\n" +
			"- Increase Received: A value increase the combatant received (e.g. getting healed).\n" +
			"- Increase Given: A value increase the combatant gave (e.g. healing others).", "")]
		public ValueStatistic.Source valueSource = ValueStatistic.Source.DecreaseReceived;

		[EditorHelp("Use Total Change", "Use the total change the combatant registered.\n" +
			"If disabled, uses the change registered from the user (requires using 'Per Combatant' statistics).", "")]
		[EditorSeparator]
		public bool useTotalChange = true;


		// source combatant
		[EditorSeparator]
		[EditorTitleLabel("Source Combatant")]
		[EditorCondition("useTotalChange", false)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FormulaStatusOrigin changeOrigin;

		public BattleStatisticNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("wholeGroup"))
			{
				bool tmp = false;
				data.Get("wholeGroup", ref tmp);
				if(tmp)
				{
					tmp = false;
					data.Get("onlyBattle", ref tmp);
					this.combatantScope = tmp ? MenuCombatantScope.Battle : MenuCombatantScope.Group;
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(ORK.BattleSettings.battleStatistics.useStatictics &&
				(this.useTotalChange ||
					ORK.BattleSettings.battleStatistics.usePerCombatant))
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					Combatant source = this.useTotalChange ?
						null : this.changeOrigin.GetCombatant(call);
					float value = 0;
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						if(source != null)
						{
							value = combatant.Battle.Statistic[this.statisticKey].PerCombatant(source).GetValue(this.valueSource);
						}
						else
						{
							value = combatant.Battle.Statistic[this.statisticKey].Total.GetValue(this.valueSource);
						}
					}
					else
					{
						List<Combatant> group = new List<Combatant>();
						combatant.Group.GetMembers(this.combatantScope, ref group);
						value = this.GetGroupValue(group, source);
					}
					this.formulaOperator.Use(ref call.result, value);
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			// no preview
			return this.next;
		}

		private float GetGroupValue(List<Combatant> list, Combatant source)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(source != null)
					{
						values.Add(list[i].Battle.Statistic[this.statisticKey].PerCombatant(source).GetValue(this.valueSource));
					}
					else
					{
						values.Add(list[i].Battle.Statistic[this.statisticKey].Total.GetValue(this.valueSource));
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, this.multiValueType);
			}
			return 0;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString() +
				(this.useTotalChange ? " total change" : " from " + this.changeOrigin.ToString()) +
				": " + this.statisticKey + " " + this.valueSource;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Combatant Count", "The number of combatants in the scene is used.\n" +
		"The found combatants can be filtered by different settings, e.g. being enemy of a user or status conditions.", "")]
	[NodeInfo("Combatant")]
	public class CombatantCountNode : BaseFormulaNode
	{
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorSeparator]
		[EditorTitleLabel("User Combatant")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// range
		[EditorHelp("Check Range", "Only search within a defined range of the user or a position.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Range Settings")]
		public bool checkRange = false;

		[EditorHelp("From Position", "Check the range from a defined position.\n" +
			"If disabled, the range will be checked from the user's position.", "")]
		[EditorCondition("checkRange", true)]
		public bool checkPosition = false;

		[EditorAutoInit]
		public RangeValue range;

		[EditorSeparator]
		[EditorTitleLabel("Search Position")]
		[EditorCondition("checkPosition", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public Vector3Value<FormulaObjectSelection> position;


		// search settings
		public SearchCombatantSettings search = new SearchCombatantSettings();

		public CombatantCountNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = this.origin.GetCombatant(call);
			if(user != null)
			{
				List<Combatant> found = this.checkRange && this.checkPosition ?
					this.search.Search(this.position.GetValue(call), user, this.checkRange ? this.range : null) :
					this.search.Search(user, this.checkRange ? this.range : null);

				this.formulaOperator.Use(ref call.result, found.Count);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			return this.Calculate(call);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Store Combatant Count", "Stores the number of combatants in the scene into a float variable.\n" +
		"The found combatants can be filtered by different settings, e.g. being enemy of a user or status conditions.", "")]
	[NodeInfo("Combatant", "Variable")]
	public class StoreCombatantCountNode : BaseFormulaNode
	{
		// variable settings
		VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		public FloatOperator floatOperator = new FloatOperator();


		// user
		[EditorSeparator]
		[EditorTitleLabel("User Combatant")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// range
		[EditorHelp("Check Range", "Only search within a defined range of the user or a position.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Range Settings")]
		public bool checkRange = false;

		[EditorHelp("From Position", "Check the range from a defined position.\n" +
			"If disabled, the range will be checked from the user's position.", "")]
		[EditorCondition("checkRange", true)]
		public bool checkPosition = false;

		[EditorAutoInit]
		public RangeValue range;

		[EditorSeparator]
		[EditorTitleLabel("Search Position")]
		[EditorCondition("checkPosition", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public Vector3Value<FormulaObjectSelection> position;


		// search settings
		[EditorSeparator]
		public SearchCombatantSettings search = new SearchCombatantSettings();

		public StoreCombatantCountNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = this.origin.GetCombatant(call);
			if(user != null)
			{
				List<Combatant> found = this.checkRange && this.checkPosition ?
					this.search.Search(this.position.GetValue(call), user, this.checkRange ? this.range : null) :
					this.search.Search(user, this.checkRange ? this.range : null);

				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						found.Count, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			return this.Calculate(call);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Equipment", "Checks the equipment of a combatant.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckEquipmentNode : BaseFormulaCheckNode
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		// equipment slot
		[EditorHelp("Any Equipment Slot", "Check all equipment slots of the combatant if any of them matches the defined equipment.", "")]
		[EditorSeparator]
		public bool anySlot = false;

		[EditorHelp("Equipment Slot", "Select the equipment slot that will be checked.", "")]
		[EditorCondition("anySlot", false)]
		public AssetSelection<EquipmentSlotAsset> equipmentSlot = new AssetSelection<EquipmentSlotAsset>();

		[EditorHelp("Check Blocking Slot", "Check the equipment of the slot that's blocking the selected equipment slot.", "")]
		[EditorEndCondition]
		public bool checkBlockingSlot = false;


		// selected data
		[EditorHelp("Use Selected Data", "Check for an equipment stored in selected data.", "")]
		public bool useSelectedData = false;

		[EditorTitleLabel("Selected Key")]
		[EditorCondition("useSelectedData", true)]
		[EditorAutoInit]
		public SelectedData<FormulaObjectSelection> selectedData;


		// equipment
		[EditorHelp("Is Unequipped", "The equipment slot has to be unequipped")]
		[EditorElseCondition]
		public bool isUnequipped = false;

		[EditorHelp("Any Equipment", "Checks the equipment slot for any equipment.\n" +
			"If disabled, a defined equipment has to be equipped.")]
		[EditorCondition("isUnequipped", false)]
		public bool anyEquipment = false;

		[EditorHelp("Equipment", "Select the equipment that will be checked for.", "")]
		[EditorCondition("anyEquipment", false)]
		public AssetSelection<EquipmentAsset> equip = new AssetSelection<EquipmentAsset>();

		[EditorHelp("Level Check", "Select the level of the equipment that will be checked for.")]
		[EditorEndCondition(3)]
		public LevelValueCheck levelCheck = new LevelValueCheck(ValueCheckType.IsGreaterEqual, 1, 0);

		public CheckEquipmentNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("level"))
			{
				int tmp = 1;
				data.Get("level", ref tmp);
				this.levelCheck = new LevelValueCheck(ValueCheckType.IsGreaterEqual, tmp, 0);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.Check(call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}

		private bool Check(FormulaCall call)
		{
			if(this.useSelectedData)
			{
				List<EquipShortcut> equipList = this.selectedData.GetSelectedData<EquipShortcut>(call, ORKSelectedDataHelper.GetEquipment);
				if(equipList != null &&
					equipList.Count > 0)
				{
					Combatant user = this.origin.GetCombatant(call);
					if(user != null)
					{
						EquipmentSlot equipSlot = null;
						if(!this.anySlot &&
							this.equipmentSlot.StoredAsset != null)
						{
							equipSlot = user.Equipment.GetRealSlot(this.equipmentSlot.StoredAsset.Settings, this.checkBlockingSlot);
						}

						for(int j = 0; j < equipList.Count; j++)
						{
							if(equipSlot != null ?
								equipSlot.IsEquipped(equipList[j]) :
								user.Equipment.IsEquipped(equipList[j]))
							{
								return true;
							}
						}
					}
				}
			}
			else
			{
				Combatant user = this.origin.GetCombatant(call);
				if(user != null)
				{
					EquipmentSlotSetting equipSlot = null;
					if(!this.anySlot &&
						this.equipmentSlot.StoredAsset != null)
					{
						equipSlot = user.Equipment.GetRealSlot(this.equipmentSlot.StoredAsset.Settings, this.checkBlockingSlot).Settings;
					}
					if(this.isUnequipped)
					{
						if(user.Equipment.IsUnequipped(equipSlot))
						{
							return true;
						}
					}
					else if(this.anyEquipment)
					{
						if(user.Equipment.IsEquipped(null, this.levelCheck, equipSlot))
						{
							return true;
						}
					}
					else if(this.equip.StoredAsset != null &&
						user.Equipment.IsEquipped(this.equip.StoredAsset.Settings, this.levelCheck, equipSlot))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.anySlot ? "Any Equipment Slot" : this.equipmentSlot.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Equipment Fork", "Checks a selected equipment slot of a combatant.\n" +
		"If an equipment condition is valid, it's next node will be executed.\n" +
		"If no condition is valid, 'Failed' will be executed.", "")]
	[NodeInfo("Combatant", "Check")]
	public class EquipmentForkNode : BaseFormulaNode
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Equipment Slot", "Select the equipment slot that will be checked.", "")]
		[EditorSeparator]
		public AssetSelection<EquipmentSlotAsset> equipmentSlot = new AssetSelection<EquipmentSlotAsset>();

		[EditorHelp("Check Blocking Slot", "Check the equipment of the slot that's blocking the selected equipment slot.", "")]
		public bool checkBlockingSlot = false;


		// checks
		[EditorArray("Add Check", "Adds a new equipment condition.", "",
			"Remove", "Removes the equipment condition.", "", isMove = true, isCopy = true,
			noRemoveCount = 1, foldout = true, foldoutText = new string[] {
				"Equipment Condition", "Define the variable condition that must be valid.", ""
		})]
		public EquipmentConditionNextNode<FormulaObjectSelection>[] condition = new EquipmentConditionNextNode<FormulaObjectSelection>[] {
			new EquipmentConditionNextNode<FormulaObjectSelection>()
		};

		public EquipmentForkNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.equipmentSlot.StoredAsset != null)
			{
				Combatant user = this.origin.GetCombatant(call);
				if(user != null)
				{
					// get linked slot for multi-slot equipments
					EquipmentSlot equipSlot = user.Equipment.GetRealSlot(this.equipmentSlot.StoredAsset.Settings, this.checkBlockingSlot);

					for(int j = 0; j < this.condition.Length; j++)
					{
						if(this.condition[j].useSelectedData)
						{
							List<EquipShortcut> equipList = this.condition[j].selectedData.GetSelectedData<EquipShortcut>(call, ORKSelectedDataHelper.GetEquipment);
							if(equipList != null &&
								equipList.Count > 0)
							{
								for(int k = 0; k < equipList.Count; k++)
								{
									if(equipSlot.IsEquipped(equipList[k]))
									{
										return this.condition[j].next;
									}
								}
							}
						}
						else if(this.condition[j].isUnequipped)
						{
							if(!equipSlot.Equipped)
							{
								return this.condition[j].next;
							}
						}
						else if(equipSlot.Equipped)
						{
							if(this.condition[j].checkItemType)
							{
								if(this.condition[j].itemType.StoredAsset != null)
								{
									ItemType itemType = this.condition[j].itemType.StoredAsset.Settings;
									if(equipSlot.Equipment.IsItemType(itemType, this.condition[j].useSubTypes))
									{
										return this.condition[j].next;
									}
								}
							}
							else if(this.condition[j].equipment.Is(equipSlot.Equipment.Setting))
							{
								return this.condition[j].next;
							}
						}
					}
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.equipmentSlot.ToString();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1) + ": " + this.condition[index - 1].ToString();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Faction", "Checks the faction of a combatant.\n" +
		"If the faction equals a defined faction, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckFactionNode : BaseFormulaCheckNode
	{
		[EditorTitleLabel("Combatant")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Faction", "Select the faction that will be checked for.", "")]
		[EditorSeparator]
		public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();

		public CheckFactionNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);

			if(c != null && this.faction.Is(c.Group.Faction))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.faction.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Faction Sympathy", "Checks the sympathy a faction has for another faction.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckFactionSympathyNode : BaseFormulaCheckNode
	{
		// change faction
		[EditorHelp("Use Combatant", "Use the faction of a combatant.", "")]
		[EditorTitleLabel("Check Faction")]
		public bool useCombatant = false;

		[EditorCondition("useCombatant", true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Faction", "Select the faction that will be checked.", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();


		// sympathy check
		[EditorHelp("Use Combatant", "Use the faction of a combatant.", "")]
		[EditorTitleLabel("Check Sympathy For")]
		[EditorSeparator]
		public bool useCombatant2 = false;

		[EditorCondition("useCombatant2", true)]
		public FormulaStatusOrigin origin2 = new FormulaStatusOrigin(StatusOrigin.Target);

		[EditorHelp("Faction", "Select the faction that will be checked for.", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		public AssetSelection<FactionAsset> faction2 = new AssetSelection<FactionAsset>();


		// check by
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckFactionSympathyNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			// get faction
			FactionSetting tmpFaction = null;
			if(this.useCombatant)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					tmpFaction = combatant.Group.Faction;
				}
			}
			else if(this.faction.StoredAsset != null)
			{
				tmpFaction = this.faction.StoredAsset.Settings;
			}

			// get faction 2
			FactionSetting tmpFaction2 = null;
			if(this.useCombatant2)
			{
				Combatant combatant = this.origin2.GetCombatant(call);
				if(combatant != null)
				{
					tmpFaction2 = combatant.Group.Faction;
				}
			}
			else if(this.faction2.StoredAsset != null)
			{
				tmpFaction2 = this.faction2.StoredAsset.Settings;
			}

			// check
			if(tmpFaction != null && tmpFaction2 != null &&
				this.check.Check(ORK.Game.Faction.GetSympathy(tmpFaction, tmpFaction2), call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Faction Benefit", "Checks the benefit a faction gives to another faction.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckFactionBenefitNode : BaseFormulaCheckNode
	{
		// change faction
		[EditorHelp("Use Combatant", "Use the faction of a combatant.", "")]
		[EditorTitleLabel("Check Faction")]
		public bool useCombatant = false;

		[EditorCondition("useCombatant", true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Faction", "Select the faction that will be checked.", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();


		// sympathy check
		[EditorHelp("Use Combatant", "Check the sympathy for a combatant's faction.", "")]
		[EditorTitleLabel("Check Sympathy For")]
		[EditorSeparator]
		public bool useCombatant2 = false;

		[EditorCondition("useCombatant2", true)]
		public FormulaStatusOrigin origin2 = new FormulaStatusOrigin(StatusOrigin.Target);

		[EditorHelp("Faction", "Select the faction that will be checked for.", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		public AssetSelection<FactionAsset> faction2 = new AssetSelection<FactionAsset>();


		// benefit
		[EditorHelp("Faction Benefit", "Select the faction benefit that will be checked for.", "")]
		[EditorSeparator]
		public AssetSelection<FactionBenefitAsset> factionBenefit = new AssetSelection<FactionBenefitAsset>();

		public CheckFactionBenefitNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			// get faction
			FactionSetting tmpFaction = null;
			if(this.useCombatant)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					tmpFaction = combatant.Group.Faction;
				}
			}
			else if(this.faction.StoredAsset != null)
			{
				tmpFaction = this.faction.StoredAsset.Settings;
			}

			// get faction 2
			FactionSetting tmpFaction2 = null;
			if(this.useCombatant2)
			{
				Combatant combatant = this.origin2.GetCombatant(call);
				if(combatant != null)
				{
					tmpFaction2 = combatant.Group.Faction;
				}
			}
			else if(this.faction2.StoredAsset != null)
			{
				tmpFaction2 = this.faction2.StoredAsset.Settings;
			}

			// check
			if(tmpFaction != null && tmpFaction2 != null &&
				this.factionBenefit.StoredAsset != null &&
				this.factionBenefit.StoredAsset.Settings.InSympathyRange(ORK.Game.Faction.GetSympathy(tmpFaction, tmpFaction2)))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.factionBenefit.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Is Linked Combatant", "Checks if a combatant is linked to another combatant.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class IsLinkedCombatantNode : BaseFormulaCheckNode
	{
		[EditorHelp("Linked Key", "Define the key that will be used.")]
		public StringValue<FormulaObjectSelection> linkedKey = new StringValue<FormulaObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("Combatant")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorSeparator]
		[EditorTitleLabel("Linked Combatant")]
		public FormulaStatusOrigin linkedOrigin = new FormulaStatusOrigin(StatusOrigin.Target);

		public IsLinkedCombatantNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = this.origin.GetCombatant(call);
			Combatant target = this.linkedOrigin.GetCombatant(call);

			// check
			if(user != null &&
				target != null &&
				user.Battle.CombatantLinks.Contains(this.linkedKey.GetValue(call), target))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " +
				this.linkedKey.ToString() + ", " + this.linkedOrigin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Status Effect Added By", "Checks if the user's status effect was added by a target.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class StatusEffectAddedByNode : BaseFormulaCheckNode
	{
		[EditorHelp("Status Effect", "Select the status effect that will be checked for.", "")]
		public AssetSelection<StatusEffectAsset> effect = new AssetSelection<StatusEffectAsset>();

		[EditorSeparator]
		[EditorTitleLabel("Combatant with Status Effect")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorSeparator]
		[EditorTitleLabel("Check For Combatant")]
		public FormulaStatusOrigin checkFor = new FormulaStatusOrigin(StatusOrigin.Target);

		public StatusEffectAddedByNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = this.origin.GetCombatant(call);
			Combatant target = this.checkFor.GetCombatant(call);

			// check
			if(this.effect.StoredAsset != null &&
				user != null &&
				target != null &&
				user.Status.Effects.IsAppliedBy(this.effect.StoredAsset.Settings, target))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " +
				this.effect.ToString() + ", " + this.checkFor.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
