﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class StatusConditionSettings : BaseData
	{
		[EditorHelp("Needed", "Either all or only one status conditions must be valid.", "")]
		public Needed needed = Needed.All;

		[EditorArray("Add Status Condition", "Add a status condition.", "",
			"Remove", "Remove the status condition.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Status Condition", "Define the status condition that must be valid.", ""
		})]
		[EditorLabel("Using 'Local' variable origin in conditions will use the checked combatant's object variables.")]
		public StatusCondition[] condition = new StatusCondition[0];

		public StatusConditionSettings()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant combatant)
		{
			return StatusCondition.Check(combatant, this.condition, this.needed);
		}

		public bool CheckPreview(Combatant combatant)
		{
			return StatusCondition.CheckPreview(combatant, this.condition, this.needed);
		}

		public bool CheckBestiary(Combatant combatant)
		{
			return StatusCondition.CheckBestiary(combatant, this.condition, this.needed);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public void RegisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			for(int i = 0; i < this.condition.Length; i++)
			{
				this.condition[i].RegisterStatusChanges(combatant, notify);
			}
		}

		public void UnregisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			for(int i = 0; i < this.condition.Length; i++)
			{
				this.condition[i].UnregisterStatusChanges(combatant, notify);
			}
		}

		public void RegisterStatusChanges(Combatant combatant, Notify notify)
		{
			for(int i = 0; i < this.condition.Length; i++)
			{
				this.condition[i].RegisterStatusChanges(combatant, notify);
			}
		}

		public void UnregisterStatusChanges(Combatant combatant, Notify notify)
		{
			for(int i = 0; i < this.condition.Length; i++)
			{
				this.condition[i].UnregisterStatusChanges(combatant, notify);
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual bool ContainsCondition(ResearchTreeSetting researchTree, int researchItemIndex)
		{
			for(int i = 0; i < this.condition.Length; i++)
			{
				if(this.condition[i].ContainsCondition(researchTree, researchItemIndex))
				{
					return true;
				}
			}
			return false;
		}
	}
}
