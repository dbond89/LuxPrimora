﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Battle Menu Open", "The combatant's battle menu must or mustn't be opened.")]
	public class BattleMenuOpenStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Open", "The combatant's battle menu must be opened.\n" +
			"If disabled, the combatant's battle menu must be closed.", "")]
		public bool isOpen = true;

		public BattleMenuOpenStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isOpen ? "battle menu open" : "battle menu closed";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Battle.BattleMenu != null &&
				combatant.Battle.BattleMenu.IsOpen == this.isOpen;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.BattleMenuOpened += notify.NotifyStatusChanged;
			combatant.Events.BattleMenuClosed += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.BattleMenuOpened -= notify.NotifyStatusChanged;
			combatant.Events.BattleMenuClosed -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.BattleMenuOpenedSimple += notify;
			combatant.Events.BattleMenuClosedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.BattleMenuOpenedSimple -= notify;
			combatant.Events.BattleMenuClosedSimple -= notify;
		}
	}
}
