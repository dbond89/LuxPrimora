﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Bestiary", "The combatant must or mustn't have an entry in the bestiary.", "")]
	public class BestiaryStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Known", "The combatant has an entry in the bestiary.", "")]
		public bool isKnown = true;

		[EditorHelp("Complete Entry", "The combatant's entry must be complete (i.e. all status information known).\n" +
			"If disabled, the combatant only needs to have an entry in the bestiary.", "")]
		[EditorCondition("isKnown", true)]
		[EditorEndCondition]
		public bool isComplete = false;

		public BestiaryStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.isKnown ? (this.isComplete ? "Bestiary Complete" : "Bestiary Known") : "No Bestiary Entry");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.isKnown &&
				this.isComplete)
			{
				return ORK.Game.Bestiary.IsComplete(combatant);
			}
			else
			{
				return ORK.Game.Bestiary.IsKnown(combatant) == this.isKnown;
			}
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			ORK.Game.Bestiary.Changed += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			ORK.Game.Bestiary.Changed -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			ORK.Game.Bestiary.Changed += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			ORK.Game.Bestiary.Changed -= notify;
		}
	}
}
