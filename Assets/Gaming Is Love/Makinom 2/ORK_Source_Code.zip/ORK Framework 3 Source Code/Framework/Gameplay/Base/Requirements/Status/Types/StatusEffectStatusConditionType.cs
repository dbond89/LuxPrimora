﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Status Effect", "The selected status effect must or mustn't be applied to the combatant.")]
	public class StatusEffectStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Status Effect", "Select the status effect that will be used.", "")]
		public AssetSelection<StatusEffectAsset> statusEffect = new AssetSelection<StatusEffectAsset>();

		[EditorHelp("Is Applied", "The selected status effect must be applied.\n" +
			"If disabled, the effect mustn't be applied.", "")]
		public bool applied = false;

		[EditorHelp("Check Stacked Quantity", "Check the quantity the status effect is stacked on the combatant.", "")]
		[EditorCondition("applied", true)]
		public bool checkStacked = false;

		[EditorCondition("checkStacked", true)]
		[EditorEndCondition(2)]
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public StatusEffectStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.statusEffect.ToString() + (this.applied ? 
				" applied" + (this.checkStacked ? " stack count " + this.check.ToString() : "") : 
				" not applied");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.statusEffect.StoredAsset != null &&
				this.applied == combatant.Status.Effects.IsApplied(this.statusEffect.StoredAsset.Settings) &&
				(!this.checkStacked ||
					this.check.Check(
						combatant.Status.Effects.GetStackedCount(this.statusEffect.StoredAsset.Settings),
						combatant.Call));
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.StatusEffectAdded += notify.NotifyStatusChanged;
			combatant.Events.StatusEffectRemoved += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.StatusEffectAdded -= notify.NotifyStatusChanged;
			combatant.Events.StatusEffectRemoved -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.StatusEffectsChanged += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.StatusEffectsChanged -= notify;
		}
	}
}
