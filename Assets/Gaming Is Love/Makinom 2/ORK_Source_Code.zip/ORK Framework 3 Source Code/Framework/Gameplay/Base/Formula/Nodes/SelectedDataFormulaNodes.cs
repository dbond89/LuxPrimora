﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Select Combatant", "Uses combatants as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectCombatantNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> dataChange = new SelectedDataChange<FormulaObjectSelection>();


		// combatants
		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorHelp("Use Random", "Use a random combatant from the group.", "")]
		[EditorCondition("combatantScope", MenuCombatantScope.Current)]
		[EditorElseCondition]
		[EditorEndCondition]
		public bool useRandom = false;

		[EditorSeparator]
		public SelectCombatantSettings<FormulaObjectSelection> selectCombatant = new SelectCombatantSettings<FormulaObjectSelection>();

		[EditorSeparator]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// requirements
		[EditorHelp("Use Requirements", "Check for enemy state or valid conditions, " +
			"e.g. combatant status or variable conditions to check if a combatant will be used.\n" +
			"The requirements are only checked for the combatant itself, not e.g. the combatant's last targets.", "")]
		[EditorFoldout("Filter Settings", "Optionally filter the used combatants by checking for enemies or valid conditions, " +
			"e.g. combatant status or variable conditions.", "")]
		public bool useRequirements = false;

		[EditorHelp("Is Enemy", "Select if the combatants are enemies of the user:\n" +
			"- Yes: The combatants are enemies.\n" +
			"- No: The combatants are allies.\n" +
			"- Ignore: Ignores the faction standings.", "")]
		[EditorCondition("useRequirements", true)]
		public Consider isEnemy = Consider.Ignore;

		[EditorSeparator]
		[EditorTitleLabel("User Combatant")]
		[EditorCondition("isEnemy", Consider.Ignore)]
		[EditorElseCondition]
		[EditorEndCondition]
		[EditorAutoInit]
		public FormulaStatusOrigin enemyObject;

		[EditorSeparator]
		[EditorEndFoldout]
		[EditorCondition("useRequirements", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public CombatantGeneralConditionSettings conditions;

		public SelectCombatantNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				List<Combatant> found = new List<Combatant>();
				Combatant combatant = this.origin.GetCombatant(call);
				Combatant enemy = this.useRequirements &&
					Consider.Ignore != this.isEnemy &&
					this.enemyObject != null ?
						this.enemyObject.GetCombatant(call) :
						null;

				if(combatant != null)
				{
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						if(!this.useRequirements || this.conditions.Check(combatant))
						{
							this.selectCombatant.Get(call, combatant, found);
						}
					}
					else
					{
						List<Combatant> list = new List<Combatant>();
						combatant.Group.GetMembers(this.combatantScope, ref list);
						if(this.useRequirements)
						{
							this.conditions.FilterList(list);
						}

						if(this.useRandom)
						{
							this.selectCombatant.Get(call, list[UnityWrapper.Range(0, list.Count)], found);
						}
						else
						{
							for(int i = 0; i < list.Count; i++)
							{
								this.selectCombatant.Get(call, list[i], found);
							}
						}
					}
				}

				if(found.Count > 0 &&
					enemy != null)
				{
					for(int i = 0; i < found.Count; i++)
					{
						if(found[i].IsEnemy(enemy) == (Consider.No == this.isEnemy))
						{
							found.RemoveAt(i--);
						}
					}
				}

				this.dataChange.Change(found, call, true);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.dataChange.IsClear)
			{
				return this.dataChange.ToString();
			}
			return this.dataChange.ToString() + ": " + this.origin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Select Ability", "Uses abilities of combatants or a newly created ability as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectAbilityNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> dataChange = new SelectedDataChange<FormulaObjectSelection>();


		// ability settings
		[EditorHelp("Create Ability", "Create a new instance of the defined ability.\n" +
			"If disabled, abilities known by a combatant will be used.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Ability Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public bool createAbility = false;

		// all abilities
		[EditorHelp("All Abilities", "Get all abilities of the combatant.", "")]
		[EditorCondition("createAbility", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool allAbilities = false;

		[EditorHelp("Useable In", "Select where the abilities can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Passive abilities.", "")]
		[EditorCondition("allAbilities", true)]
		public UseableIn useableIn = UseableIn.Both;

		[EditorHelp("Add Temporary Abilities", "Select if temporary abilities will be included:\n" +
			"- Yes: Temporary abilities will be included.\n" +
			"- No: Temporary abilities will not be included.\n" +
			"- Only: Only temporary abilities will be used.", "")]
		public IncludeCheckType addTemporary = IncludeCheckType.Yes;

		[EditorHelp("Add Passive Toggleable", "Add passive abilities that can be turned on/off.")]
		[EditorCondition("useableIn", UseableIn.None)]
		[EditorElseCondition]
		[EditorEndCondition]
		public bool addPassiveToggleable = false;

		[EditorHelp("Limit Ability Type", "Limit the abilities to a defined ability type and it's sub-types.", "")]
		public bool limitAbilityType = false;

		[EditorHelp("Ability Type", "Select the ability type that will be used to limit the abilities.", "")]
		[EditorCondition("limitAbilityType", true)]
		[EditorAutoInit]
		public AssetSelection<AbilityTypeAsset> abilityType;

		[EditorHelp("Use Sub-Types", "The sub-types of the defined ability type will also be used.", "")]
		[EditorEndCondition]
		public bool useSubTypes = true;

		// ability
		[EditorElseCondition]
		[EditorEndCondition]
		public AbilitySelection ability = new AbilitySelection();


		// combatant
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		[EditorCondition("createAbility", false)]
		[EditorEndCondition(2)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectAbilityNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else if(this.createAbility)
			{
				this.dataChange.Change(this.ability.CreateShortcut(AbilityState.None), call, true);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);

				if(combatant != null)
				{
					if(this.allAbilities)
					{
						this.dataChange.Change(
							this.limitAbilityType && this.abilityType.StoredAsset != null ?
								combatant.Abilities.GetByType(this.abilityType.StoredAsset.Settings, this.useableIn, this.addTemporary, this.addPassiveToggleable, this.useSubTypes) :
								combatant.Abilities.GetAbilities(this.useableIn, this.addTemporary, this.addPassiveToggleable),
							call, true);
					}
					else
					{
						AbilityShortcut ability = this.ability.GetAbility(combatant);

						if(ability != null)
						{
							this.dataChange.Change(ability, call, true);
						}
					}
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.dataChange.IsClear)
			{
				return this.dataChange.ToString();
			}
			return this.dataChange.ToString() + ": " +
				(this.createAbility ? "Create" : this.origin.ToString()) +
				(this.allAbilities ? " all abilities" : " " + this.ability.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Select Base Attack", "Uses base attacks of combatants as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectBaseAttackNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> dataChange = new SelectedDataChange<FormulaObjectSelection>();


		// attack settings
		[EditorHelp("Base Attack Scope", "Select the scope of the base attack that will be used:\n" +
			"- Current: Use the current base attack of the combatant.\n" +
			"- Index: Use a base attack at a defined index.\n" +
			"- All: Use all base attacks of the combatant.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Base Attack Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public BaseAttackScope attackScope = BaseAttackScope.Current;

		[EditorCondition("attackScope", BaseAttackScope.Index)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> attackIndex;


		// combatant
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		[EditorEndCondition]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectBaseAttackNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					if(BaseAttackScope.All == this.attackScope)
					{
						List<AbilityShortcut> abilities = new List<AbilityShortcut>();
						combatant.Abilities.GetBaseAttacks(ref abilities);
						this.dataChange.Change(abilities, call, true);
					}
					else
					{
						AbilityShortcut ability = null;

						if(BaseAttackScope.Current == this.attackScope)
						{
							ability = combatant.Abilities.GetCurrentBaseAttack();
						}
						else if(BaseAttackScope.Index == this.attackScope)
						{
							ability = combatant.Abilities.GetBaseAttack((int)this.attackIndex.GetValue(call));
						}

						if(ability != null)
						{
							this.dataChange.Change(ability, call, true);
						}
					}
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.dataChange.IsClear)
			{
				return this.dataChange.ToString();
			}
			return this.dataChange.ToString() + ": " +
				this.origin.ToString() + " " + this.attackScope.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Select Counter Attack", "Uses counter attacks of combatants as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectCounterAttackNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> dataChange = new SelectedDataChange<FormulaObjectSelection>();


		// combatant
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		[EditorEndCondition]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectCounterAttackNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					this.dataChange.Change(combatant.Abilities.GetCounterAttack(), call, true);
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.dataChange.IsClear)
			{
				return this.dataChange.ToString();
			}
			return this.dataChange.ToString() + ": " + this.origin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Select Equipment", "Uses the equipment currently equipped on combatants as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectEquipmentNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> dataChange = new SelectedDataChange<FormulaObjectSelection>();


		// equipment
		[EditorHelp("All Equipment", "Use all currently equipped equipment of the combatant.\n" +
			"If disabled, only the equipment of a defined equipment slot will be used.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Equipment Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public bool allEquipment = false;

		[EditorHelp("Equipment Slot", "Select the equipment slot which's current equipment will be used.", "")]
		[EditorCondition("allEquipment", false)]
		[EditorEndCondition]
		public AssetSelection<EquipmentSlotAsset> equipmentSlot = new AssetSelection<EquipmentSlotAsset>();

		[EditorHelp("Limit Item Type", "Limit the equipment to a defined item type and its sub-types.", "")]
		public bool limitItemType = false;

		[EditorHelp("Item Type", "Select the item type that will be used to limit the equipment.", "")]
		[EditorCondition("limitItemType", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<ItemTypeAsset> itemType;


		// combatant
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		[EditorEndCondition]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectEquipmentNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					ItemType tmpType = this.limitItemType && this.itemType.StoredAsset != null ?
						this.itemType.StoredAsset.Settings : null;
					if(this.allEquipment)
					{
						List<EquipShortcut> equipment = new List<EquipShortcut>();

						for(int j = 0; j < ORK.EquipmentSlots.Count; j++)
						{
							if(combatant.Equipment[j].Available &&
								combatant.Equipment[j].Equipped)
							{
								EquipShortcut equip = combatant.Equipment[j].Equipment;

								if(equip != null &&
									!equipment.Contains(equip) &&
									(!this.limitItemType ||
										equip.IsItemType(tmpType, true)))
								{
									equipment.Add(equip);
								}
							}
						}
						this.dataChange.Change(equipment, call, true);
					}
					else if(this.equipmentSlot.StoredAsset != null)
					{
						EquipmentSlot equipSlot = combatant.Equipment.GetSlot(this.equipmentSlot.StoredAsset.Settings);
						if(equipSlot.Available &&
							equipSlot.Equipped)
						{
							EquipShortcut equip = equipSlot.Equipment;

							if(equip != null &&
								(!this.limitItemType ||
									equip.IsItemType(tmpType, true)))
							{
								this.dataChange.Change(equip, call, true);
							}
						}
					}
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.dataChange.IsClear)
			{
				return this.dataChange.ToString();
			}
			return this.dataChange.ToString() + ": " + this.origin.ToString() +
				(this.allEquipment ? " all equipment" : " " + this.equipmentSlot.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Select Item", "Uses items from the inventory of combatants or newly created items as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectItemNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> dataChange = new SelectedDataChange<FormulaObjectSelection>();


		// item settings
		[EditorHelp("Create Item", "Create new instances of the defined items.\n" +
			"If disabled, items from the inventories of combatants will be used.", "")]
		[EditorFoldout("Item Settings", "Define the items that will be selected.")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public bool createItem = false;

		// all items
		[EditorHelp("All Items", "Use all items currently in the combatant's inventory.\n" +
			"If disabled, only the defined items will be used.", "")]
		[EditorCondition("createItem", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool allItems = false;

		[EditorCondition("allItems", true)]
		[EditorSeparator]
		public InventoryAccessSettings inventoryAccess = new InventoryAccessSettings();

		// item type
		[EditorHelp("Limit Item Type", "Limit the items to a defined item type and its sub-types.", "")]
		[EditorSeparator]
		public bool limitItemType = false;

		[EditorHelp("Item Type", "Select the item type that will be used to limit the items.", "")]
		[EditorCondition("limitItemType", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<ItemTypeAsset> itemType;

		// define items
		[EditorEndFoldout]
		[EditorArray("Add Item", "Adds an item to the list.", "",
			"Remove", "Removes this item from the list.", "",
			noRemoveCount = 1, isCopy = true, isMove = true, foldout = true, foldoutText = new string[] {
				"Item", "Define the item.", ""
		})]
		[EditorElseCondition]
		[EditorEndCondition]
		public ItemGain<FormulaObjectSelection>[] item = new ItemGain<FormulaObjectSelection>[] { new ItemGain<FormulaObjectSelection>() };


		// combatant
		[EditorFoldout("Combatant Settings", "Define the combatant which's inventory will be used.")]
		[EditorCondition("createItem", false)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		// inventory containers
		[EditorHelp("Use Inventory Container", "Select items from a defined inventory container.\n" +
			"No items will be selected if the combatant doesn't have inventory containers " +
			"(e.g. when feature not used or limited to player combatants).")]
		[EditorSeparator]
		public bool useInventoryContainer = false;

		[EditorHelp("Inventory Container", "Select the inventory container that will be used.")]
		[EditorEndFoldout]
		[EditorCondition("useInventoryContainer", true)]
		[EditorEndCondition(3)]
		[EditorAutoInit]
		public AssetSelection<InventoryContainerAsset> inventoryContainer;

		public SelectItemNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else if(this.createItem)
			{
				Combatant user = call.GetUserCombatant();
				List<IShortcut> items = new List<IShortcut>();
				for(int i = 0; i < this.item.Length; i++)
				{
					items.Add(this.item[i].CreateShortcut(user.Call));
				}
				this.dataChange.Change(items, call, true);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					List<IShortcut> items = new List<IShortcut>();
					if(this.allItems)
					{
						if(this.useInventoryContainer)
						{
							InventoryContainer container = combatant.Inventory.GetContainer(this.inventoryContainer.StoredAsset);
							if(container != null)
							{
								this.inventoryAccess.GetAll(container,
									this.limitItemType && this.itemType.StoredAsset != null ?
										this.itemType.StoredAsset.Settings : null, true, ref items);
							}
						}
						else
						{
							this.inventoryAccess.GetAll(combatant.Inventory,
								this.limitItemType && this.itemType.StoredAsset != null ?
									this.itemType.StoredAsset.Settings : null, true, ref items);
						}
					}
					else if(this.useInventoryContainer)
					{
						InventoryContainer container = combatant.Inventory.GetContainer(this.inventoryContainer.StoredAsset);
						if(container != null)
						{
							for(int j = 0; j < this.item.Length; j++)
							{
								this.item[j].GetFromInventoryContainer(call, container, true, ref items);
							}
						}
					}
					else
					{
						for(int j = 0; j < this.item.Length; j++)
						{
							this.item[j].GetFromInventory(call, combatant.Inventory, true, ref items);
						}
					}
					this.dataChange.Change(items, call, true);
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.dataChange.IsClear)
			{
				return this.dataChange.ToString();
			}
			return this.dataChange.ToString() + ": " +
				(this.createItem ? "Create" : (this.origin.ToString() + (this.allItems ? " all items" : "")));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Selected Data Level", "The level of something stored in selected data is used.\n" +
		"E.g. uses the level of an ability, equipment, combatant or class stored in selected data as value.", "")]
	[NodeInfo("Selected Data")]
	public class SelectedDataLevelNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();


		// selected data
		[EditorSeparator]
		public SelectedData<FormulaObjectSelection> selectedData = new SelectedData<FormulaObjectSelection>("action", SelectedDataOriginType.Local);

		[EditorHelp("Multi Value Use", "Select how values of multiple level contents will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[EditorSeparator]
		public MultiFloatValueUse multiValueType = MultiFloatValueUse.Add;

		public SelectedDataLevelNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			List<ILevel> content = this.selectedData.GetSelectedData<ILevel>(call, SelectedDataHelper.Get<ILevel>);
			if(content != null &&
				content.Count > 0)
			{
				List<int> values = new List<int>();
				for(int i=0; i<content.Count; i++)
				{
					values.Add(content[i].Level);
				}

				int value = 0;
				if(values.Count > 0)
				{
					value = ValueHelper.GetMultiValue(values, this.multiValueType);
				}
				this.formulaOperator.Use(ref call.result, value);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.selectedData.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
