﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Shortcut Slot (Item Type)", "The combatant must or mustn't have a shortcut slot assigned with an inventory shortcut (e.g. item or equipment) of a defined item type.", "")]
	public class ShortcutSlotItemTypeStatusConditionType : BaseStatusConditionType
	{
		public ShortcutSlot slot = new ShortcutSlot();

		[EditorHelp("Item Type", "Select the item type that will be checked for.")]
		public AssetSelection<ItemTypeAsset> itemType = new AssetSelection<ItemTypeAsset>();

		[EditorHelp("Use Sub-Types", "The sub-types of the defined item type will also be checked.", "")]
		public bool useSubTypes = false;

		[EditorHelp("Is Valid", "The shortcut slot must contain the defined item type.\n" +
			"If disabled, the shortcut slot mustn't contain the defined item type.", "")]
		[EditorSeparator]
		public bool isValid = true;

		public ShortcutSlotItemTypeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.slot.ToString() + (this.isValid ? " is " : " not ") + this.itemType.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.itemType.StoredAsset != null)
			{
				Combatant owner = null;
				IInventoryShortcut tmpShortcut = this.slot.GetShortcut(combatant, out owner) as IInventoryShortcut;
				return tmpShortcut != null &&
					tmpShortcut.IsItemType(this.itemType.StoredAsset.Settings, this.useSubTypes) == this.isValid;
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ShortcutsChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ShortcutsChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ShortcutsChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ShortcutsChangedSimple -= notify;
		}
	}
}
