﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Shortcut Slot", "The combatant must or mustn't have a shortcut slot assigned with a defined shortcut.", "")]
	public class ShortcutSlotStatusConditionType : BaseStatusConditionType
	{
		public ShortcutSlotAssignment shortcut = new ShortcutSlotAssignment();

		[EditorHelp("Is Valid", "The shortcut slot must contain the defined shortcut.\n" +
			"If disabled, the shortcut slot mustn't contain the defined shortcut.", "")]
		[EditorSeparator]
		public bool isValid = true;

		public ShortcutSlotStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.shortcut.slot.ToString() + (this.isValid ? " is " : " not ") + this.shortcut.shortcut.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.shortcut.Check(combatant);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ShortcutsChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ShortcutsChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ShortcutsChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ShortcutsChangedSimple -= notify;
		}
	}
}
