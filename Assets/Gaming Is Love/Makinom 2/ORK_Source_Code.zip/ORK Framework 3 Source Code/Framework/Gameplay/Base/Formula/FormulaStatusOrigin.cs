
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas
{
	public enum StatusOrigin { User, Target, Player, Selected };

	public class FormulaStatusOrigin : BaseData
	{
		[EditorHelp("Status Origin", "Select combatant that will be the origin of the status:" +
			"- User: The user of the formula (i.e. the combatant who uses an ability, item, hit chances, etc.).\n" +
			"- Target: The target of the formula (i.e. the combatant who is targeted by the ability, item, hit chance, etc.).\n" +
			"- Player: The player combatant. If there is no player, the user will be used.\n" +
			"- Selected: A combatant stored in selected data will be used.", "")]
		public StatusOrigin origin = StatusOrigin.User;

		[EditorCondition("origin", StatusOrigin.Selected)]
		[EditorAutoInit]
		[EditorEndCondition]
		public SelectedData<FormulaObjectSelection> selectedData;

		[EditorHelp("Group Leader", "The group leader of the combatant will be used.\n" +
			"If disabled, the combatant will be used.", "")]
		[EditorCondition("origin", StatusOrigin.Player)]
		[EditorElseCondition]
		[EditorEndCondition]
		public bool groupLeader = false;

		public FormulaStatusOrigin()
		{

		}

		public FormulaStatusOrigin(StatusOrigin origin)
		{
			this.origin = origin;
			if(StatusOrigin.Selected == this.origin)
			{
				this.selectedData = new SelectedData<FormulaObjectSelection>();
			}
		}

		public Combatant GetCombatant(FormulaCall call)
		{
			if(StatusOrigin.Player == this.origin)
			{
				if(ORK.Game.ActiveGroup.Leader != null)
				{
					return ORK.Game.ActiveGroup.Leader;
				}
			}
			else
			{
				Combatant combatant = null;
				if(StatusOrigin.User == this.origin)
				{
					combatant = call.GetUserCombatant();
				}
				else if(StatusOrigin.Target == this.origin)
				{
					combatant = call.GetTargetCombatant();
				}
				else if(StatusOrigin.Selected == this.origin)
				{
					combatant = this.selectedData.GetSelectedDataSingle<Combatant>(call, ORKSelectedDataHelper.GetCombatant);
				}
				if(combatant != null)
				{
					return this.groupLeader ? combatant.Group.Leader : combatant;
				}
			}
			return null;
		}

		public override string ToString()
		{
			if(StatusOrigin.Player == this.origin)
			{
				return "Player";
			}
			else if(StatusOrigin.Selected == this.origin)
			{
				return this.selectedData.ToString() +
					(this.groupLeader ? " (Leader)" : "");
			}
			else
			{
				return this.origin.ToString() +
					(this.groupLeader ? " (Leader)" : "");
			}
		}
	}
}
