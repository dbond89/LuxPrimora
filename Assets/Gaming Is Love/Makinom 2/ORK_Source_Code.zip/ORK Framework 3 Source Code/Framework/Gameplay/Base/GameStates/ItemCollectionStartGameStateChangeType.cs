﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Item Collection Start", "When an item collection starts (via 'Item Collector' component).")]
	public class ItemCollectionStartGameStateChangeType : BaseGameStateChangeType
	{
		public ItemCollectionStartGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Control.ItemCollectionStart += notify;
		}
	}
}
