﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Ability", "The combatant must or mustn't have a selected ability.", "")]
	public class AbilityStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Ability", "Select the ability that will be used.", "")]
		public AssetSelection<AbilityAsset> ability = new AssetSelection<AbilityAsset>();

		[EditorHelp("Level", "The level of the ability that will be checked for.\n" +
			"The combatant must have at least the defined ability level.", "")]
		[EditorLimit(1, false)]
		public int level = 1;

		[EditorHelp("Ability Is", "Select if the ability is:\n" +
			"- Known: The combatant must know the ability (i.e. the ability is available).\n" +
			"- Learned: The combatant must have learned the ability.\n" +
			"- Group Ability: The ability must be a group ability of the combatant's group.\n" +
			"- Temporary: The ability is added as temporary ability.", "")]
		public AbilityCheckType abilityCheck = AbilityCheckType.Known;

		[EditorHelp("Ignore Availability", "Ignore ability availability settings and use all abilities added to the combatant.")]
		[EditorCondition("abilityCheck", AbilityCheckType.Known)]
		[EditorEndCondition]
		public bool ignoreAvailability = false;

		[EditorHelp("Is Valid", "The 'Ability Is' check must be valid.\n" +
			"If disabled, the check must not be valid (i.e. " +
			"'Knows' = mustn't know at all, " +
			"'Learned' = mustn't be learned, " +
			"'Group Ability' = mustn't be a group ability).", "")]
		public bool isValid = true;

		public AbilityStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.ability.ToString() + (this.isValid ? " is " : " not ") + this.abilityCheck;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.ability.StoredAsset != null)
			{
				if(AbilityCheckType.Known == this.abilityCheck)
				{
					return combatant.Abilities.Has(this.ability.StoredAsset.Settings, this.level, this.ignoreAvailability) == this.isValid;
				}
				else if(AbilityCheckType.Learned == this.abilityCheck)
				{
					return combatant.Abilities.HasLearned(this.ability.StoredAsset.Settings, this.level) == this.isValid;
				}
				else if(AbilityCheckType.GroupAbility == this.abilityCheck)
				{
					return combatant.Group.Abilities.HasLearned(this.ability.StoredAsset.Settings, this.level) == this.isValid;
				}
				else if(AbilityCheckType.Temporary == this.abilityCheck)
				{
					return combatant.Abilities.HasTemporary(this.ability.StoredAsset.Settings, this.level) == this.isValid;
				}
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AbilitiesChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AbilitiesChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.AbilitiesChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.AbilitiesChangedSimple -= notify;
		}
	}
}
