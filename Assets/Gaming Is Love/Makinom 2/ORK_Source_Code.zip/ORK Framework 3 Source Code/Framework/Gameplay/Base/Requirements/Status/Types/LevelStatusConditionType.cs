﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Level", "The combatants level (or class level) will be compared to a defined value.")]
	public class LevelStatusConditionType : BaseStatusConditionType
	{
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();


		// class level
		[EditorHelp("Class Level", "If enabled, the combatants class level will be used instead of the base level.\n" +
			"The class level refers to the combatant's current single-class, unless a defined class is checked.\n" +
			"Use the 'Class Slot Level' to check a class on a class slot.", "")]
		public bool classLevel = false;

		[EditorHelp("Define Class", "Define the class which's class level will be checked.\n" +
			"If the combatant never used the defined class, it's class level will be 0.\n" +
			"If disabled, the class level of the combatant's current class will be checked.", "")]
		[EditorCondition("classLevel", true)]
		public bool checkDefinedClassLevel = false;

		[EditorHelp("Class", "Select the class which's level will be checked.\n" +
			"If the combatant never used the class, it's class level will be 0.", "")]
		[EditorCondition("checkDefinedClassLevel", true)]
		[EditorEndCondition(2)]
		public AssetSelection<ClassAsset> useClass = new AssetSelection<ClassAsset>();


		public LevelStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.classLevel ?
				(this.checkDefinedClassLevel ? this.useClass.ToString() + " " : "class level ") :
				"level ") + this.check.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(
				this.classLevel ?
					(this.checkDefinedClassLevel && this.useClass.StoredAsset != null ?
						combatant.Class.GetLevel(this.useClass.StoredAsset.Settings) :
						combatant.Class.Level) :
					combatant.Status.Level,
				combatant.Call);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			if(this.classLevel)
			{
				combatant.Events.ClassLevelChanged += notify.NotifyStatusChanged;
			}
			else
			{
				combatant.Events.LevelChanged += notify.NotifyStatusChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			if(this.classLevel)
			{
				combatant.Events.ClassLevelChanged -= notify.NotifyStatusChanged;
			}
			else
			{
				combatant.Events.LevelChanged -= notify.NotifyStatusChanged;
			}
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			if(this.classLevel)
			{
				combatant.Events.ClassLevelChangedSimple += notify;
			}
			else
			{
				combatant.Events.LevelChangedSimple += notify;
			}
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			if(this.classLevel)
			{
				combatant.Events.ClassLevelChangedSimple -= notify;
			}
			else
			{
				combatant.Events.LevelChangedSimple -= notify;
			}
		}
	}
}
