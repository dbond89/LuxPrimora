﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Status Value Changed State", "The selected status value must or mustn't be in changed state.\n" +
		"Changed state is a short duration after a change was done to a status value (defined in 'UI > Text Display Settings').")]
	public class StatusValueChangedStateStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Status Value", "Select the status value that will be used.", "")]
		public AssetSelection<StatusValueAsset> statusValue = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Is Changed State", "The status value must be in changed state.\n" +
			"If disabled, the status value mustn't be in changed state.", "")]
		public bool isChangedState = true;

		public StatusValueChangedStateStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.statusValue.ToString() + (this.isChangedState ? " is changed" : " is not changed");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue statusValue = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				return statusValue != null &&
					statusValue.ChangedState.IsChangedState == this.isChangedState;
			}
			return false;
		}

		public override bool CheckPreview(Combatant combatant)
		{
			return this.Check(combatant);
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete || combatant.Bestiary.status.statusValues))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue sv = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				if(sv.ChangedState != null)
				{
					sv.ChangedState.LastValueChanged += notify.NotifyStatusChanged;
				}
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue sv = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				if(sv.ChangedState != null)
				{
					sv.ChangedState.LastValueChanged -= notify.NotifyStatusChanged;
				}
			}
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue sv = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				if(sv.ChangedState != null)
				{
					sv.ChangedState.SimpleLastValueChanged += notify;
				}
			}
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue sv = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				if(sv.ChangedState != null)
				{
					sv.ChangedState.SimpleLastValueChanged -= notify;
				}
			}
		}
	}
}
