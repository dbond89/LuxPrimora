﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Shortcut Slot (Ability Type)", "The combatant must or mustn't have a shortcut slot assigned with an ability of a defined ability type.", "")]
	public class ShortcutSlotAbilityTypeStatusConditionType : BaseStatusConditionType
	{
		public ShortcutSlot slot = new ShortcutSlot();

		[EditorHelp("Ability Type", "Select the ability type that will be checked for.")]
		public AssetSelection<AbilityTypeAsset> abilityType = new AssetSelection<AbilityTypeAsset>();

		[EditorHelp("Use Sub-Types", "The sub-types of the defined ability type will also be checked.", "")]
		public bool useSubTypes = false;

		[EditorHelp("Is Valid", "The shortcut slot must contain the defined ability type.\n" +
			"If disabled, the shortcut slot mustn't contain the defined ability type.", "")]
		[EditorSeparator]
		public bool isValid = true;

		public ShortcutSlotAbilityTypeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.slot.ToString() + (this.isValid ? " is " : " not ") + this.abilityType.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.abilityType.StoredAsset != null)
			{
				Combatant owner = null;
				AbilityShortcut tmpShortcut = this.slot.GetShortcut(combatant, out owner) as AbilityShortcut;
				return tmpShortcut != null &&
					tmpShortcut.Setting.IsType(this.abilityType.StoredAsset.Settings, this.useSubTypes) == this.isValid;
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ShortcutsChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ShortcutsChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ShortcutsChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ShortcutsChangedSimple -= notify;
		}
	}
}
