﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class PlayerInputIDSettings : BaseData
	{
		[EditorHelp("Add Interaction Controllers", "Automatically add interaction controllers (via the interaction controller prefab settings) " +
			"to all combatants of the player group that have an input ID set (e.g. via 'Change Combatant Input ID' node in schematics).")]
		public bool addInteractionControllers = false;

		[EditorHelp("Add Player Controls", "Automatically add player controls to all combatants of the player group " +
			"that have an input ID set (e.g. via 'Change Combatant Input ID' node in schematics).")]
		public bool addPlayerControls = false;

		public PlayerInputIDSettings()
		{

		}
	}
}
