
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Animations
{
	public class MecanimStateCheck : BaseData, IFoldoutInfo
	{
		[EditorHelp("Active State Name", "The name of the active state (without layer name).", "")]
		[EditorWidth(true)]
		public string name = "";
		
		[EditorHelp("Layer Index", "The index of the AnimatorController layer that will be checked.", "")]
		[EditorLimit(0, false)]
		public int layer = 0;
		
		[EditorHelp("Layer Name", "The name of the AnimatorController layer that will be checked.", "")]
		[EditorWidth(true)]
		public string layerName = "Base Layer";
		
		[EditorHelp("Check Transition", "Check if the AnimatorController layer is in a transition.", "")]
		public bool checkTransition = false;
		
		[EditorHelp("In Transition", "The layer must be in transition.\n" +
			"If disabled, the layer mustn't be in transition.", "")]
		[EditorCondition("checkTransition", true)]
		[EditorEndCondition]
		public bool inTransition = false;
		
		
		// set values
		[EditorArray("Add Parameter", "Adds a parameter that will be set.", "", 
			"Remove", "Removes this parameter.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {"Set Parameter", "The parameter will be set to the defined value.", ""})]
		public MecanimParameter[] parameter = new MecanimParameter[0];
		
		
		// ingame
		private int stateID = 0;
		
		public MecanimStateCheck()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.stateID = Animator.StringToHash(this.layerName + "." + this.name);
		}

		public virtual string GetFoldoutInfo()
		{
			return this.name;
		}


		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public void Check(Animator animator)
		{
			if(animator.GetCurrentAnimatorStateInfo(this.layer).fullPathHash == this.stateID && 
				(!this.checkTransition || animator.IsInTransition(this.layer) == this.inTransition))
			{
				for(int i=0; i<this.parameter.Length; i++)
				{
					this.parameter[i].Set(animator);
				}
			}
		}
	}
}
