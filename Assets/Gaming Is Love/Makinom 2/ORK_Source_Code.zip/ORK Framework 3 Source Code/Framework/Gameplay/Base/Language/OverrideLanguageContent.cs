﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class OverrideLanguageContent : BaseData
	{
		// own name
		[EditorHelp("Own Name", "Override the name.", "")]
		[EditorFoldout("Override Name", "Use a custom name.")]
		public bool ownName = false;

		[EditorHelp("Name", "Define the name that will be used.", "")]
		[EditorEndFoldout]
		[EditorCallback("textcodes:name", EditorCallbackType.Before)]
		[EditorCondition("ownName", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLanguageExport("OwnName")]
		public LanguageData<TextContent> name;


		// own short name
		[EditorHelp("Own Short Name", "Override the short name.", "")]
		[EditorFoldout("Override Short Name", "Use a custom short name.")]
		public bool ownShortName = false;

		[EditorHelp("Short Name", "Define the short name that will be used.", "")]
		[EditorEndFoldout]
		[EditorCallback("textcodes:shortname", EditorCallbackType.Before)]
		[EditorCondition("ownShortName", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLanguageExport("OwnShortName")]
		public LanguageData<TextContent> shortName;


		// own description
		[EditorHelp("Own Description", "Override the description.", "")]
		[EditorFoldout("Override Description", "Use a custom description.")]
		public bool ownDescription = false;

		[EditorHelp("Description", "Define the description that will be used.", "")]
		[EditorEndFoldout]
		[EditorCallback("textcodes:description", EditorCallbackType.Before)]
		[EditorCondition("ownDescription", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLanguageExport("OwnDescription")]
		public LanguageData<TextContent> description;


		// own icon
		[EditorHelp("Own Icon", "Override the icon.", "")]
		[EditorFoldout("Override Icon", "Use a custom icon.")]
		public bool ownIcon = false;

		[EditorHelp("Icon", "Select the icon that will be used.", "")]
		[EditorEndFoldout]
		[EditorCondition("ownIcon", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public LanguageData<IconContent> icon;


		// custom content
		[EditorFoldout("Custom Content", "Custom content information can be displayed via text codes.\n" +
			"Custom content using the same content key as the ability's custom content will override it.",
			initialState = false)]
		[EditorEndFoldout]
		[EditorArray("Add Custom Content", "Adds a custom content information.", "",
			"Remove", "Removes this custom content", "",
			isCopy = true, isMove = true, foldout = true, foldoutText = new string[]
			{
				"Custom Content", "Custom content can be displayed via text codes using the content key.", ""
			})]
		public CustomContentInformation[] customContent = new CustomContentInformation[0];

		public OverrideLanguageContent()
		{

		}

		public string GetName(string originalName)
		{
			if(this.name != null)
			{
				string name = this.name.Current;
				return name.Replace("<name>", originalName);
			}
			return originalName;
		}

		public string GetShortName(string originalShortName)
		{
			if(this.shortName != null)
			{
				string name = this.shortName.Current;
				return name.Replace("<shortname>", originalShortName);
			}
			return originalShortName;
		}

		public string GetDescription(string originalDescription)
		{
			if(this.description != null)
			{
				string description = this.description.Current;
				return description.Replace("<description>", originalDescription);
			}
			return originalDescription;
		}

		public virtual string GetCustomContent(string contentKey, CustomContentInformation[] originalCustomContent)
		{
			for(int i = 0; i < this.customContent.Length; i++)
			{
				if(this.customContent[i].contentKey == contentKey)
				{
					return this.customContent[i].content.Current;
				}
			}
			if(originalCustomContent != null)
			{
				for(int i = 0; i < originalCustomContent.Length; i++)
				{
					if(originalCustomContent[i].contentKey == contentKey)
					{
						return originalCustomContent[i].content.Current;
					}
				}
			}
			return "";
		}
	}
}
