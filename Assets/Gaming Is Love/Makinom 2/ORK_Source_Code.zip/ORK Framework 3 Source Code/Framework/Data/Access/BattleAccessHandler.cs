﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BattleAccessHandler
	{
		public BattleAccessHandler()
		{

		}


		/*
		============================================================================
		Loot functions
		============================================================================
		*/
		/// <summary>
		/// Adds loot to the battle loot.
		/// </summary>
		/// <param name="item">The loot item/equipment that will be added</param>
		public virtual void AddLoot(IShortcut item)
		{
			ORK.Battle.Loot.AddLoot(item);
		}

		/// <summary>
		/// Adds experience to the battle loot.
		/// </summary>
		/// <param name="statusValue">The status value.</param>
		/// <param name="exp">The experience that will be added.</param>
		/// <param name="level">The level of the source combatant.</param>
		/// <param name="classLevel">The class level of the source combatant.</param>
		/// <param name="forCombatant">The combatant the experience is for, or <c>null</c> if not for a specific combatant.</param>
		public virtual void AddExperience(StatusValueSetting statusValue, int exp, int level, int classLevel, Combatant forCombatant)
		{
			ORK.Battle.Loot.AddExperience(statusValue, exp, level, classLevel, forCombatant);
		}

		/// <summary>
		/// Changes the current experience in the battle loot.
		/// </summary>
		/// <param name="statusValue">The status value.</param>
		/// <param name="change">The value used to change the experience.</param>
		/// <param name="op">The operator used, e.g. add or multiply.</param>
		/// <param name="forCombatant">The combatant who's experience will be changed, or <c>null</c> if not using a specific combatant.</param>
		public virtual void ChangeExperience(StatusValueSetting statusValue, float change, FloatOperator op, Combatant forCombatant)
		{
			ORK.Battle.Loot.ChangeExperience(statusValue, change, op, forCombatant);
		}

		/// <summary>
		/// Adds a 'Normal' type status value reward to the battle loot.
		/// </summary>
		/// <param name="statusValue">The status value.</param>
		/// <param name="value">The value that will be added.</param>
		public virtual void AddNormalStatusValue(StatusValueSetting statusValue, int value)
		{
			ORK.Battle.Loot.AddNormalStatusValue(statusValue, value);
		}

		/// <summary>
		/// Changes the current 'Normal' type status value reward in the battle loot.
		/// </summary>
		/// <param name="statusValue">The status value.</param>
		/// <param name="change">The value used to change the reward.</param>
		/// <param name="op">The operator used, e.g. add or multiply.</param>
		public virtual void ChangeNormalStatusValue(StatusValueSetting statusValue, float change, FloatOperator op)
		{
			ORK.Battle.Loot.ChangeNormalStatusValue(statusValue, change, op);
		}

		/// <summary>
		/// Collects the loot, experience and 'Normal' type status value rewards of a combatant.
		/// </summary>
		/// <param name="combatant">The combatant.</param>
		public virtual void GetGainsFrom(Combatant combatant)
		{
			ORK.Battle.Loot.GetGainsFrom(combatant);
		}

		/// <summary>
		/// Collects the loot, experience and 'Normal' type status value rewards of a combatant.
		/// Loot will be added to a provided list instead of the battle loot.
		/// </summary>
		/// <param name="combatant">The combatant</param>
		/// <param name="list">The list the loot wil be added to.</param>
		/// <param name="useStackType"><c>true</c> if item stacking is used (based on the stacking setup for the item).</param>
		public virtual void GetGainsFrom(Combatant combatant, List<IShortcut> list, bool useStackType)
		{
			ORK.Battle.Loot.GetGainsFrom(combatant, list, useStackType);
		}

		/// <summary>
		/// Collects the current battle loot.
		/// </summary>
		/// <param name="collectLoot">Loot will be collected (e.g. items, equipment, etc.).</param>
		/// <param name="collectExp">Experience and 'Normal' type status value rewards will be collected.</param>
		/// <param name="showGains">The loot dialogue will be displayed.</param>
		/// <param name="autoClose">The auto close time for the loot dialoge, use a value below 0 to not use auto closing.</param>
		/// <param name="autoCloseControlable"><c>true</c> if auto close loot dialogues can still be accepted to close them sooner.</param>
		/// <param name="useItemBox">Store the loot into an item box.</param>
		/// <param name="itemBoxAddType">Use the item stacking options when storing loot in an item box.</param>
		/// <param name="itemBoxID">The box ID of the item box.</param>
		/// <param name="notifyFinished">Delegate to call when the collection finished.</param>
		/// <param name="immediateCollection"><c>true</c> if this loot collection is an immediate collection (i.e. not at the end of the battle).</param>
		public virtual void CollectGains(bool collectLoot, bool collectExp,
			bool showGains, float autoClose, bool autoCloseControlable,
			bool useItemBox, bool itemBoxAddType, string itemBoxID,
			Notify notifyFinished, bool immediateCollection)
		{
			ORK.BattleEnd.CollectGains(collectLoot, collectExp,
				showGains, autoClose, autoCloseControlable,
				useItemBox, itemBoxAddType, itemBoxID,
				notifyFinished, immediateCollection);
		}


		/*
		============================================================================
		Flying text functions
		============================================================================
		*/
		public virtual void ShowMissFlyingText(string info, Combatant combatant, GameObject targetObject, IContent content)
		{
			ORK.BattleTexts.ShowMissFlyingText(info, combatant, targetObject, content);
		}

		public virtual void ShowBlockFlyingText(string info, Combatant combatant, GameObject targetObject, IContent content)
		{
			ORK.BattleTexts.ShowBlockFlyingText(info, combatant, targetObject, content);
		}

		public virtual void ShowCastCancelFlyingText(string info, Combatant combatant, GameObject targetObject, IContent content)
		{
			ORK.BattleTexts.ShowCastCancelFlyingText(info, combatant, targetObject, content);
		}

		public virtual void ShowLevelUpFlyingText(string info, Combatant combatant, GameObject targetObject)
		{
			ORK.BattleTexts.ShowLevelUpFlyingText(info, combatant, targetObject);
		}

		public virtual void ShowClassLevelUpFlyingText(string info, Combatant combatant, GameObject targetObject)
		{
			ORK.BattleTexts.ShowClassLevelUpFlyingText(info, combatant, targetObject);
		}
	}
}
