﻿
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class TextDisplaySettings : BaseSettings
	{
		// quantity texts
		[EditorFoldout("Formatting Texts", "Define text settings related to formatting/display of values.", "",
			"Quantity Texts", "Quantity texts are used when using the info texts (e.g. in menu screens).", "")]
		[EditorEndFoldout]
		public QuantityTextSettings quantityText = new QuantityTextSettings();

		// price texts
		[EditorFoldout("Price Texts", "Price texts are used to display buy/sell prices in the info texts (e.g. shop layouts).", "")]
		[EditorEndFoldout]
		public PriceTextSettings priceText = new PriceTextSettings();

		// time formatting
		[EditorFoldout("Time Formatting", "Define how time/duration values will be formatted.", "")]
		[EditorEndFoldout]
		public TimeFormatSettings timeFormatting = new TimeFormatSettings();

		// number formatting
		[EditorFoldout("Number Formatting", "Define how certain number values will be formatted when displayed as text (e.g. in HUDs and menus).\n" +
			"Uses C# numeric format strings.", "",
			initialState = false)]
		[EditorEndFoldout(2)]
		[EditorLabel("Uses C# numeric format strings, e.g. for 1500:\n" +
			"0 > 1500\n" +
			"#,# > 1,500\n" +
			"0.0 > 1500.0")]
		[EditorCallback("button:ResetTextFormats", EditorCallbackType.Before)]
		public NumberFormatSettings numberFormatting = new NumberFormatSettings();


		// combatant
		// combatant choice
		[EditorFoldout("Combatant Texts", "Define text settings related to combatants.", "",
			"Default Combatant Choice Layout", "Define the default layout for combatant choices " +
			"in battle menus or combatant selections.\n" +
			"You can either display each combatant as a simple button with name and icon, " +
			"or use a HUD as a template to create more complex choices with status information, value bars, etc.\n" +
			"The default layout can be overridden by each battle menu and combatant selection.", "")]
		[EditorEndFoldout]
		public CombatantChoiceLayout combatantChoice = new CombatantChoiceLayout();

		// combatant list displays
		[EditorFoldout("Combatant Name List", "Define how the name of multiple combatants will be displayed.\n" +
			"This is e.g. used in console texts when displaying a list of targets or when using the " +
			"'<equipped>' text code for abilities to display the names of combatants that know an ability.", "")]
		[EditorEndFoldout(2)]
		public CombatantNamesDisplay combatantNameList = new CombatantNamesDisplay();


		// status
		// use costs display
		[EditorFoldout("Use Cost Display", "Define how an ability's use costs will be displayed in menus.", "")]
		[EditorEndFoldout]
		public UseCostDisplay useCostDisplay = new UseCostDisplay();

		// bonus display
		[EditorFoldout("Bonus Display", "Define how bonuses will be displayed when " +
			"using the '<bonus>' text code in the descriptions of status effects, equipment, " +
			"passive abilities, classes and combatants.", "")]
		[EditorEndFoldout]
		public BonusDisplay bonusDisplay = new BonusDisplay();

		// preview settings
		[EditorFoldout("Status Preview Settings", "These settings handle the status previews for combatants.\n" +
			"Status previews can e.g. be displayed in HUDs when using the 'Preview' value origin for status values.", "")]
		[EditorEndFoldout]
		public PreviewSettings preview = new PreviewSettings();


		// status change display
		// status value last change
		[EditorHelp("Combined Timeout (s)", "Define the time in seconds for status value changes to be considered as part of combined changes.\n" +
			"Combined changes add multiple status value changes together to display the total changes.\n" +
			"If the time between two changes exceeds this timeout, the combined change will reset (to the new change value).")]
		[EditorFoldout("Status Change Display", "Define how status changes of an ability or item on the user and targets are displayed.", "",
			"Status Value Changed State", "Define settings related to the changed state of status values and the last change values.\n" +
			"A status value has to enable using the changed state in it's settings.", "")]
		[EditorEndFoldout]
		public StatusValueChangedStateSettings statusValueChangedState = new StatusValueChangedStateSettings();

		// user changes text code
		[EditorHelp("User Changes Text", "The text displayed for the user changes text codes.", "")]
		[EditorFoldout("User Changes Text Code", "Define the text used to replace user changes text codes of an ability or item.\n" +
			"Use the available text codes to add chance and change information from the status change display settings.\n" +
			"Please note that the user changes also include the use costs.", "")]
		[EditorEndFoldout]
		[EditorSeparator]
		[EditorLabel("Chances:\n" +
			"<hitchance> = hit chance, <criticalchance> = critical chance\n" +
			"Changes:\n" +
			"<statuschanges> = status value changes, <statuschangescritical> = critical status value changes\n" +
			"<effectadd> = apply status effect list, <effectaddcritical> = critical apply status effect list\n" +
			"<effectremove> = apply remove effect list, <effectremovecritical> = critical remove status effect list")]
		public LanguageData<TextContent> textCodeUserChanges = new LanguageData<TextContent>("<statuschanges>");

		// target changes text code
		[EditorHelp("Dummy Target Combatant", "The target change text code uses this combatant to calculate target changes.\n" +
			"If 'None' is selected, uses the user as target.")]
		[EditorFoldout("Target Changes Text Code", "Define the text used to replace target changes text codes of an ability or item.\n" +
			"Use the available text codes to add chance and change information from the status change display settings.", "")]
		public AssetSelection<CombatantAsset> targetChangeDummyTarget = new AssetSelection<CombatantAsset>();

		[EditorHelp("User Level", "The dummy target will have the same level as the user, otherwise uses the default start level.\n" +
			"Please note that using the user level will create a new dummy target whenever the current user's level differs from the last created one, impacting performance.")]
		public bool targetChangeDummyTargetUserLevel = false;

		[EditorHelp("Use Tooltip Combatant", "Use a combatant that's currently available as tooltip.\n" +
			"If no combatant is available, it'll use the dummy target as defined.")]
		public bool targetChangeUseTooltipCombatant = false;

		[EditorHelp("Target Changes Text", "The text displayed for the user changes text codes.", "")]
		[EditorEndFoldout]
		[EditorSeparator]
		[EditorLabel("Chances:\n" +
			"<hitchance> = hit chance, <criticalchance> = critical chance\n" +
			"Changes:\n" +
			"<statuschanges> = status value changes, <statuschangescritical> = critical status value changes\n" +
			"<effectadd> = apply status effect list, <effectaddcritical> = critical apply status effect list\n" +
			"<effectremove> = apply remove effect list, <effectremovecritical> = critical remove status effect list")]
		public LanguageData<TextContent> textCodeTargetChanges = new LanguageData<TextContent>("<statuschanges>");

		// default texts
		[EditorEndFoldout]
		public StatusChangeDisplaySettings statusChangeDisplay = new StatusChangeDisplaySettings();


		// in-game
		protected Combatant dummyTargetInstance;

		public TextDisplaySettings(MakinomProjectAsset project)
		{
			this.dummyTargetInstance = null;
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Text Display Settings"; }
		}


		/*
		============================================================================
		Text code functions
		============================================================================
		*/
		public virtual string GetUserChanges(IShortcut shortcut, Combatant user, bool isBestiary)
		{
			UIText text = this.textCodeUserChanges.Current;
			this.statusChangeDisplay.GetContent(text, user,
				new StatusChangeInformation(shortcut, user, true),
				isBestiary);
			return text.Text;
		}

		public virtual string GetTargetChanges(IShortcut shortcut, Combatant user, bool isBestiary)
		{
			Combatant target = null;
			UIText text = this.textCodeTargetChanges.Current;

			if(this.targetChangeUseTooltipCombatant &&
				Maki.UI.Tooltip.TooltipContent != null)
			{
				target = TextDisplaySettings.GetTooltipCombatant(Maki.UI.Tooltip.TooltipContent);
				if(target == null &&
					Maki.UI.Tooltip.TooltipContent != Maki.UI.Tooltip.RealTooltipContent)
				{
					target = TextDisplaySettings.GetTooltipCombatant(Maki.UI.Tooltip.RealTooltipContent);
				}
			}

			if(target == null &&
				this.targetChangeDummyTarget.StoredAsset != null)
			{
				if(this.targetChangeDummyTargetUserLevel)
				{
					if(this.dummyTargetInstance == null ||
						this.dummyTargetInstance.Status.Level != user.Status.Level)
					{
						this.dummyTargetInstance = this.targetChangeDummyTarget.StoredAsset.Settings.Create(new Group(), false, false);
						this.dummyTargetInstance.Init(user.Status.Level, user.Class.Level, null, false, true, true, true, true, true);
					}
				}
				else if(this.dummyTargetInstance == null)
				{
					this.dummyTargetInstance = this.targetChangeDummyTarget.StoredAsset.Settings.Create(new Group(), false, false);
					this.dummyTargetInstance.Init();
				}
				target = this.dummyTargetInstance;
			}

			this.statusChangeDisplay.GetContent(text, user,
				new StatusChangeInformation(shortcut, user, target != null ? target : user, true),
				isBestiary);
			return text.Text;
		}

		protected static Combatant GetTooltipCombatant(IContent tooltip)
		{
			if(tooltip is Combatant)
			{
				return (Combatant)tooltip;
			}
			else if(tooltip is HUDCombatantWrapper)
			{
				return ((HUDCombatantWrapper)tooltip).Combatant;
			}
			else if(tooltip is UIInputContent)
			{
				UIInputContent content = (UIInputContent)tooltip;
				if(content.Tooltip is Combatant)
				{
					return (Combatant)content.Tooltip;
				}
				else if(content.DragContent is Combatant)
				{
					return (Combatant)content.DragContent;
				}
				else if(content.SchematicContext is Combatant)
				{
					return (Combatant)content.SchematicContext;
				}
			}
			return null;
		}
	}
}
