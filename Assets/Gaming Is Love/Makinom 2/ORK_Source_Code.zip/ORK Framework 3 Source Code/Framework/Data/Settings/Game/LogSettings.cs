﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class LogSettings : BaseSettings
	{
		[EditorFoldout("Log Notifications", "Log notifications can be displayed when a log changes.", "")]
		public NotificationQueueSettings queueNotifications = new NotificationQueueSettings();

		[EditorEndFoldout]
		public LogNotificationSettings notifications = new LogNotificationSettings();

		public LogSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Log Settings"; }
		}
	}
}
