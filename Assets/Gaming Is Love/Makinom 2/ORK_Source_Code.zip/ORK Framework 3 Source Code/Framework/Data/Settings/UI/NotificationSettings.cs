﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class NotificationSettings : BaseSettings
	{
		// default settings
		[EditorHelp("Default Queue Mode", "Select how multiple notifications are displayed:\n" +
			"- Add: Notifications are displayed immediately while previous notifications are still displayed.\n" +
			"- Replace: Notifications are displayed immediately, closing the previous notification.\n" +
			"- Queue: Notifications are queued, displaying them after previous notifications where closed.", "")]
		[EditorFoldout("Notification Settings", "Define the default notification settings.\n" +
			"Individual notifications can override these settings.", "")]
		public NotificationQueueType defaultQueueMode = NotificationQueueType.Queue;

		[EditorHelp("Max Display Count", "The number of notifications that can be displayed at the same time before being queued.")]
		[EditorLimit(1)]
		[EditorIndent]
		[EditorCondition("defaultQueueMode", NotificationQueueType.Queue)]
		[EditorEndCondition]
		public int defaultMaxDisplayCount = 1;

		[EditorFoldout("Default Sound", "Define the default sound used by notifications.\n" +
			"Individual notifications can override these settings and enable if a sound is played.", "")]
		[EditorEndFoldout]
		public NotificationAudioSettings defaultSound = new NotificationAudioSettings();

		[EditorFoldout("Default UI Box", "Define the default UI box and UI layout used by notifications.\n" +
			"Individual notifications can override these settings.", "")]
		[EditorEndFoldout(2)]
		public NotificationBoxSettings defaultBox = new NotificationBoxSettings();


		// ability notifications
		[EditorFoldout("Ability Notifications", "Learning and forgetting abilities can display notifications.", "")]
		public NotificationQueueSettings abilityQueueMode = new NotificationQueueSettings();

		[EditorEndFoldout]
		public AbilityNotificationSettings abilityNotifications = new AbilityNotificationSettings();


		// class notifications
		[EditorFoldout("Class Notifications", "Adding and removing classes and class slots can display notifications.\n" +
			"Only used for player combatants.", "")]
		public NotificationQueueSettings classQueueMode = new NotificationQueueSettings();

		[EditorEndFoldout]
		public ClassNotifications classNotifications = new ClassNotifications();


		public NotificationSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Notifications"; }
		}
	}
}
