
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum BattleCameraType { None, BlockSchematics, AllowSchematics };

	public class BattleCameraSettings : BaseSettings
	{
		[EditorHelp("Battle Camera Type", "Select the battle camera that will be used:\n" +
			"- None: The battle camera isn't used.\n" +
			"- Block Schematics: Camera changes by schematics are blocked, performs rotations and look at actions.\n" +
			"- Allow Schematics: Camera changes by schematics are allowed, performs look at actions (except 'Simple Look').\n" +
			"Please note that rotation and 'Simple Look' look at actions only work with blocked camera controls.", "")]
		[EditorFoldout("Battle Camera", "The battle camera settings can override and " +
			"block camera changes made by battle animations.\n" +
			"The camera can be set to rotate around the arena and automatically look at users and targets, " +
			"use camera positions or change the camera control target of an active camera control to show who's in action.\n" +
			"The battle camera is not available in 'Real Time' type battles.", "")]
		public BattleCameraType type = BattleCameraType.None;

		// block schematics camera
		[EditorHelp("Combatant Center", "The camera will use the center of all combatants " +
			"for it's rotation and look movements.\n" +
			"If disabled, the position of the battle arena is used.", "")]
		[EditorSeparator]
		[EditorCondition("type", BattleCameraType.BlockSchematics)]
		public bool useCombatantCenter = false;

		[EditorHelp("Remember Position", "The last position of the battle camera is remembered.\n" +
			"If the battle camera changes (e.g. to look at the latest target), " +
			"it will return to the remembered position after it's 'look at' action is finished.", "")]
		public bool rememberPosition = false;

		[EditorHelp("Look Damping", "The damping for 'look at' camera changes.\n" +
			"The higher the value, the faster the camera will get to it's looking position.\n" +
			"A lower value will result in a smoother camera movement.", "")]
		public float lookAtDamping = 5.0f;

		// rotation
		[EditorHelp("Rotation Axis", "Set at the camera's rotation axis by setting it's X, Y and Z rotation.\n" +
			"E.g. X=0, Y=1, Z=0 will rotate along the Y-axis around the battle arena.\n" +
			"A value between 0 and 1 is recommended.", "")]
		[EditorSeparator]
		public Vector3 rotationAxis = Vector3.zero;

		[EditorHelp("Rotation Speed", "The speed at which the camera will rotate.\n" +
			"Set the speed to 0 if no camera rotation is wanted.\n" +
			"Use negative numbers to invert rotation.", "")]
		public float rotationSpeed = 0;

		// rotation limit
		[EditorHelp("Limit Rotation", "The rotation is limited to defined minimum/maximum degrees.\n" +
			"If the camera rotation reaches a limit (rotation at battle start + min/max rotation), " +
			"the rotation is inverted (the camera rotates into the opposite direction).", "")]
		[EditorSeparator]
		public bool limitRotation = false;

		[EditorHelp("Minimum Rotation", "The minimum rotation of the camera (left limit) in degree.\n" +
			"The value has to be between -180 and 0.", "")]
		[EditorCondition("limitRotation", true)]
		public Vector3 minRotation = Vector3.zero;

		[EditorHelp("Maximum Rotation", "The maximum rotation of the camera (right limit) in degree.\n" +
			"The value has to be between 0 and 180.", "")]
		[EditorCallback("check:rotations", EditorCallbackType.After)]
		[EditorEndCondition(2)]
		public Vector3 maxRotation = Vector3.zero;


		// toggle key
		[EditorFoldout("Toggle Key", "Use an input key to toggle the battle camera on or off.", "")]
		[EditorCondition("type", BattleCameraType.None)]
		[EditorElseCondition]
		public ToggleKeySetting toggleKey = new ToggleKeySetting();

		[EditorHelp("Clear Look Targets", "Clear the current look targets when toggling off the battle camera.", "")]
		[EditorCondition("toggleKey.useKey", true)]
		public bool toggleClearLookTargets = false;

		[EditorHelp("Only Player Choosing", "The toggle key can only be used while a player combatant is choosing an action.", "")]
		[EditorEndFoldout]
		[EditorEndCondition(2)]
		public bool toggleOnlyPlayerChoosing = false;


		// camera control target
		[EditorHelp("Camera Control Target", "Changes the camera control target to " +
			"the selecting player combatant, the battle arena or the player.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[EditorFoldout("Camera Control Target", "Optionally change the camera control target to " +
			"the selecting player combatant, the battle arena or the player.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[EditorCondition("type", BattleCameraType.None)]
		[EditorElseCondition]
		public bool cameraControlTarget = false;

		[EditorHelp("Selecting Player Member", "The currently selecting player group member is used as target.\n" +
			"The battle arena or player are used if no selecting player combatant is available.", "")]
		[EditorCondition("cameraControlTarget", true)]
		public bool cameraControlTargetSelectingPlayer = true;

		[EditorHelp("Battle Arena", "The battle arena is used as target.\n" +
			"The player is used if the battle arena isn't available.", "")]
		public bool cameraControlTargetArena = true;

		[EditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		[EditorSeparator]
		public bool ownControlTargetTransition = false;

		[EditorEndFoldout(2)]
		[EditorCondition("ownControlTargetTransition", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public CameraControlTargetTransition controlTargetTransition;


		// look at actions
		// damage
		[EditorFoldout("Look At Latest Damage", "The camera can look at the last combatant that was target of an action's calculation.\n" +
			"Beside receiving damage, this also includes missed attacks, death actions, etc.", "")]
		public LookAtSettings latestDamage = new LookAtSettings();

		[EditorFoldout("Block Actions", "Block looking at the latest damage from defined actions.", "")]
		[EditorEndFoldout(2)]
		public LookAtActionBlock latestDamageActionBlock = new LookAtActionBlock();

		// user
		[EditorFoldout("Look At Latest User", "The camera can look at the combatant " +
			"who performs the current action (i.e. the last action that has been started).", "")]
		public LookAtSettings latestUser = new LookAtSettings();

		[EditorFoldout("Block Actions", "Block looking at the latest user from defined actions.", "")]
		[EditorEndFoldout(2)]
		public LookAtActionBlock latestUserActionBlock = new LookAtActionBlock();

		// menu
		[EditorFoldout("Look At Selecting User", "The camera can look at the combatant that currently selects an action.\n" +
			"This works like 'Look At Menu User', but isn't limited to player controlled combatants.", "")]
		[EditorEndFoldout]
		public LookAtSettings selectingUser = new LookAtSettings();

		// menu
		[EditorFoldout("Look At Menu User", "The camera can look at the combatant with the battle menu opened (i.e. only player controlled combatants).\n" +
			"When the battle menu isn't opened automatically, the camera will still look at the combatant that starts selecting actions.", "")]
		[EditorEndFoldout]
		public LookAtSettings menuUser = new LookAtSettings();

		// selection
		[EditorFoldout("Look At Selection", "The camera can look at the currently selected combatant (target selection).", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public LookAtSettings selection = new LookAtSettings();


		// ingame
		protected bool lookingAtSomething = false;

		protected bool forceReset = false;

		protected int blockedByAnimation = 0;

		protected Transform camera = null;

		protected Camera cameraComponent = null;

		protected bool activated = false;

		protected bool toggleState = true;

		protected BattleComponent battleComponent = null;

		protected int lastLookAtIndex = -1;

		protected Vector3 lastPos = Vector3.zero;

		protected Quaternion lastRot = Quaternion.identity;

		protected float lastFoV = 40;

		protected Vector3 useRotationAxis = Vector3.zero;

		protected Vector3 startRotationAxis = Vector3.zero;


		// look at reset times
		protected float damageTimeout = -1;

		protected float userTimeout = -1;

		protected float selectingUserTimeout = -1;

		protected float menuTimeout = -1;

		protected float selectionTimeout = -1;

		public BattleCameraSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Battle Camera"; }
		}


		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public virtual bool IsNone
		{
			get { return BattleCameraType.None == this.type; }
		}

		public virtual bool IsBlockSchematics
		{
			get { return BattleCameraType.BlockSchematics == this.type; }
		}

		protected virtual void SetCameraControlTarget()
		{
			if(!this.IsNone &&
				this.cameraControlTarget)
			{
				if(this.cameraControlTargetSelectingPlayer &&
					ORK.Battle.SelectingCombatant != null)
				{
					ORK.Control.SetCameraControlTarget(ORK.Battle.SelectingCombatant.GameObject,
						this.ownControlTargetTransition ? this.controlTargetTransition : null);
				}
				else if(this.cameraControlTargetArena &&
					ORK.Battle.BattleArena != null)
				{
					ORK.Control.SetCameraControlTarget(ORK.Battle.BattleArena.gameObject,
						this.ownControlTargetTransition ? this.controlTargetTransition : null);
				}
				else
				{
					ORK.Control.SetCameraControlTarget(null,
						this.ownControlTargetTransition ? this.controlTargetTransition : null);
				}
			}
		}

		public virtual void SetToggleStartState()
		{
			this.toggleState = this.toggleKey.toggleStartState;
		}


		/*
		============================================================================
		Look at functions
		============================================================================
		*/
		protected virtual void ClearLookTargets()
		{
			this.latestDamage.Target = null;
			this.damageTimeout = -1;

			this.latestUser.Target = null;
			this.userTimeout = -1;

			this.selectingUser.Target = null;
			this.selectingUserTimeout = -1;

			this.menuUser.Target = null;
			this.menuTimeout = -1;

			this.selection.Target = null;
			this.selectionTimeout = -1;
		}

		public virtual void SetLatestDamage(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.latestDamage.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.latestDamage.SetTarget(this.camera, user, target, ref this.damageTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}

		public virtual void SetLatestUser(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.latestUser.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.latestUser.SetTarget(this.camera, user, target, ref this.userTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}

		public virtual void SetSelectingUser(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.selectingUser.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.selectingUser.SetTarget(this.camera, user, target, ref this.selectingUserTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}

		public virtual void SetMenuUser(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.menuUser.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.menuUser.SetTarget(this.camera, user, target, ref this.menuTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}

		public virtual void SetSelection(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.selection.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.selection.SetTarget(this.camera, user, target, ref this.selectionTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}


		/*
		============================================================================
		Block functions
		============================================================================
		*/
		public virtual void BlockedByAnimation(bool block)
		{
			if(block)
			{
				this.blockedByAnimation++;
			}
			else
			{
				this.blockedByAnimation--;
			}
			this.forceReset = true;
		}

		public virtual bool ToggleState
		{
			get { return this.toggleState; }
			set
			{
				if(this.toggleState != value)
				{
					this.toggleState = value;

					if(this.activated &&
						this.toggleClearLookTargets &&
						!this.toggleState)
					{
						this.ClearLookTargets();
						this.SetCameraControlTarget();
					}
				}
			}
		}


		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public virtual void Tick()
		{
			if(this.activated)
			{
				if(!this.toggleOnlyPlayerChoosing ||
					ORK.Battle.HasChoosingPlayer)
				{
					bool tmpToggle = this.toggleState;
					this.toggleKey.GetToggleState(ref this.toggleState);

					if(this.toggleClearLookTargets &&
						!this.toggleState &&
						tmpToggle != this.toggleState)
					{
						this.ClearLookTargets();
						this.SetCameraControlTarget();
					}
				}

				if(this.toggleState)
				{
					// reset timers
					if(this.damageTimeout > 0)
					{
						this.damageTimeout -= Time.deltaTime;
						if(this.damageTimeout <= 0)
						{
							this.SetLatestDamage(null, null);
						}
					}
					if(this.userTimeout > 0)
					{
						this.userTimeout -= Time.deltaTime;
						if(this.userTimeout <= 0)
						{
							this.SetLatestUser(null, null);
						}
					}
					if(this.selectingUserTimeout > 0)
					{
						this.selectingUserTimeout -= Time.deltaTime;
						if(this.selectingUserTimeout <= 0)
						{
							this.SetSelectingUser(null, null);
						}
					}
					if(this.menuTimeout > 0)
					{
						this.menuTimeout -= Time.deltaTime;
						if(this.menuTimeout <= 0)
						{
							this.SetMenuUser(null, null);
						}
					}
					if(this.selectionTimeout > 0)
					{
						this.selectionTimeout -= Time.deltaTime;
						if(this.selectionTimeout <= 0)
						{
							this.SetSelection(null, null);
						}
					}

					// rotation
					if(Maki.Control.CameraBlocked &&
						this.IsBlockSchematics &&
						this.blockedByAnimation == 0 &&
						this.camera != null)
					{
						int index = -1;
						bool looking = false;
						bool resetBase = true;

						if(this.selection.Target != null && this.selection.CheckCamPos())
						{
							if(this.selection.IsSimpleLook)
							{
								index = 0;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.selection.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.selection.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}
						if(resetBase && this.selectingUser.Target != null && this.selectingUser.CheckCamPos())
						{
							if(this.selectingUser.IsSimpleLook)
							{
								index = 1;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.selectingUser.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.selectingUser.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}
						if(resetBase && this.menuUser.Target != null && this.menuUser.CheckCamPos())
						{
							if(this.menuUser.IsSimpleLook)
							{
								index = 1;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.menuUser.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.menuUser.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}
						if(resetBase && this.latestDamage.Target != null && this.latestDamage.CheckCamPos())
						{
							if(this.latestDamage.IsSimpleLook)
							{
								index = 2;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.latestDamage.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.latestDamage.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}
						if(resetBase && this.latestUser.Target != null && this.latestUser.CheckCamPos())
						{
							if(this.latestUser.IsSimpleLook)
							{
								index = 2;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.latestUser.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.latestUser.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}

						if(!looking)
						{
							if(this.forceReset ||
								(this.lookingAtSomething &&
								(resetBase || index != this.lastLookAtIndex)))
							{
								this.camera.SetPositionAndRotation(this.lastPos, this.lastRot);
								if(this.cameraComponent != null)
								{
									this.cameraComponent.fieldOfView = this.lastFoV;
								}
								this.forceReset = false;
								this.lookingAtSomething = false;
							}

							if(this.rotationSpeed != 0)
							{
								if(this.useCombatantCenter)
								{
									this.camera.RotateAround(ORK.Battle.GetCombatantCenter().transform.position,
										this.useRotationAxis, this.rotationSpeed * Time.deltaTime);
								}
								else
								{
									this.camera.RotateAround(this.battleComponent.transform.position,
										this.useRotationAxis, this.rotationSpeed * Time.deltaTime);
								}

								if(this.limitRotation)
								{
									Vector3 tmpRot = this.camera.eulerAngles - this.startRotationAxis;
									VectorHelper.SecureVector(ref tmpRot, -190, 190, 360);

									// X-axis
									if(tmpRot.x <= this.minRotation.x)
									{
										this.useRotationAxis.x = -this.useRotationAxis.x;
									}
									else if(tmpRot.x >= this.maxRotation.x)
									{
										this.useRotationAxis.x = -this.useRotationAxis.x;
									}
									// Y-axis
									if(tmpRot.y <= this.minRotation.y)
									{
										this.useRotationAxis.y = -this.useRotationAxis.y;
									}
									else if(tmpRot.y >= this.maxRotation.y)
									{
										this.useRotationAxis.y = -this.useRotationAxis.y;
									}
									// Z-axis
									if(tmpRot.z <= this.minRotation.z)
									{
										this.useRotationAxis.z = -this.useRotationAxis.z;
									}
									else if(tmpRot.z >= this.maxRotation.z)
									{
										this.useRotationAxis.z = -this.useRotationAxis.z;
									}
								}
							}

							if(this.rememberPosition)
							{
								this.lastPos = this.camera.position;
								this.lastRot = this.camera.rotation;
								if(this.cameraComponent != null)
								{
									this.lastFoV = this.cameraComponent.fieldOfView;
								}
							}
						}
						this.lastLookAtIndex = index;
					}
				}
			}
		}

		public virtual void StartBattle(BattleComponent battleComponent)
		{
			this.battleComponent = battleComponent;
			this.useRotationAxis = this.rotationAxis;
			this.startRotationAxis = Vector3.zero;
			this.lookingAtSomething = false;
			if(Maki.Game.Camera != null)
			{
				this.camera = Maki.Game.Camera.transform;
				this.cameraComponent = this.camera.GetComponent<Camera>();
				this.lastPos = this.camera.position;
				this.lastRot = this.camera.rotation;
				if(this.cameraComponent != null)
				{
					this.lastFoV = this.cameraComponent.fieldOfView;
				}
				this.startRotationAxis = this.camera.eulerAngles;
			}

			this.ClearLookTargets();
			this.SetCameraControlTarget();
			this.lastLookAtIndex = -1;
			this.blockedByAnimation = 0;
			this.forceReset = false;
			this.activated = true;
		}

		public virtual void EndBattle()
		{
			ORK.Control.SetCameraControlTarget(null,
				this.cameraControlTarget && this.ownControlTargetTransition ?
					this.controlTargetTransition : null);
			this.activated = false;
			this.blockedByAnimation = 0;
			this.lookingAtSomething = false;
			this.forceReset = false;
			this.camera = null;
			this.cameraComponent = null;
			this.ClearLookTargets();
			this.battleComponent = null;
			this.lastLookAtIndex = -1;
			this.lastPos = Vector3.zero;
			this.lastRot = Quaternion.identity;
		}
	}
}
