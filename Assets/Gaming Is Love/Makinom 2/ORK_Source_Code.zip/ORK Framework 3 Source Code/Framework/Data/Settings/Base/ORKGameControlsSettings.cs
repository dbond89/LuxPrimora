
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ORKGameControlsSettings : BaseSettings
	{
		// player controls
		[EditorFoldout("ORK Control Settings", "Set the base game controls.", "",
			"Player Controls", "ORK can automatically add controls to your player when spawned.\n" +
			"When the player is changed during the game, the controls will be removed from the " +
			"old player and added to the new one.",
			"https://orkframework.com/guide/documentation/getting-started/player-camera-controls/")]
		[EditorEndFoldout]
		public PlayerControlSettings playerControl = new PlayerControlSettings();


		// camera controls
		[EditorFoldout("Camera Controls", "ORK can automatically add camera controls to your scene's main camera.\n" +
			"If you don't want to automatically add camera control in a scene, " +
			"simply add a NoCameraControl component to the camera.",
			"https://orkframework.com/guide/documentation/getting-started/player-camera-controls/")]
		[EditorEndFoldout]
		public CameraControlSettings cameraControl = new CameraControlSettings();


		// other controls
		// input ID settings
		[EditorFoldout("Other Controls", "Define other control settings.", "",
			"Player Input ID Settings", "Optionally add player controls and interaction controllers to all combatants of the player group " +
			"that have an input ID set (e.g. via 'Change Combatant Input ID' node in schematics).", "")]
		[EditorEndFoldout]
		public PlayerInputIDSettings inputIDSettings = new PlayerInputIDSettings();

		// member switch settings
		[EditorFoldout("Group Member Keys", "You can use input keys to change the player " +
			"or switch to another group members battle menu.", "",
			"Next Member Key", "The key used to change to the next member of the player group.\n" +
			"Can be used to change to another group member's battle menu (if available) or switch the player.", "")]
		[EditorEndFoldout]
		public AudioInputSelection nextMemberKey = new AudioInputSelection();

		[EditorFoldout("Previous Member Key", "The key used to change to the previous member of the player group.\n" +
			"Can be used to change to another group member's battle menu (if available) or switch the player.", "")]
		[EditorEndFoldout]
		public AudioInputSelection previousMemberKey = new AudioInputSelection();

		[EditorHelp("Only Battle Group", "Only members of the battle group will be available for switching.", "")]
		public bool switchOnlyBattle = false;

		[EditorHelp("Not Dead", "Dead combatants will be ignored, " +
			"i.e. only alive members of the active player group will be used.", "")]
		public bool switchNotDead = false;

		[EditorHelp("Keep Scale", "When spawning a new player it'll use the scale of the currently spawned player.\n" +
			"Only used if a new player is spawned, but used in all cases when this happens (i.e. not limited to the group member keys).")]
		public bool switchKeepScale = false;

		// change player
		[EditorHelp("Switch Player", "The plus/minus keys will switch the player from " +
			"one group member to the other.\n" +
			"If your party isn't spawned in the field, the current player object will be " +
			"replaced with the new player.\n" +
			"A combatant with 'Not Controllable' enabled can't be switched to.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Change Player")]
		public bool switchPlayer = false;

		[EditorHelp("Field", "The player can be changed in the field (i.e. outside of battles).", "")]
		[EditorCondition("switchPlayer", true)]
		public bool switchField = true;

		[EditorEndCondition]
		[EditorAutoInit]
		public BattleSystemCheck switchBattleSystem;

		// change menu user
		[EditorHelp("Switch Menu User", "The plus/minus keys will switch the current battle menu user.\n" +
			"This is only possible when more than one battle menu is displayed " +
			"(i.e. also only in 'Active Time' and 'Real Time' battles).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Change Menu User")]
		public bool switchMenuUser = false;

		[EditorHelp("Active Time", "The menu user can be changed in 'Active Time' battles.", "")]
		[EditorCondition("switchMenuUser", true)]
		public bool switchMenuActiveTime = false;

		[EditorHelp("Real Time", "The menu user can be changed in 'Real Time' battles.", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public bool switchMenuRealTime = true;


		// ability level changes
		[EditorFoldout("Ability Level Keys", "You can use input keys to change " +
			"the used level of a currently selected ability.", "",
			"Next Level Key", "The key to be used to increase the level of a currently selected ability.\n" +
			"Can be done in the battle menu or ability menu screens.\n" +
			"The ability level keys are used to circle through already learned ability levels.", "")]
		[EditorEndFoldout]
		public AudioInputSelection nextLevelKey = new AudioInputSelection();

		[EditorFoldout("Previous Level Key", "The key to be used to decrease the level of a currently selected ability.\n" +
			"Can be done in the battle menu or ability menu screens.\n" +
			"The ability level keys are used to circle through already learned ability levels.", "")]
		[EditorEndFoldout]
		public AudioInputSelection previousLevelKey = new AudioInputSelection();

		[EditorHelp("Loop Levels", "The ability level changes will loop when at the end " +
			"(level 1 or currently learned maximum level).", "")]
		[EditorEndFoldout(3)]
		public bool loopAbilityLevels = false;

		public ORKGameControlsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "ORK Game Controls"; }
		}


		/*
		============================================================================
		Player components functions
		============================================================================
		*/
		public virtual void AddPlayerComponents(GameObject gameObject)
		{
			if(gameObject != null)
			{
				this.playerControl.AddPlayerControl(gameObject);
			}
		}

		public virtual void RemovePlayerComponents(GameObject gameObject)
		{
			if(gameObject != null)
			{
				this.playerControl.RemovePlayerControl(gameObject);
			}
		}
	}
}

