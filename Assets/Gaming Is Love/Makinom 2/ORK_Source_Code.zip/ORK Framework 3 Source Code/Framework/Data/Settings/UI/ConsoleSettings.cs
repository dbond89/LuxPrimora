
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ConsoleSettings : BaseSettings
	{
		// base settings
		[EditorHelp("Use Console", "Use the console.", "")]
		[EditorFoldout("Base Settings", "Define the base console settings.", "")]
		public bool useConsole = false;

		[EditorHelp("Unity Console Output", "Print new console lines to the Unity console.\n" +
			"This is only done when playing in the Unity Editor and ignores 'Use Console'.", "")]
		public bool unityConsole = false;

		[EditorHelp("Maximum Lines", "Define the maximum number of lines the console will display.", "")]
		[EditorLimit(1, false)]
		public int maxLines = 50;

		// auto remove
		[EditorHelp("Auto Remove Lines", "Automatically remove console lines after a defined amount of time.", "")]
		public bool autoRemoveLines = false;

		[EditorHelp("Remove Every (s)", "The time in seconds between removing console lines.", "")]
		[EditorIndent]
		[EditorLimit(0.0f, false)]
		[EditorCondition("autoRemoveLines", true)]
		[EditorEndCondition]
		public float autoRemoveEvery = 3;


		// combatant consoles
		[EditorHelp("Use Combatant Consoles", "Use combatant consoles.\n" +
			"Allows using consoles per combatant, automatically adding texts that concern a combatant to their console.\n" +
			"E.g. if a combatant is user or target of an action, the action text will be added to the combatant's console.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Combatant Consoles")]
		public bool useCombatantConsoles = false;

		[EditorHelp("Maximum Lines Combatant", "Define the maximum number of lines the combatant consoles will display.", "")]
		[EditorEndFoldout]
		[EditorLimit(1, false)]
		[EditorCondition("useCombatantConsoles", true)]
		[EditorEndCondition]
		public int maxLinesCombatant = 30;


		// text wrapping
		[EditorHelp("Before Line Text", "Text added before each console line.\n" +
			"This text will be added after the 'Before Line Text' of the console type.", "")]
		[EditorFoldout("Before Line Text", "Text added before each console line.\n" +
			"This text will be added after the 'Before Line Text' of the console type.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("BeforeLine")]
		public LanguageData<TextContent> beforeLineText = new LanguageData<TextContent>();

		[EditorHelp("After Line Text", "Text added after each console line.\n" +
			"This text will be added before the 'After Line Text' of the console type.", "")]
		[EditorFoldout("After Line Text", "Text added after each console line.\n" +
			"This text will be added before the 'After Line Text' of the console type.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("AfterLine")]
		public LanguageData<TextContent> afterLineText = new LanguageData<TextContent>();


		// actions
		[EditorHelp("Display Actions", "Action texts will be added to the console.\n" +
			"Actions are everything like using abilities or items, trying to escape, defending or dying.", "")]
		[EditorFoldout("Action Texts", "Define if and what texts will be added for using actions.\n" +
			"Actions are everything like using abilities or items, trying to escape, defending or dying.", "")]
		public bool displayActions = true;

		[EditorFoldout("Max. Player Distance", "The maximum distance (in world units) to the player to add action texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with actions.", "")]
		[EditorEndFoldout]
		[EditorLimit(0.0f, false)]
		public ConsoleRange actionRange = new ConsoleRange();

		// target names
		[EditorHelp("Own Target Names", "Override the default combatant name list settings " +
			"('UI > Text Display Settings') for action texts.", "")]
		[EditorFoldout("Target Names", "Define how the name of multiple targets will be displayed.", "")]
		public bool ownActionTargetNames = false;

		[EditorEndFoldout]
		[EditorCondition("ownActionTargetNames", true)]
		[EditorEndCondition]
		public CombatantNamesDisplay actionTargetNames = new CombatantNamesDisplay();

		// console action previews
		[EditorFoldout("Status Value Changes", "Define the text used to display status value changes " +
			"in ability and item action texts.", "")]
		[EditorEndFoldout]
		public StatusValueChangeDisplay actionStatusValueChanges = new StatusValueChangeDisplay();

		// add action texts
		[EditorFoldout("Add Action Texts", "The add action texts will be added to the console " +
			"when an action has been selected by a combatant.", "",
			"Ability Text", "The text displayed for add ability actions.\n" +
			"Can be overridden for each ability individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionPreview actionAddAbility = new ConsoleTextActionPreview(false);

		[EditorFoldout("Item Text", "The text displayed for adding item actions.\n" +
			"Can be overridden for each item individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionPreview actionAddItem = new ConsoleTextActionPreview(false);

		[EditorFoldout("Defend Text", "The text displayed for adding defend actions (defend command).\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionAddDefend = new ConsoleTextActionSimple(false);

		[EditorFoldout("Escape Text", "The text displayed for adding escape actions (escape command).\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionAddEscape = new ConsoleTextActionSimple(false);

		[EditorFoldout("Death Text", "The text displayed for adding death actions (dying).\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionAddDeath = new ConsoleTextActionSimple(false);

		[EditorFoldout("None Text", "The text displayed for adding none actions (doing nothing).\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionAddNone = new ConsoleTextActionSimple(false);

		[EditorFoldout("Change Member Text", "The text displayed for adding change member actions.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSingle actionAddChangeMember = new ConsoleTextActionSingle(false);

		[EditorFoldout("Join Battle Text", "The text displayed for adding join battle actions.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionAddJoinBattle = new ConsoleTextActionSimple(false);

		[EditorFoldout("Grid Move Text", "The text displayed for adding grid move actions (move command).\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextActionSimple actionAddGridMove = new ConsoleTextActionSimple(false);

		// perform action texts
		[EditorFoldout("Perform Action Texts", "The perform action texts will be added to the console " +
			"when an action starts performing (or casting).", "",
			"Ability Text", "The text displayed for using abilities.\n" +
			"Can be overridden for each ability individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionPreview actionAbility = new ConsoleTextActionPreview("<username> uses <name> on <targetnames>.");

		[EditorFoldout("Cast Action Text", "The text displayed for casting an action.\n" +
			"Can be overridden for each ability or item individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionPreview actionCast = new ConsoleTextActionPreview("<username> casts <name>.");

		[EditorFoldout("Cancel Cast Text", "The text displayed for canceling an action cast.\n" +
			"Can be overridden for each ability or item individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionPreview actionCastCancel = new ConsoleTextActionPreview("<username> cancels casting <name>.");

		[EditorFoldout("Item Text", "The text displayed for using item actions.\n" +
			"Can be overridden for each item individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionPreview actionItem = new ConsoleTextActionPreview("<username> uses <name> on <targetnames>.");

		[EditorFoldout("Defend Text", "The text displayed for using the defend command.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionDefend = new ConsoleTextActionSimple("<username> defends himself.");

		[EditorFoldout("Escape Text", "The text displayed for using the escape command.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionEscape = new ConsoleTextActionSimple("<username> tries to escape.");

		[EditorFoldout("Death Text", "The text displayed for dying.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionDeath = new ConsoleTextActionSimple("<username> dies.");

		[EditorFoldout("None Text", "The text displayed for doing nothing.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionNone = new ConsoleTextActionSimple("<username> does nothing.");

		[EditorFoldout("Change Member Text", "The text displayed for changing members.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSingle actionChangeMember = new ConsoleTextActionSingle("<username> is exchanged for <targetname>.");

		[EditorFoldout("Join Battle Text", "The text displayed for joining a battle.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextActionSimple actionJoinBattle = new ConsoleTextActionSimple("<username> joins the battle.");

		[EditorFoldout("Grid Move Text", "The text displayed for moving on the grid (move command).\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout(3)]
		public ConsoleTextActionSimple actionGridMove = new ConsoleTextActionSimple("<username> moves.");


		// learning
		[EditorHelp("Display Learning", "Learning texts will be added to the console.\n" +
			"Learning texts are used for everything like learning new abilities, crafting recipes and logs.", "")]
		[EditorFoldout("Learning Texts", "Define if and what texts will be added for learning new things.\n" +
			"Learning texts are used for everything like learning new abilities, crafting recipes and logs.", "")]
		public bool displayLearning = true;

		[EditorFoldout("Max. Player Distance", "The maximum distance (in world units) to the player to add learning texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with learning texts.", "")]
		[EditorEndFoldout]
		[EditorLimit(0.0f, false)]
		public ConsoleRange learningRange = new ConsoleRange();

		// learning group names
		[EditorHelp("Own Group Member Names", "Override the default combatant name list settings " +
			"('UI > Text Display Settings') for learning texts.", "")]
		[EditorFoldout("Group Member Names", "Define how the name of multiple group members will be displayed.\n" +
			"This is used for group abilities.", "")]
		public bool ownLearningGroupNames = false;

		[EditorEndFoldout]
		[EditorCondition("ownLearningGroupNames", true)]
		[EditorEndCondition]
		public CombatantNamesDisplay learningGroupNames = new CombatantNamesDisplay();

		// learning texts
		[EditorFoldout("Ability Text", "The text displayed for learning a new ability.\n" +
			"Can be overridden for each ability individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning learnAbility = new ConsoleTextLearning("<username> learns <name>");

		[EditorFoldout("Group Ability Text", "The text displayed for learning a new group ability.\n" +
			"Can be overridden for each ability individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextGroupLearning learnGroupAbility = new ConsoleTextGroupLearning("<usernames> learn <name>");

		[EditorFoldout("Crafting Recipe Text", "The text displayed for adding a crafting recipe.\n" +
			"Can be overridden for each crafting recipe individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextCrafting learnCraftingRecipe = new ConsoleTextCrafting("<username> receives <name>.");

		[EditorFoldout("Log Text", "The text displayed for learning a new log.\n" +
			"Can be overridden for each log individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning learnLog = new ConsoleTextLearning("<username> learns <name>.");

		[EditorFoldout("Log Update Text", "The text displayed for learning a new log text.\n" +
			"Can be overridden for each log text individually.\n" +
			"<name> displays the name of the log.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextLearning learnLogUpdate = new ConsoleTextLearning("<name> updated.");


		// forgetting
		[EditorHelp("Display Forgetting", "Forgetting texts will be added to the console.\n" +
			"Forgetting texts are used for everything like forgetting abilities, crafting recipes and logs.", "")]
		[EditorFoldout("Forgetting Texts", "Define if and what texts will be added for forgetting learned things.\n" +
			"Forgetting texts are used for everything like forgetting abilities, crafting recipes and logs.", "")]
		public bool displayForgetting = true;

		[EditorFoldout("Max. Player Distance", "The maximum distance (in world units) to the player to add forgetting texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with forgetting texts.", "")]
		[EditorEndFoldout]
		[EditorLimit(0.0f, false)]
		public ConsoleRange forgettingRange = new ConsoleRange();

		// forget group names
		[EditorHelp("Own Group Member Names", "Override the default combatant name list settings " +
			"('UI > Text Display Settings') for forgetting texts.", "")]
		[EditorFoldout("Group Member Names", "Define how the name of multiple group members will be displayed.\n" +
			"This is used for group abilities.", "")]
		public bool ownForgettingGroupNames = false;

		[EditorEndFoldout]
		[EditorCondition("ownForgettingGroupNames", true)]
		[EditorEndCondition]
		public CombatantNamesDisplay forgettingGroupNames = new CombatantNamesDisplay();

		// forgetting texts
		[EditorFoldout("Ability Text", "The text displayed for forgetting an ability.\n" +
			"Can be overridden for each ability individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning forgetAbility = new ConsoleTextLearning("<username> forgets <name>.");

		[EditorFoldout("Group Ability Text", "The text displayed for forgetting a group ability.\n" +
			"Can be overridden for each ability individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextGroupLearning forgetGroupAbility = new ConsoleTextGroupLearning("<usernames> forget <name>");

		[EditorFoldout("Crafting Recipe Text", "The text displayed for removing a crafting recipe.\n" +
			"Can be overridden for each crafting recipe individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextCrafting forgetCraftingRecipe = new ConsoleTextCrafting("<username> removes <name>.");

		[EditorFoldout("Log Text", "The text displayed for forgett a log.\n" +
			"Can be overridden for each log individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning forgetLog = new ConsoleTextLearning("<username> forgets <name>.");

		[EditorFoldout("Log Update Text", "The text displayed for forgetting a log text.\n" +
			"Can be overridden for each log text individually.\n" +
			"<name> displays the name of the log.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextLearning forgetLogUpdate = new ConsoleTextLearning("<name> updated.");


		// status
		[EditorHelp("Display Status", "Status texts will be added to the console.\n" +
			"Status texts are everything like applying/removing status effects and changes to status values.", "")]
		[EditorFoldout("Status Texts", "Define if and what texts will be added for status changes.\n" +
			"Status texts are everything like applying/removing status effects and changes to status values.", "")]
		public bool displayStatus = true;

		[EditorFoldout("Max. Player Distance", "The maximum distance (in world units) to the player to add status texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with status texts.", "")]
		[EditorEndFoldout]
		[EditorLimit(0.0f, false)]
		public ConsoleRange statusRange = new ConsoleRange();

		// status texts
		// status value
		[EditorFoldout("Increase Status Value Text", "The text displayed for increasing a status value.\n" +
			"Can be overridden for each status value individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextStatusValue statusIncreaseSV = new ConsoleTextStatusValue("<username> +<value> <name>.");

		[EditorFoldout("Decrease Status Value Text", "The text displayed for decreasing a status value.\n" +
			"Can be overridden for each status value individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextStatusValue statusDecreaseSV = new ConsoleTextStatusValue("<username> -<value> <name>.");

		[EditorFoldout("Set Status Value Text", "The text displayed for setting a status value.\n" +
			"Can be overridden for each status value individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextStatusValue statusSetSV = new ConsoleTextStatusValue("<username> <name> set to <value>.");

		// status effect
		[EditorFoldout("Apply Effect Text", "The text displayed for applying a status effect to a combatant.\n" +
			"Can be overridden for each status effect individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextStatusEffect statusApplyEffect = new ConsoleTextStatusEffect("<name> added to <username>.");

		[EditorFoldout("Reapply Effect Text", "The text displayed for reapplying a status effect to a combatant.\n" +
			"Can be overridden for each status effect individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextStatusEffect statusReapplyEffect = new ConsoleTextStatusEffect("<name> renewed on <username>.");

		[EditorFoldout("Miss Effect Text", "The text displayed for failing to apply a status effect to a combatant.\n" +
			"Can be overridden for each status effect individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextStatusEffect statusMissEffect = new ConsoleTextStatusEffect(false, "<name> failed on <username>.");

		[EditorFoldout("Remove Effect Text", "The text displayed for removing a status effect from a combatant.\n" +
			"Can be overridden for each status effect individually.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextStatusEffect statusRemoveEffect = new ConsoleTextStatusEffect("<name> removed from <username>.");


		// level up
		[EditorHelp("Display Level Up", "Level up texts will be added to the console.\n" +
			"Level up texts are displayed when a combatant reaches a new base/class level.", "")]
		[EditorFoldout("Level Up Texts", "Define if and what texts will be added for a combatant's level up.\n" +
			"Level up texts are displayed when a combatant reaches a new base/class level.", "")]
		public bool displayLevelUp = true;

		[EditorFoldout("Max. Player Distance", "The maximum distance (in world units) to the player to add level up texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with level up texts.", "")]
		[EditorEndFoldout]
		[EditorLimit(0.0f, false)]
		public ConsoleRange levelUpRange = new ConsoleRange();

		// level up texts
		[EditorFoldout("Level Up Text", "The text displayed when a combatant's base level increases.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLevelUp levelUp = new ConsoleTextLevelUp("<username> reaches level <level>.");

		[EditorFoldout("Class Level Up Text", "The text displayed when a combatant's class level increases.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLevelUp levelUpClass = new ConsoleTextLevelUp("<username> reaches class level <level>.");

		[EditorFoldout("Ability Level Up Text", "The text displayed when an ability's level increases.\n" +
			"Can be overridden for each ability individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLevelUp levelUpAbility = new ConsoleTextLevelUp("<username> <name> reaches level <level>.");

		[EditorFoldout("Equipment Level Up Text", "The text displayed when an equipment's level increases.\n" +
			"Can be overridden for each equipment individually.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextLevelUp levelUpEquipment = new ConsoleTextLevelUp("<username> <name> reaches level <level>.");


		// inventory
		[EditorHelp("Display Inventory", "Inventory texts will be added to the console.\n" +
			"Inventory texts are everything like adding/removing items, currency or equipment.\n" +
			"Please note that inventory texts are only displayed for the player group.", "")]
		[EditorFoldout("Inventory Texts", "Define if and what texts will be added for inventory changes.\n" +
			"Inventory texts are everything like adding/removing items, currency or equipment.\n" +
			"Please note that inventory texts are only displayed for the player group.", "")]
		public bool displayInventory = true;

		// owner names
		[EditorHelp("Own Owner Names", "Override the default combatant name list settings " +
			"('UI > Text Display Settings') for inventory texts.", "")]
		[EditorFoldout("Owner Names", "Define how the name of multiple inventory owners will be displayed.\n" +
			"This is used for 'Group' inventory.", "")]
		public bool ownInventoryOwnerNames = false;

		[EditorEndFoldout]
		[EditorCondition("ownInventoryOwnerNames", true)]
		[EditorEndCondition]
		public CombatantNamesDisplay inventoryOwnerNames = new CombatantNamesDisplay();

		// inventory texts
		// items
		[EditorFoldout("Add Item Text", "The text displayed for adding an item to the inventory.\n" +
			"Can be overridden for each item individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextInventory inventoryAddItem = new ConsoleTextInventory("<usernames> finds <name> (<quantity>).");

		[EditorFoldout("Remove Item Text", "The text displayed for removing an item from the inventory.\n" +
			"Can be overridden for each item individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextInventory inventoryRemoveItem = new ConsoleTextInventory("<usernames> drops <name> (<quantity>).");

		// currency
		[EditorFoldout("Add Currency Text", "The text displayed for adding currency to the inventory.\n" +
			"Can be overridden for each currency individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextInventory inventoryAddCurrency = new ConsoleTextInventory("<usernames> finds <name> (<quantity>).");

		[EditorFoldout("Remove Currency Text", "The text displayed for removing currency from the inventory.\n" +
			"Can be overridden for each currency individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextInventory inventoryRemoveCurrency = new ConsoleTextInventory("<usernames> drops <name> (<quantity>).");

		[EditorFoldout("Set Currency Text", "The text displayed for setting currency to a quantity.\n" +
			"Can be overridden for each currency individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextInventory inventorySetCurrency = new ConsoleTextInventory("<usernames> <name> set to <quantity>.");

		// equipment
		[EditorFoldout("Add Equipment Text", "The text displayed for adding an equipment to the inventory.\n" +
			"Can be overridden for each equipment individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextInventory inventoryAddEquipment = new ConsoleTextInventory("<usernames> finds <name> (<quantity>).");

		[EditorFoldout("Remove Equipment Text", "The text displayed for removing an equipment from the inventory.\n" +
			"Can be overridden for each equipment individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextInventory inventoryRemoveEquipment = new ConsoleTextInventory("<usernames> drops <name> (<quantity>).");

		// equipment durability
		[EditorFoldout("Equipment +Durability Text", "The text displayed for an equipment's durability increasing.\n" +
			"Can be overridden for each equipment individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextDurability durabilityIncreaseEquipment = new ConsoleTextDurability("<username>'s <name> increased to <durability>.");

		[EditorFoldout("Equipment -Durability Text", "The text displayed for an equipment's durability decreasing.\n" +
			"Can be overridden for each equipment individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextDurability durabilityDecreaseEquipment = new ConsoleTextDurability("<username>'s <name> dropped to <durability>.");

		[EditorFoldout("Equipment Outworn Text", "The text displayed for an equipment's durability reaching 0 (i.e. being outworn).\n" +
			"Can be overridden for each equipment individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextDurability durabilityOutwornEquipment = new ConsoleTextDurability("<username>'s <name> is outworn.");

		// AI behaviours
		[EditorFoldout("Add AI Behaviour Text", "The text displayed for adding an AI behaviour to the player.\n" +
			"Can be overridden for each AI behaviour individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextAI aiBehaviourAdd = new ConsoleTextAI("<name> (<quantity>) added.");

		[EditorFoldout("Remove AI Behaviour Text", "The text displayed for removing an AI behaviour from the player.\n" +
			"Can be overridden for each AI behaviour individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextAI aiBehaviourRemove = new ConsoleTextAI("<name> (<quantity>) removed.");

		// AI rulesets
		[EditorFoldout("Add AI Ruleset Text", "The text displayed for adding an AI ruleset to the player.\n" +
			"Can be overridden for each AI ruleset individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextAI aiRulesetAdd = new ConsoleTextAI("<name> (<quantity>) added.");

		[EditorFoldout("Remove AI Ruleset Text", "The text displayed for removing an AI ruleset from the player.\n" +
			"Can be overridden for each AI ruleset individually.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextAI aiRulesetRemove = new ConsoleTextAI("<name> (<quantity>) removed.");


		// quests
		[EditorHelp("Display Quests", "Quest texts will be added to the console.\n" +
			"Quest texts are everything like adding a new quest, finishing/failing a quest/task or activating a new task.", "")]
		[EditorFoldout("Quest Texts", "Define if and what texts will be added for quest related things.\n" +
			"Quest texts are everything like adding a new quest, finishing/failing a quest/task or activating a new task.", "")]
		public bool displayQuests = true;

		[EditorHelp("Display Initial Tasks", "Display a quest's initial tasks when adding the quest.\n" +
			"Initial tasks are tasks that will be activated when the quest is added.", "")]
		public bool displayInitialTasks = false;

		[EditorFoldout("Add Quest Text", "The text displayed for adding a new quest.\n" +
			"Can be overridden for each quest individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning addQuest = new ConsoleTextLearning("'<name>' added.");

		[EditorFoldout("Remove Quest Text", "The text displayed for removing a quest.\n" +
			"Can be overridden for each quest individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning removeQuest = new ConsoleTextLearning("'<name>' removed.");

		[EditorFoldout("Inactivate Quest Text", "The text displayed for inactivating a quest.\n" +
			"Can be overridden for each quest individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning inactivateQuest = new ConsoleTextLearning("'<name>' is inactive.");

		[EditorFoldout("Activate Quest Text", "The text displayed for activating a quest.\n" +
			"Can be overridden for each quest individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning activateQuest = new ConsoleTextLearning("'<name>' is active.");

		[EditorFoldout("Finish Quest Text", "The text displayed for finishing a quest.\n" +
			"Can be overridden for each quest individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning finishQuest = new ConsoleTextLearning("'<name>' finished.");

		[EditorFoldout("Fail Quest Text", "The text displayed for failing a quest.\n" +
			"Can be overridden for each quest individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning failQuest = new ConsoleTextLearning("'<name>' failed.");

		[EditorFoldout("Inactivate Task Text", "The text displayed for inactivating a task.\n" +
			"Can be overridden for each task individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning inactivateTask = new ConsoleTextLearning("Task '<name>' removed.");

		[EditorFoldout("Activate Task Text", "The text displayed for activating a task.\n" +
			"Can be overridden for each task individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning activateTask = new ConsoleTextLearning("Task '<name>' added.");

		[EditorFoldout("Finish Task Text", "The text displayed for finishing a task.\n" +
			"Can be overridden for each task individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning finishTask = new ConsoleTextLearning("Task '<name>' finished.");

		[EditorFoldout("Fail Task Text", "The text displayed for failing a task.\n" +
			"Can be overridden for each task individually.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextLearning failTask = new ConsoleTextLearning("Task '<name>' failed.");


		// research
		[EditorHelp("Display Research", "Research texts will be added to the console.\n" +
			"Please note that research texts are only displayed for the player group.", "")]
		[EditorFoldout("Research Texts", "Define if and what texts will be added for research related things.\n" +
			"Research texts are everything like adding a new research tree, start or finish researching a research item.\n" +
			"Please note that research texts are only displayed for the player group.", "")]
		public bool displayResearch = true;

		[EditorFoldout("Add Research Tree Text", "The text displayed for adding a new research tree.\n" +
			"Can be overridden for each research tree individually.\n" +
			"<name> displays the name of the research tree.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning addResearchTree = new ConsoleTextLearning("<username> learns <name>.");

		[EditorFoldout("Remove Research Tree Text", "The text displayed for removing a research tree.\n" +
			"Can be overridden for each research tree individually.\n" +
			"<name> displays the name of research tree.", "")]
		[EditorEndFoldout]
		public ConsoleTextLearning removeResearchTree = new ConsoleTextLearning("<username> forgets <name>.");

		[EditorFoldout("Start Research Text", "The text displayed for starting research of a research item.\n" +
			"Can be overridden for each research tree individually.\n" +
			"<name> displays the name of research item.", "")]
		[EditorEndFoldout]
		public ConsoleTextResearchItem startResearch = new ConsoleTextResearchItem("<username> started researching <name>.");

		[EditorFoldout("Cancel Research Text", "The text displayed for canceling research of a research item.\n" +
			"Can be overridden for each research tree individually.\n" +
			"<name> displays the name of research item.", "")]
		[EditorEndFoldout]
		public ConsoleTextResearchItem cancelResearch = new ConsoleTextResearchItem("<username> canceled researching <name>.");

		[EditorFoldout("Finish Research Text", "The text displayed for finishing research of a research item.\n" +
			"Can be overridden for each research tree individually.\n" +
			"<name> displays the name of research item.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextResearchItem finishResearch = new ConsoleTextResearchItem("<username> finished researching <name>.");


		// player group
		[EditorHelp("Display Player Group", "Player group texts will be added to the console.", "")]
		[EditorFoldout("Player Group Texts", "Define if and what texts will be added for player group related things.", "")]
		public bool displayPlayerGroup = true;

		[EditorFoldout("Join Group Text", "The text displayed for joining the player group.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextCombatant joinGroup = new ConsoleTextCombatant("<name> joins the group.");

		[EditorFoldout("Leave Group Text", "The text displayed for leaving the player group.\n" +
			"Can be overridden for each combatant individually.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextCombatant leaveGroup = new ConsoleTextCombatant("<name> leaves the group.");


		// class
		[EditorHelp("Display Class", "Class texts will be added to the console.\n" +
			"Only used for player combatants.", "")]
		[EditorFoldout("Class Texts", "Define if and what texts will be added for class related things.\n" +
			"Only used for player combatants.", "")]
		public bool displayClass = true;

		[EditorFoldout("Class Added Text", "The text displayed for adding a class to a combatant.\n" +
			"Can be overridden for each class individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextClass classAdded = new ConsoleTextClass("<classname> added to <name>.");

		[EditorFoldout("Class Removed Text", "The text displayed for removing a class from a combatant.\n" +
			"Can be overridden for each class individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextClass classRemoved = new ConsoleTextClass("<classname> removed from <name>.");

		[EditorFoldout("Class Slot Added Text", "The text displayed for adding a class slot to a combatant.\n" +
			"Can be overridden for each class individually.", "")]
		[EditorEndFoldout]
		public ConsoleTextClassSlot classSlotAdded = new ConsoleTextClassSlot("<slotname> added to <name>.");

		[EditorFoldout("Class Slot Removed Text", "The text displayed for removing a class slot from a combatant.\n" +
			"Can be overridden for each class individually.", "")]
		[EditorEndFoldout(2)]
		public ConsoleTextClassSlot classSlotRemoved = new ConsoleTextClassSlot("<slotname> removed from <name>.");

		public ConsoleSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Console Settings"; }
		}
	}
}
