
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class ORKUISettings : BaseSettings
	{
		// preview settings
		[EditorFoldout("ORK UI Settings", "Define UI settings for ORK Framework.", "",
			"Tooltip Settings", "These settings handle displaying tooltips.\n" +
			"Many tooltips can be enabled/disabled for individual parts, e.g. in menu screens.\n" +
			"Tooltips can be displayed using 'Tooltip' HUDs.", "")]
		[EditorEndFoldout]
		public ORKTooltipSettings tooltip = new ORKTooltipSettings();


		// drag and drop
		// drop on
		[EditorHelp("Drop Give Player", "Dropping an item on members of the player group can give it to the combatant.", "")]
		[EditorFoldout("Drag/Drop Settings", "Define drag/drop interaction settings.", "")]
		[EditorTitleLabel("Raycast Settings")]
		[EditorSeparator]
		public bool dropGivePlayer = true;

		[EditorHelp("Drop Give Allies", "Dropping an item on allies of the player group can give it to the combatant.", "")]
		public bool dropGiveAllies = true;

		[EditorHelp("Drop Give Enemies", "Dropping an item on enemies of the player group can give it to the combatant.", "")]
		[EditorEndFoldout]
		public bool dropGiveEnemies = true;


		// hud settings
		[EditorHelp("HUD Effect Time", "The time in seconds used to display status effects in HUDs.\n" +
			"This is used to switch between the current status effects of a combatant, if only one effect " +
			"is displayed by a HUD, or if there are not enough cells to display all effects.", "")]
		[EditorFoldout("HUD Settings", "Base settings regarding HUDs.", "")]
		public float hudSETime = 2;

		[EditorHelp("HUD Check Time", "The time in seconds used to check individual combatant HUDs.\n" +
			"The check will review faction and enemy state of the combatants and change the HUD accordingly.", "")]
		public float hudCheckTime = 1;

		[EditorHelp("Use Turn Flash", "The HUD of a combatant who start's his turn will flash.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Turn Flash HUD")]
		public bool useTurnFlash = false;

		[EditorCondition("useTurnFlash", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FadeColorSettings hudTurnFlash;

		[EditorFoldout("Default Status Value UI", "The default UI setup used by all status values that don't have any other UI setup.", "")]
		[EditorEndFoldout]
		public UIStatusValueSettings defaultStatusValueUI = new UIStatusValueSettings();

		[EditorFoldout("Default Status Effect UI", "The default UI setup used by all status effects that don't have any other UI setup.", "")]
		[EditorEndFoldout]
		public UIStatusEffectSettings defaultStatusEffectUI = new UIStatusEffectSettings();

		[EditorFoldout("Default Research Item UI", "The default UI setup used by all research items that don't have any other UI setup.", "")]
		[EditorEndFoldout(2)]
		public UIResearchItemSettings defaultResearchItemUI = new UIResearchItemSettings();


		// buttons
		[EditorFoldout("Default Buttons", "Default button settings, the buttons are used system wide.", "")]
		[EditorEndFoldout]
		public DefaultButtonSettings defaultButtons = new DefaultButtonSettings();


		// prefab view
		[EditorFoldout("Prefab View Settings", "These settings define how portraits using prefabs handled.", "")]
		[EditorEndFoldout(2)]
		public PrefabViewSettings prefabView = new PrefabViewSettings();

		public ORKUISettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("defaultEffectUI"))
			{
				DataObject effectData = data.GetFile("defaultEffectUI");
				this.defaultStatusEffectUI.SetData(effectData);
				this.defaultStatusEffectUI.settings.SetData(effectData.GetFile("settings"));

				DataObject[] keyData = effectData.GetFileArray("keySettings");
				for(int i = 0; i < keyData.Length; i++)
				{
					this.defaultStatusEffectUI.keySettings[i].settings.SetData(keyData[i].GetFile("settings"));
				}
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Menu Settings"; }
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public virtual bool CanGive(Combatant combatant)
		{
			if(combatant != null &&
				ORK.Game.ActiveGroup.Leader != null)
			{
				if(this.dropGivePlayer &&
					combatant.Group.IsPlayerGroup())
				{
					return true;
				}
				else if(combatant.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					return this.dropGiveEnemies;
				}
				else
				{
					return this.dropGiveAllies;
				}
			}
			return false;
		}
	}
}
