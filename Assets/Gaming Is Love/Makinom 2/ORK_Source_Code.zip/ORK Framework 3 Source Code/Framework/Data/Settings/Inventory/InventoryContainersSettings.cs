﻿
using UnityEngine;
using GamingIsLove.ORKFramework.AI;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum SlotInventoryType { Disable, Enable, PlayerOnly }

	public class InventoryContainersSettings : GenericAssetListSettings<InventoryContainerAsset, InventoryContainerSetting>
	{
		[EditorHelp("Use Inventory Containers", "Define if slot-based inventory containers are used:\n" +
			"- Disable: Not used.\n" +
			"- Enable: Used by all combatants.\n" +
			"- Player Only: Used only by the player group.")]
		[EditorFoldout("Use Settings", "Optionally use a slot-based inventory containers.")]
		public SlotInventoryType type = SlotInventoryType.Disable;

		[EditorHelp("Slot Index Display", "Offset added to the index of the slot when displayed in the slot content ('<slotindex>').\n" +
			"The first slot has the index 0, e.g. if you want to start your slot index numbers at 1, set this setting to 1.", "")]
		[EditorEndFoldout]
		public int slotIndexDisplay = 0;


		// notifications
		[EditorFoldout("Notifications", "Optionally display notifications when free slots are running out.")]
		[EditorEndFoldout]
		public InventoryContainerNotifications notifications = new InventoryContainerNotifications();

		public InventoryContainersSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Inventory Containers"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual string FormatSlotIndex(int slotIndex)
		{
			return ORK.TextDisplaySettings.numberFormatting.FormatInt(slotIndex + this.slotIndexDisplay);
		}
	}
}
