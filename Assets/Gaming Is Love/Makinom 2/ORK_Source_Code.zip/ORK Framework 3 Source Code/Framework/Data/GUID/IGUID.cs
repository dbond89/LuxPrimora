﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface IGUID
	{
		string GUID
		{
			get;
			set;
		}
	}
}
