﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class EquipStatusValueSorter : IComparer<IInventoryShortcut>, IComparer<EquipShortcut>
	{
		private Combatant user;

		private StatusValueSetting statusValue;

		private bool invert = false;

		public EquipStatusValueSorter(Combatant user, StatusValueSetting statusValue, bool invert)
		{
			this.user = user;
			this.statusValue = statusValue;
			this.invert = invert;
		}

		public int Compare(IInventoryShortcut x, IInventoryShortcut y)
		{
			EquipShortcut equipX = x as EquipShortcut;
			EquipShortcut equipY = y as EquipShortcut;
			if(this.invert)
			{
				if(equipX == null &&
					equipY == null)
				{
					return y.GetName().CompareTo(x.GetName());
				}
				else if(equipX != null &&
					equipY == null)
				{
					return -1;
				}
				else if(equipX == null &&
					equipY != null)
				{
					return 1;
				}
				else
				{
					int result = equipY.GetStatusValueBonus(this.user, this.statusValue).CompareTo(
						equipX.GetStatusValueBonus(this.user, this.statusValue));
					if(result == 0)
					{
						return y.GetName().CompareTo(x.GetName());
					}
					return result;
				}
			}
			else
			{
				if(equipX == null &&
					equipY == null)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				else if(equipX != null &&
					equipY == null)
				{
					return -1;
				}
				else if(equipX == null &&
					equipY != null)
				{
					return 1;
				}
				else
				{
					int result = equipX.GetStatusValueBonus(this.user, this.statusValue).CompareTo(
						equipY.GetStatusValueBonus(this.user, this.statusValue));
					if(result == 0)
					{
						return x.GetName().CompareTo(y.GetName());
					}
					return result;
				}
			}
		}

		public int Compare(EquipShortcut x, EquipShortcut y)
		{
			if(this.invert)
			{
				int result = y.GetStatusValueBonus(this.user, this.statusValue).CompareTo(
					x.GetStatusValueBonus(this.user, this.statusValue));
				if(result == 0)
				{
					return y.GetName().CompareTo(x.GetName());
				}
				return result;
			}
			else
			{
				int result = x.GetStatusValueBonus(this.user, this.statusValue).CompareTo(
					y.GetStatusValueBonus(this.user, this.statusValue));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}
}
