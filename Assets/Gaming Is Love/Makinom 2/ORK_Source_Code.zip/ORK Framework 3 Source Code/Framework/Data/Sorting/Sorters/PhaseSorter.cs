
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class PhaseSorter : IComparer<KeyValuePair<FactionSetting, float>>
	{
		public int Compare(KeyValuePair<FactionSetting, float> x , KeyValuePair<FactionSetting, float> y)
		{
	        if(x.Value < y.Value)
			{
				return 1;
			}
			else if(x.Value > y.Value)
			{
				return -1;
			}
			else
			{
				return 0;
			}
	    } 
	}
}
