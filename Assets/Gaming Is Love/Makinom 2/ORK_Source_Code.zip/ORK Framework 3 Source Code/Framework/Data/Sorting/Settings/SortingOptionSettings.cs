﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class SortingOptionSettings : BaseData
	{
		[EditorFoldout("Change Sorting Key", "Select the input key used to change the sorting.", "")]
		[EditorEndFoldout]
		public AudioInputSelection changeSortingKey = new AudioInputSelection();

		[EditorHelp("Remember Sorting", "Remember the current sorting option.", "")]
		public bool rememberSorting = false;

		[EditorArray("Add Sort Option", "Adds a sort option.", "",
			"Remove", "Removes this sort option.", "",
			isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Sort Option", "Define the sorting that will be used by this sort option.", ""
		})]
		public SortOption[] sortOption = new SortOption[]
		{
			new SortOption()
		};

		public SortingOptionSettings()
		{

		}

		public bool ChangeSorting(int inputID, ref int currentSorting)
		{
			if(this.sortOption.Length > 0 &&
				this.changeSortingKey.GetButton(inputID))
			{
				currentSorting++;
				if(currentSorting >= this.sortOption.Length)
				{
					currentSorting = 0;
				}
				return true;
			}
			return false;
		}
	}
}
