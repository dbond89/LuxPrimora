﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CombatantStatusValueSorter : IComparer<Combatant>
	{
		private StatusValueSetting statusValue;

		private bool invert = false;

		public CombatantStatusValueSorter(StatusValueSetting statusValue, bool invert)
		{
			this.statusValue = statusValue;
			this.invert = invert;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(this.invert)
			{
				int result = y.Status.Get(this.statusValue).GetValue().CompareTo(
					x.Status.Get(this.statusValue).GetValue());
				if(result == 0)
				{
					return y.GetName().CompareTo(x.GetName());
				}
				return result;
			}
			else
			{
				int result = x.Status.Get(this.statusValue).GetValue().CompareTo(
					y.Status.Get(this.statusValue).GetValue());
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}
}
