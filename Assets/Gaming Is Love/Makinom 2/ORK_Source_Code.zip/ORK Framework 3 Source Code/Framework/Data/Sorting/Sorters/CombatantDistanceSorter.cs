﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CombatantDistanceSorter : IComparer<Combatant>
	{
		private Combatant user;

		private bool ignoreHeightDistance = false;

		private bool ignoreCombatantRadius = false;

		private bool inverse = false;

		public CombatantDistanceSorter(Combatant user, bool ignoreHeightDistance, bool ignoreCombatantRadius, bool inverse)
		{
			this.user = user;
			this.ignoreHeightDistance = ignoreHeightDistance;
			this.ignoreCombatantRadius = ignoreCombatantRadius;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				if(x.GameObject == null &&
					y.GameObject == null)
				{
					return 0;
				}
				else if(x.GameObject != null &&
					y.GameObject == null)
				{
					return 1;
				}
				else if(x.GameObject == null &&
					y.GameObject != null)
				{
					return -1;
				}
				else
				{
					return this.user.Object.DistanceTo(y, this.ignoreHeightDistance,
							this.ignoreCombatantRadius, Maki.GameSettings.horizontalPlane).CompareTo(
						this.user.Object.DistanceTo(x, this.ignoreHeightDistance,
							this.ignoreCombatantRadius, Maki.GameSettings.horizontalPlane));
				}
			}
			else
			{
				if(x.GameObject == null &&
					y.GameObject == null)
				{
					return 0;
				}
				else if(x.GameObject != null &&
					y.GameObject == null)
				{
					return -1;
				}
				else if(x.GameObject == null &&
					y.GameObject != null)
				{
					return 1;
				}
				else
				{
					return this.user.Object.DistanceTo(x, this.ignoreHeightDistance,
							this.ignoreCombatantRadius, Maki.GameSettings.horizontalPlane).CompareTo(
						this.user.Object.DistanceTo(y, this.ignoreHeightDistance,
							this.ignoreCombatantRadius, Maki.GameSettings.horizontalPlane));
				}
			}
		}
	}
}
