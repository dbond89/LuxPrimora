
using GamingIsLove.ORKFramework;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Camera Control/Top Down Border Camera")]
	public class TopDownBorderCamera : BaseCameraControl, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public TopDownBorderCameraSettings settings = new TopDownBorderCameraSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// in-game
		protected Camera cameraComponent;

		protected bool initialized = false;

		protected float originalRotation = 0;

		protected float inputRotation = 0;

		protected Vector3 inputPanning = Vector3.zero;

		protected Vector3 panningStartPosition = Vector3.zero;

		protected bool dragPanningMousePCInputBlocked = false;

		protected float dragPanningStartTime = -1;

		protected float dragPanningLastInputTime = -1;

		protected Vector3 dragPanningLastAdd = Vector3.zero;

		protected Vector3 dragPanningLastVelocity = Vector3.zero;

		protected Vector2 inputZoom = Vector2.zero;

		protected bool firstUpdate = true;

		protected int lastIndex = -1;

		protected float lastTargetRotation = 0;

		protected float lastTargetDistance = 0;


		// static
		public static List<CameraBorder> CameraBorders = new List<CameraBorder>();

		public override bool UseUnscaledTime
		{
			get { return this.settings.useUnscaledTime; }
		}

		protected virtual void Start()
		{
			this.cameraComponent = this.GetComponentInParent<Camera>();
			if(this.cameraComponent == null)
			{
				this.cameraComponent = this.GetComponentInChildren<Camera>();
			}
			this.originalRotation = this.settings.rotation;

			this.ResetZoom();
			this.lastTargetDistance = this.settings.height;

			if(TopDownBorderCamera.CameraBorders != null)
			{
				int index = this.ClosestBorderIndex(this.settings.childObject.GetChild(this.CameraTarget));
				if(index >= 0 &&
					TopDownBorderCamera.CameraBorders[index].settings.setRotation)
				{
					this.settings.rotation = TopDownBorderCamera.CameraBorders[index].settings.rotation;
				}
				this.lastTargetRotation = this.settings.rotation;
				this.lastIndex = index;
			}

			if(this.settings.rememberRotation &&
				this.IsUseable(this.settings.useRotationIn) &&
				(this.settings.rememberRotationBattle || !ORK.Control.InBattle))
			{
				ORK.GameControls.cameraControl.topDownBorderControl.GetStoredRotation(
					ref this.settings.rotation, ref this.inputRotation, ref this.lastTargetRotation);
			}
			if(this.settings.rememberPanning &&
				this.IsUseable(this.settings.usePanningIn) &&
				(this.settings.rememberPanningBattle || !ORK.Control.InBattle))
			{
				ORK.GameControls.cameraControl.topDownBorderControl.GetStoredPanning(
					ref this.inputPanning);
			}
			if(this.settings.rememberZoom &&
				this.IsUseable(this.settings.useZoomingIn) &&
				(this.settings.rememberZoomBattle || !ORK.Control.InBattle))
			{
				ORK.GameControls.cameraControl.topDownBorderControl.GetStoredZoom(
					ref this.inputZoom, ref this.lastTargetDistance);
			}
			this.initialized = true;
		}

		protected virtual void OnDisable()
		{
			if(this.initialized)
			{
				if(this.settings.rememberRotation &&
					this.IsUseable(this.settings.useRotationIn) &&
					(this.settings.rememberRotationBattle || !ORK.Control.InBattle))
				{
					ORK.GameControls.cameraControl.topDownBorderControl.StoreRotation(
						this.settings.rotation, this.inputRotation, this.lastTargetRotation);
				}
				if(this.settings.rememberPanning &&
					this.IsUseable(this.settings.usePanningIn) &&
					(this.settings.rememberPanningBattle || !ORK.Control.InBattle))
				{
					ORK.GameControls.cameraControl.topDownBorderControl.StorePanning(
						this.inputPanning);
				}
				if(this.settings.rememberZoom &&
					this.IsUseable(this.settings.useZoomingIn) &&
					(this.settings.rememberZoomBattle || !ORK.Control.InBattle))
				{
					ORK.GameControls.cameraControl.topDownBorderControl.StoreZoom(
						this.inputZoom, this.lastTargetDistance);
				}
			}
		}

		public override void CameraTargetChanged(GameObject oldTarget, GameObject newTarget)
		{
			if(this.settings.cameraTargetChangeResetRotation)
			{
				this.ResetRotation();
			}
			if(this.settings.cameraTargetChangeResetPanning)
			{
				this.ResetPanning();
			}
			if(this.settings.cameraTargetChangeResetZoom)
			{
				this.ResetZoom();
			}
		}

		public virtual void ResetRotation()
		{
			this.inputRotation = 0;
		}

		public virtual void ResetPanning()
		{
			this.inputPanning = Vector3.zero;
			this.panningStartPosition = Vector3.zero;
			this.dragPanningLastAdd = Vector3.zero;
		}

		public virtual void ResetZoom()
		{
			this.inputZoom = new Vector2(this.settings.distance, this.settings.height);
		}

		public virtual void ResetDistance()
		{
			this.inputZoom.x = this.settings.distance;
		}

		public virtual void ResetHeight()
		{
			this.inputZoom.y = this.settings.height;
		}

		protected virtual bool IsPanning()
		{
			return this.inputPanning.sqrMagnitude > Mathf.Epsilon;
		}

		protected virtual int ClosestBorderIndex(GameObject targetObject)
		{
			if(TopDownBorderCamera.CameraBorders != null &&
				TopDownBorderCamera.CameraBorders.Count > 0)
			{
				if(TopDownBorderCamera.CameraBorders.Count == 1)
				{
					return 0;
				}
				else
				{
					if(targetObject != null)
					{
						int index = -1;
						float distance = Mathf.Infinity;
						for(int i = 0; i < TopDownBorderCamera.CameraBorders.Count; i++)
						{
							if(TopDownBorderCamera.CameraBorders[i] != null &&
								TopDownBorderCamera.CameraBorders[i].enabled)
							{
								float tmp = TopDownBorderCamera.CameraBorders[i].DistanceToCameraTarget(targetObject.transform.position);
								if(tmp < distance)
								{
									distance = tmp;
									index = i;
								}
							}
						}
						return index;
					}
				}
			}
			return -1;
		}

		protected virtual bool IsUseable(UseableIn useable)
		{
			return UseableIn.Both == useable ||
				(UseableIn.Field == useable && !ORK.Control.InBattle) ||
				(UseableIn.Battle == useable && ORK.Control.InBattle);
		}

		protected virtual void CheckRotationInput()
		{
			if(this.inputRotation < -36000)
			{
				int change = (this.inputRotation > -36000 ?
					1 : (int)(-this.inputRotation / 36000)) * 36000;
				this.inputRotation += change;
				this.lastTargetRotation += change;
			}
			else if(this.inputRotation >= 36000)
			{
				int change = ((int)(this.inputRotation / 36000)) * 36000;
				this.inputRotation -= change;
				this.lastTargetRotation -= change;
			}
		}

		protected virtual void LateUpdate()
		{
			GameObject targetObject = this.settings.childObject.GetChild(this.CameraTarget);
			if(targetObject != null)
			{
				Vector3 targetPosition = targetObject.transform.position;

				int index = this.ClosestBorderIndex(targetObject);
				if(index != this.lastIndex)
				{
					this.firstUpdate = true;
					if(index >= 0 &&
						TopDownBorderCamera.CameraBorders[index].settings.setRotation)
					{
						this.settings.rotation = TopDownBorderCamera.CameraBorders[index].settings.rotation;
						this.inputRotation = 0;
					}
					else
					{
						this.settings.rotation = this.originalRotation;
					}
				}
				this.lastIndex = index;

				// panning
				if(this.IsUseable(this.settings.usePanningIn) &&
					(!this.settings.cameraTargetChangeBlockPanning ||
						!this.IsCameraTargetTransition) &&
					(TopDownBorderCamera.CameraBorders == null ||
						index < 0 ||
						!TopDownBorderCamera.CameraBorders[index].settings.blockPanning))
				{
					bool isPanning = this.IsPanning();
					if(InputKey.GetButton(this.settings.centerPanningKey.StoredAsset))
					{
						if(this.settings.centerPanningKeyTransition)
						{
							this.ResetCurrentCameraTarget(null);
						}
						this.ResetPanning();
					}
					else
					{
						Vector3 forward = this.transform.TransformDirection(Vector3.forward);
						forward.y = 0;
						forward = forward.normalized;
						Vector3 right = new Vector3(forward.z, 0, -forward.x);

						this.inputPanning += (InputKey.GetAxis(this.settings.horizontalPanningKey) * right +
								InputKey.GetAxis(this.settings.verticalPanningKey) * forward) *
							this.settings.panningSpeed.GetSpeed() * this.DeltaTime;

						// edge panning
						if(this.IsUseable(this.settings.useScreenEdgePanningIn) &&
							(!this.settings.screenEdgePanningUIBlock ||
								!Maki.UI.IsCursorOver))
						{
							Vector2 edgeInput = Vector2.zero;
							Vector4 edgeDistance = this.settings.screenEdgeDistance;
							if(ValueSetter.Percent == this.settings.screenEdgeValueSetter)
							{
								edgeDistance.x = (Maki.UISystem.defaultScreen.x * edgeDistance.x) / 100.0f;
								edgeDistance.z = (Maki.UISystem.defaultScreen.x * edgeDistance.z) / 100.0f;
								edgeDistance.y = (Maki.UISystem.defaultScreen.y * edgeDistance.y) / 100.0f;
								edgeDistance.w = (Maki.UISystem.defaultScreen.y * edgeDistance.w) / 100.0f;
							}
							if(Maki.Control.MousePosition.x < edgeDistance.x)
							{
								edgeInput.x -= Mathf.Min(edgeDistance.x,
									edgeDistance.x - Maki.Control.MousePosition.x) / edgeDistance.x;
							}
							else if(Maki.Control.MousePosition.x > (Maki.UISystem.defaultScreen.x - edgeDistance.z))
							{
								edgeInput.x += Mathf.Min(edgeDistance.z,
									edgeDistance.z - (Maki.UISystem.defaultScreen.x - Maki.Control.MousePosition.x)) / edgeDistance.z;
							}
							if(Maki.Control.MousePosition.y < edgeDistance.y)
							{
								edgeInput.y += Mathf.Min(edgeDistance.y,
									edgeDistance.y - Maki.Control.MousePosition.y) / edgeDistance.y;
							}
							else if(Maki.Control.MousePosition.y > (Maki.UISystem.defaultScreen.y - edgeDistance.w))
							{
								edgeInput.y -= Mathf.Min(edgeDistance.w,
									edgeDistance.w - (Maki.UISystem.defaultScreen.y - Maki.Control.MousePosition.y)) / edgeDistance.w;
							}
							this.inputPanning += (edgeInput.x * right + edgeInput.y * forward) *
								this.settings.screenEdgePanningSpeed.GetSpeed() * this.DeltaTime;
						}
						// drag panning
						if(this.IsUseable(this.settings.useDragPanningIn) &&
							(!this.settings.dragPanningUIBlock ||
								!Maki.UI.IsCursorOver) &&
							this.settings.dragPanningMouseTouch.Active)
						{
							Vector3 add = Vector3.zero;
							if(this.settings.dragPanningMouseTouch.Interacted(ref add))
							{
								this.dragPanningLastInputTime = Time.realtimeSinceStartup + 0.1f;
								if(this.settings.dragPanningBlockMouseInput)
								{
									if(this.dragPanningStartTime < 0)
									{
										this.dragPanningStartTime = Time.realtimeSinceStartup + this.settings.dragPanningNoBlockMITimeout;
									}
									if(this.dragPanningStartTime <= Time.realtimeSinceStartup)
									{
										this.dragPanningMousePCInputBlocked = true;
										Maki.Control.BlockingMouseTouch = this.settings.dragPanningMouseTouch;
									}
								}
								this.dragPanningLastAdd = this.settings.dragPanningMouseTouch.GetLastChange();
								this.inputPanning += ((this.settings.dragPanningInvertX ? this.dragPanningLastAdd.x * right : -this.dragPanningLastAdd.x * right) +
										(this.settings.dragPanningInvertY ? this.dragPanningLastAdd.y * forward : -this.dragPanningLastAdd.y * forward)) *
									this.settings.dragPanningSpeed.GetSpeed() * this.DeltaTime;
							}
							else if(this.settings.dragPanningMouseTouch.Released())
							{
								if(this.dragPanningStartTime >= 0)
								{
									this.dragPanningStartTime = -1;
									if(this.dragPanningMousePCInputBlocked)
									{
										this.dragPanningMousePCInputBlocked = false;
										Maki.Control.BlockingMouseTouch = null;
									}
								}
								if(this.dragPanningLastInputTime >= 0)
								{
									if(this.dragPanningLastInputTime <= Time.realtimeSinceStartup)
									{
										this.dragPanningLastAdd = Vector3.zero;
									}
									this.dragPanningLastInputTime = -1;
								}
								if(this.dragPanningLastAdd != Vector3.zero &&
									this.settings.dragPanningReleaseSmoothing > 0)
								{
									this.dragPanningLastAdd = Vector3.SmoothDamp(this.dragPanningLastAdd, Vector3.zero,
										ref this.dragPanningLastVelocity, this.settings.dragPanningReleaseSmoothing,
										Mathf.Infinity, this.DeltaTime);
									this.inputPanning += ((this.settings.dragPanningInvertX ? this.dragPanningLastAdd.x * right : -this.dragPanningLastAdd.x * right) +
											(this.settings.dragPanningInvertY ? this.dragPanningLastAdd.y * forward : -this.dragPanningLastAdd.y * forward)) *
										this.settings.dragPanningSpeed.GetSpeed() * this.DeltaTime;
								}
							}
						}

						if(this.settings.panningIgnorePlayerMove &&
							this.IsPanning())
						{
							if(isPanning)
							{
								targetPosition = this.panningStartPosition;
							}
							else
							{
								isPanning = true;
								this.panningStartPosition = targetPosition;
							}
						}

						// limit panning
						if(this.settings.limitPanning)
						{
							if(ORK.Control.InBattle)
							{
								VectorHelper.LimitVector3(ref this.inputPanning,
									-this.settings.panningDistanceLimitBattle, this.settings.panningDistanceLimitBattle);
							}
							else
							{
								VectorHelper.LimitVector3(ref this.inputPanning,
									-this.settings.panningDistanceLimitField, this.settings.panningDistanceLimitField);
							}
						}
						if(this.inputPanning.sqrMagnitude > 0.1 &&
							TopDownBorderCamera.CameraBorders != null && index >= 0)
						{
							this.inputPanning += targetPosition;
							TopDownBorderCamera.CameraBorders[index].UpdatePosition(
								this.settings.borderCameraEdge ? this.cameraComponent : null, ref this.inputPanning,
								this.settings.positionPadding, this.settings.horizontalPlane);
							this.inputPanning -= targetPosition;
						}
						targetPosition.x += this.inputPanning.x;
						if(HorizontalPlaneType.XZ == this.settings.horizontalPlane)
						{
							targetPosition.z += this.inputPanning.z;
						}
						else if(HorizontalPlaneType.XY == this.settings.horizontalPlane)
						{
							targetPosition.y += this.inputPanning.z;
						}
					}
				}

				// rotation input
				if(this.IsUseable(this.settings.useRotationIn) &&
					(!this.settings.cameraTargetChangeBlockRotation ||
						!this.IsCameraTargetTransition) &&
					(TopDownBorderCamera.CameraBorders == null ||
						index < 0 ||
						(!TopDownBorderCamera.CameraBorders[index].settings.setRotation &&
							!TopDownBorderCamera.CameraBorders[index].settings.blockRotationInput)))
				{
					if(InputKey.GetButton(this.settings.rotationResetInputKey.StoredAsset))
					{
						this.ResetRotation();
					}
					else
					{
						float tmpInput = this.settings.rotationAxis.GetAxis(false);
						if(tmpInput != 0)
						{
							this.inputRotation += tmpInput *
								(this.settings.rotateDeltaTime ?
									this.settings.rotationInputChange * this.DeltaTime :
									this.settings.rotationInputChange);
							this.CheckRotationInput();
						}

						if(this.settings.rotationMouseTouch.Active)
						{
							Vector3 add = Vector3.zero;
							if(this.settings.rotationMouseTouch.Interacted(ref add))
							{
								add = this.settings.rotationMouseTouch.GetLastChange();
								this.inputRotation += add.x * this.settings.rotationFactor;
								this.CheckRotationInput();
							}
						}
					}
				}
				// rotation damping
				float targetRotation = this.settings.rotation + this.inputRotation;
				if(this.settings.rotationDamping > 0 &&
					(this.settings.initialDamping || !this.firstUpdate))
				{
					targetRotation = Mathf.Lerp(this.lastTargetRotation, targetRotation,
						this.settings.rotationDamping * this.DeltaTime);
				}

				// zooming
				if(this.IsUseable(this.settings.useZoomingIn) &&
					(!this.settings.zoomUIBlock ||
						!Maki.UI.IsCursorOver) &&
					(!this.settings.cameraTargetChangeBlockZoom ||
						!this.IsCameraTargetTransition) &&
					(TopDownBorderCamera.CameraBorders == null ||
						index < 0 ||
						!TopDownBorderCamera.CameraBorders[index].settings.blockZooming))
				{
					// zoom input
					if(InputKey.GetButton(this.settings.zoomResetInputKey.StoredAsset))
					{
						this.ResetZoom();
					}
					else
					{
						float tmpInput = this.settings.zoomAxis.GetAxis(false);
						if(tmpInput != 0)
						{
							this.inputZoom.x += tmpInput *
								(this.settings.zoomDeltaTime ?
									this.settings.zoomDistanceInputChange * this.DeltaTime :
									this.settings.zoomDistanceInputChange);
							this.inputZoom.y += tmpInput *
								(this.settings.zoomDeltaTime ?
									this.settings.zoomHeightInputChange * this.DeltaTime :
									this.settings.zoomHeightInputChange);
						}
					}
					// height input
					if(this.settings.useHeightInput)
					{
						if(InputKey.GetButton(this.settings.heightResetInputKey.StoredAsset))
						{
							this.ResetHeight();
						}
						else
						{
							float tmpInput = this.settings.heightAxis.GetAxis(false);
							if(tmpInput != 0)
							{
								this.inputZoom.y += tmpInput *
									(this.settings.heightDeltaTime ?
										this.settings.heightInputChange * this.DeltaTime :
										this.settings.heightInputChange);
							}
						}
					}
					// distance input
					if(this.settings.useDistanceInput)
					{
						if(InputKey.GetButton(this.settings.distanceResetInputKey.StoredAsset))
						{
							this.ResetDistance();
						}
						else
						{
							float tmpInput = this.settings.distanceAxis.GetAxis(false);
							if(tmpInput != 0)
							{
								this.inputZoom.x += tmpInput *
									(this.settings.distanceDeltaTime ?
										this.settings.distanceInputChange * this.DeltaTime :
										this.settings.distanceInputChange);
							}
						}
					}

					// limit zoom
					if(ORK.Control.InBattle)
					{
						ValueHelper.Limit(ref this.inputZoom.x,
							this.settings.zoomMinDistanceBattle, this.settings.zoomMaxDistanceBattle);
						ValueHelper.Limit(ref this.inputZoom.y,
							this.settings.zoomMinHeightBattle, this.settings.zoomMaxHeightBattle);
					}
					else
					{
						ValueHelper.Limit(ref this.inputZoom.x,
							this.settings.zoomMinDistanceField, this.settings.zoomMaxDistanceField);
						ValueHelper.Limit(ref this.inputZoom.y,
							this.settings.zoomMinHeightField, this.settings.zoomMaxHeightField);
					}
				}


				if(TopDownBorderCamera.CameraBorders != null && index >= 0)
				{
					TopDownBorderCamera.CameraBorders[index].UpdatePosition(
						this.settings.borderCameraEdge ? this.cameraComponent : null, ref targetPosition,
						this.settings.positionPadding, this.settings.horizontalPlane);
				}

				Vector3 lookTargetPosition = targetPosition;

				if(HorizontalPlaneType.XZ == this.settings.horizontalPlane)
				{
					// calculate the new height
					float targetHeight = targetPosition.y + this.inputZoom.y;
					if(this.settings.heightDamping > 0 &&
						(this.settings.initialDamping || !this.firstUpdate))
					{
						targetHeight = Mathf.Lerp(this.transform.position.y, targetHeight,
							this.settings.heightDamping * this.DeltaTime);
					}
					// calculate the new distance
					float targetDistance = this.inputZoom.x;
					if(this.settings.distanceDamping > 0 &&
						(this.settings.initialDamping || !this.firstUpdate))
					{
						targetDistance = Mathf.Lerp(this.lastTargetDistance, targetDistance,
							this.settings.distanceDamping * this.DeltaTime);
					}

					// update camera position
					this.lastTargetRotation = targetRotation;
					this.lastTargetDistance = targetDistance;
					targetPosition -= Quaternion.Euler(0, targetRotation, 0) * Vector3.forward * targetDistance;
					targetPosition.y = targetHeight;
				}
				else if(HorizontalPlaneType.XY == this.settings.horizontalPlane)
				{
					// calculate the new height
					float targetHeight = targetPosition.z - this.inputZoom.y;
					if(this.settings.heightDamping > 0 &&
						(this.settings.initialDamping || !this.firstUpdate))
					{
						targetHeight = Mathf.Lerp(this.transform.position.z, targetHeight,
							this.settings.heightDamping * this.DeltaTime);
					}
					// calculate the new distance
					float targetDistance = this.inputZoom.x;
					if(this.settings.distanceDamping > 0 &&
						(this.settings.initialDamping || !this.firstUpdate))
					{
						targetDistance = Mathf.Lerp(this.lastTargetDistance, targetDistance,
							this.settings.distanceDamping * this.DeltaTime);
					}

					// update camera position
					this.lastTargetRotation = targetRotation;
					this.lastTargetDistance = targetDistance;
					targetPosition -= Quaternion.Euler(0, 0, targetRotation) * Vector3.forward * targetDistance;
					targetPosition.z = targetHeight;
				}

				if(TopDownBorderCamera.CameraBorders != null && index >= 0)
				{
					TopDownBorderCamera.CameraBorders[index].UpdateCameraHeight(ref targetPosition,
						this.settings.horizontalPlane, this.IsUseable(this.settings.useZoomingIn));
				}

				if(this.settings.positionDamping > 0 &&
					(this.settings.initialDamping || !this.firstUpdate))
				{
					targetPosition = Vector3.Lerp(this.transform.position, targetPosition,
						this.settings.positionDamping * this.DeltaTime);
				}

				this.UpdatePosition(targetPosition,
					VectorHelper.LookAt(targetPosition, lookTargetPosition));

				this.firstUpdate = false;
			}
			else
			{
				this.firstUpdate = true;
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}
}
