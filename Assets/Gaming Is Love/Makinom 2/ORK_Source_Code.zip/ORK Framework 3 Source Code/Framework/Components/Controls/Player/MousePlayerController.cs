
using UnityEngine;
using UnityEngine.AI;
using System.Collections;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Player Control/Mouse Controller")]
	public class MousePlayerController : BasePlayerControl, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public MousePlayerControlSettings settings = new MousePlayerControlSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected Vector3 targetPosition = Vector3.zero;

		protected CharacterController controller;

		protected NavMeshAgent navMeshAgent;

		protected GameObject targetCursor;

		protected bool moveToTarget = false;

		protected Vector3 moveDirection = Vector3.zero;

		protected bool moveStopped = false;

		protected float moveSpeed = 0.0f;

		protected Combatant combatant = null;

		protected virtual void Start()
		{
			if(MouseControlMoveType.CharacterController == this.settings.mouseMoveType)
			{
				this.controller = this.GetComponent<CharacterController>();
			}
			else if(MouseControlMoveType.NavMeshAgent == this.settings.mouseMoveType)
			{
				this.navMeshAgent = this.GetComponent<NavMeshAgent>();

				if(this.navMeshAgent != null &&
					!this.navMeshAgent.isOnNavMesh)
				{
					this.navMeshAgent.enabled = false;
					this.navMeshAgent.enabled = true;
				}
			}
			this.combatant = ORKComponentHelper.GetCombatant(this.transform.root.gameObject);
		}

		protected virtual void Update()
		{
			if(this.combatant == null ||
				((ORK.GameControls.playerControl.moveDead || !this.combatant.Status.IsDead) &&
					!this.combatant.Status.Effects.StopMovement))
			{
				float runSpeed = ORK.GameControls.playerControl.runSpeed;
				if(ORK.GameControls.playerControl.useSpeed &&
					this.combatant != null)
				{
					runSpeed = this.combatant.Object.GetMoveSpeed(MoveSpeedType.Run);
				}

				// get click
				Vector3 point = Vector3.zero;
				if(this.settings.mouseTouch.Interacted(ref point))
				{
					bool doMove = true;
					Ray ray = Maki.Game.Camera.ScreenPointToRay(point);
					RaycastOutput hit;
					if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit,
						this.settings.raycastDistance, this.settings.layerMask))
					{
						if(RaycastColliderZone.CheckHit<NoClickMove>(hit.transform.gameObject) ||
							ORK.Game.Scene.WithinNoClickMove(hit.point))
						{
							this.ClearCursor();
							doMove = false;
						}
						else
						{
							IInteractionBehaviour[] interactions = hit.transform.gameObject.GetComponentsInChildren<IInteractionBehaviour>();
							for(int i = 0; i < interactions.Length; i++)
							{
								if(interactions[i] != null &&
									interactions[i].IsInteract)
								{
									doMove = false;
									break;
								}
							}

							if(doMove && this.combatant != null)
							{
								this.combatant.Object.Component.LastMoveTime = Time.time;
							}
						}
					}
					else
					{
						doMove = false;
					}

					if(doMove &&
						(MouseControlMoveType.CharacterController == this.settings.mouseMoveType ||
							MouseControlMoveType.CombatantMovementComponent == this.settings.mouseMoveType))
					{
						this.moveStopped = false;
						this.targetPosition = hit.point;
						this.moveToTarget = true;
						this.PlaceCursor();
					}
					else if(doMove &&
						MouseControlMoveType.NavMeshAgent == this.settings.mouseMoveType)
					{
						NavMeshHit navHit;
						if(NavMesh.SamplePosition(hit.point, out navHit,
							this.settings.navMeshSampleDistance, this.settings.navMeshSampleAreaMask))
						{
							this.moveStopped = false;
							this.targetPosition = navHit.position;
							this.moveToTarget = true;
							this.PlaceCursor();
							if(this.navMeshAgent != null &&
								this.navMeshAgent.isOnNavMesh)
							{
								this.moveSpeed = Mathf.Lerp(this.moveSpeed, runSpeed,
									ORK.GameControls.playerControl.speedSmoothing * ORK.Game.DeltaMovementTime);
								this.navMeshAgent.speed = this.moveSpeed;
								this.navMeshAgent.SetDestination(this.targetPosition);
								this.navMeshAgent.isStopped = false;
							}
						}
						else
						{
							this.moveToTarget = false;
						}
					}
					else
					{
						this.moveToTarget = false;
					}
				}

				// move to target
				if(this.moveToTarget)
				{
					if(MouseControlMoveType.CharacterController == this.settings.mouseMoveType)
					{
						if(this.controller != null)
						{
							if(this.settings.minimumMoveDistance >= VectorHelper.Distance(this.transform.position,
									this.targetPosition, this.settings.ignoreDistance) ||
								(this.settings.secureMove && this.combatant != null &&
									this.combatant.Object.Component.LastMoveTime + this.settings.secureTime < Time.time))
							{
								this.moveSpeed = 0;
								this.controller.Move(Vector3.zero);

								if(this.settings.autoRemoveCursorTarget &&
									this.targetCursor != null)
								{
									UnityWrapper.Destroy(this.targetCursor);
								}
							}
							else
							{
								float t = ORK.Game.DeltaMovementTime;
								this.SetDirection(this.targetPosition);
								this.moveSpeed = Mathf.Lerp(this.moveSpeed, runSpeed, ORK.GameControls.playerControl.speedSmoothing * t);
								Vector3 movement = this.moveDirection * this.moveSpeed + new Vector3(0, ORK.GameControls.playerControl.gravity, 0);
								movement *= t;
								this.controller.Move(movement);
							}
						}
					}
					else if(MouseControlMoveType.NavMeshAgent == this.settings.mouseMoveType)
					{
						if(this.navMeshAgent != null &&
							this.navMeshAgent.isOnNavMesh)
						{
							if(this.settings.minimumMoveDistance >= VectorHelper.Distance(this.transform.position,
									this.targetPosition, this.settings.ignoreDistance) ||
								(this.settings.secureMove && this.combatant != null &&
									this.combatant.Object.Component.LastMoveTime + this.settings.secureTime < Time.time))
							{
								this.moveSpeed = 0;
								this.navMeshAgent.isStopped = true;

								if(this.settings.autoRemoveCursorTarget && this.targetCursor != null)
								{
									UnityWrapper.Destroy(this.targetCursor);
								}
							}
							else
							{
								this.moveSpeed = Mathf.Lerp(this.moveSpeed, runSpeed,
									ORK.GameControls.playerControl.speedSmoothing * ORK.Game.DeltaMovementTime);
								this.navMeshAgent.speed = this.moveSpeed;
							}
						}
					}
					else if(MouseControlMoveType.CombatantMovementComponent == this.settings.mouseMoveType)
					{
						if(this.combatant != null &&
							this.combatant.Object.MovementComponent != null)
						{
							if(this.settings.minimumMoveDistance >= VectorHelper.Distance(this.transform.position,
									this.targetPosition, this.settings.ignoreDistance) ||
								(this.settings.secureMove && this.combatant != null &&
									this.combatant.Object.Component.LastMoveTime + this.settings.secureTime < Time.time))
							{
								this.moveSpeed = 0;
								this.combatant.Object.MovementComponent.Stop();

								if(this.settings.autoRemoveCursorTarget && this.targetCursor != null)
								{
									UnityWrapper.Destroy(this.targetCursor);
								}
							}
							else
							{
								this.moveSpeed = Mathf.Lerp(this.moveSpeed, runSpeed,
									ORK.GameControls.playerControl.speedSmoothing * ORK.Game.DeltaMovementTime);
								this.combatant.Object.MovementComponent.MoveTo(ref this.targetPosition, this.moveSpeed);
							}
						}
					}
				}
			}
			else
			{
				if(this.settings.autoRemoveCursor && this.targetCursor != null)
				{
					UnityWrapper.Destroy(this.targetCursor);
				}

				if(this.settings.autoStopMove && !this.moveStopped)
				{
					this.moveSpeed = 0;
					this.moveStopped = true;
					this.moveToTarget = false;

					if(MouseControlMoveType.CharacterController == this.settings.mouseMoveType)
					{
						if(this.controller != null)
						{
							this.controller.Move(Vector3.zero);
						}
					}
					else if(MouseControlMoveType.NavMeshAgent == this.settings.mouseMoveType)
					{
						if(this.navMeshAgent != null &&
							this.navMeshAgent.isOnNavMesh)
						{
							this.navMeshAgent.isStopped = true;
						}
					}
					else if(MouseControlMoveType.CombatantMovementComponent == this.settings.mouseMoveType)
					{
						if(this.combatant != null &&
							this.combatant.Object.MovementComponent != null)
						{
							this.combatant.Object.MovementComponent.Stop();
						}
					}
				}
			}
		}

		protected virtual void SetDirection(Vector3 pos)
		{
			pos.y = this.transform.position.y;
			this.transform.LookAt(pos);
			this.moveDirection = this.transform.TransformDirection(Vector3.forward);
		}

		protected virtual void OnDisable()
		{
			if(this.settings.autoRemoveCursor && this.targetCursor != null)
			{
				UnityWrapper.Destroy(this.targetCursor);
			}
			this.settings.mouseTouch.Clear();

			if(this.settings.autoStopMove)
			{
				this.moveSpeed = 0;
				this.moveStopped = true;
				this.moveToTarget = false;
			}
			if(MouseControlMoveType.CharacterController == this.settings.mouseMoveType)
			{
				if(this.controller != null)
				{
					this.controller.Move(Vector3.zero);
				}
			}
			else if(MouseControlMoveType.NavMeshAgent == this.settings.mouseMoveType)
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					this.navMeshAgent.isStopped = true;
				}
			}
			else if(MouseControlMoveType.CombatantMovementComponent == this.settings.mouseMoveType)
			{
				if(this.combatant != null &&
					this.combatant.Object.MovementComponent != null)
				{
					this.combatant.Object.MovementComponent.Stop();
				}
			}
		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public virtual void PlaceCursor()
		{
			GameObject prefab = this.settings.cursorObject.StoredAsset;
			if(prefab != null)
			{
				if(this.settings.cursorRespawn && this.targetCursor != null)
				{
					UnityWrapper.Destroy(this.targetCursor);
					this.targetCursor = UnityWrapper.Instantiate(prefab,
						this.targetPosition + this.settings.cursorOffset, prefab.transform.rotation);
				}
				else if(this.targetCursor == null)
				{
					this.targetCursor = UnityWrapper.Instantiate(prefab,
						this.targetPosition + this.settings.cursorOffset, prefab.transform.rotation);
				}
				this.targetCursor.transform.position = this.targetPosition + this.settings.cursorOffset;
			}
		}

		public virtual void ClearCursor()
		{
			if(this.targetCursor != null)
			{
				UnityWrapper.Destroy(this.targetCursor);
			}
			this.moveSpeed = 0;
			this.moveStopped = true;
			this.moveToTarget = false;
			if(this.controller != null)
			{
				this.controller.Move(Vector3.zero);
			}
		}

		public override void MoveToInteractionStarted(IInteractionBehaviour interaction)
		{
			this.ClearCursor();
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}
}
