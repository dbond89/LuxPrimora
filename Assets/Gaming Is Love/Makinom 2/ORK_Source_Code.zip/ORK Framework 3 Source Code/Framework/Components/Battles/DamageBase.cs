
using GamingIsLove.ORKFramework;
using UnityEngine;
using System.Collections;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	public abstract class DamageBase : MonoBehaviour
	{
		// ingame
		protected Combatant combatant;

		protected virtual void OnEnable()
		{
			if(this.combatant != null)
			{
				this.StartCoroutine(this.ReInit());
			}
		}

		protected virtual void Start()
		{
			this.Init();
		}

		protected virtual IEnumerator ReInit()
		{
			yield return null;
			this.Init();
		}

		protected virtual void Init()
		{
			this.combatant = ORKComponentHelper.GetCombatant(this.transform.root.gameObject);
		}

		public virtual Combatant Combatant
		{
			get { return this.combatant; }
			set { this.combatant = value; }
		}
	}
}
