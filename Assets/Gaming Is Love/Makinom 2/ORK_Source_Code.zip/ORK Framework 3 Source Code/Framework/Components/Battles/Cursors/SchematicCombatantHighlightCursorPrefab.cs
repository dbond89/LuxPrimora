﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Combatant Highlight: Schematic")]
	public class SchematicCombatantHighlightCursorPrefab : MonoBehaviour, ICombatantHighlightCursorPrefab
	{
		[Tooltip("Select the schematic used when starting the highlight (spawning/enabling the prefab).\n" +
			"The user (combatant) is available as 'Machine Object' and 'Starting Object' of the schematic.\n" +
			"The game object of the cursor is available as local selected data via the data key 'cursor'.")]
		public MakinomSchematicAsset startSchematicAsset;

		[Tooltip("Select the schematic used when stopping the highlight (destroying/disabling the prefab).\n" +
			"The user (combatant) is available as 'Machine Object' and 'Starting Object' of the schematic.\n" +
			"The game object of the cursor is available as local selected data via the data key 'cursor'.")]
		public MakinomSchematicAsset stopSchematicAsset;


		// in-game
		protected Combatant combatant;

		public virtual void StartSelection(Combatant combatant)
		{
			this.combatant = combatant;

			if(this.startSchematicAsset != null)
			{
				Schematic.Play(this.startSchematicAsset, this, null, this.combatant, this.combatant, false, null,
					SelectedDataHelper.CreateSelectedData("cursor", this.gameObject));
			}
		}

		public virtual void StopSelection()
		{
			if(this.stopSchematicAsset != null)
			{
				Schematic.Play(this.stopSchematicAsset, this, null, this.combatant, this.combatant, false, null,
					SelectedDataHelper.CreateSelectedData("cursor", this.gameObject));
			}

			this.combatant = null;
		}
	}
}
