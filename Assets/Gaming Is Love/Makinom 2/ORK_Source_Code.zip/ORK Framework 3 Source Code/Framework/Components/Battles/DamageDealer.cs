
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	public enum DamageDealerType { TriggerEnter, TriggerExit, TriggerStay, CollisionEnter, CollisionExit, CollisionStay, Custom };

	[AddComponentMenu("ORK Framework/Battle/Damage Dealer")]
	public class DamageDealer : DamageBase, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected BaseAction action = null;

		protected bool damageActive = false;

		protected Dictionary<Combatant, float> blocked = new Dictionary<Combatant, float>();

		protected Dictionary<Combatant, float> damageBlocked = new Dictionary<Combatant, float>();

		protected Dictionary<IDamageZone, float> zoneBlocked = new Dictionary<IDamageZone, float>();

		protected Dictionary<IDamageZone, float> zoneDamageBlocked = new Dictionary<IDamageZone, float>();

		protected AudioClip audioClip = null;

		protected PlayAudioSettings audioSettings;

		protected bool doExpand = false;

		protected float autoDeactivateAfter = -1;


		// prefab
		protected GameObject prefab = null;

		protected bool mountPrefab = false;

		protected float destroyPrefabAfter = 0;

		protected float stopEmittingAfter = -1;


		// collider
		protected Collider colliderComponent;

		protected Collider2D collider2DComponent;

		protected override void Init()
		{
			this.blocked.Clear();
			this.damageBlocked.Clear();
			this.zoneBlocked.Clear();
			this.zoneDamageBlocked.Clear();

			this.colliderComponent = this.GetComponent<Collider>();
			this.collider2DComponent = this.GetComponent<Collider2D>();

			if(this.settings.destroyAfterTime)
			{
				TransformHelper.Destroy(this.gameObject, this.settings.destroyTime);
			}

			// combatant
			if(this.settings.alwaysOn &&
				this.settings.setCombatant)
			{
				this.combatant = this.settings.combatantSetting.Create(
					new Group(FactionSetting.Get(this.settings.faction)),
					true, this.transform.position);
				if(combatant != null)
				{
					this.combatant.Object.SetGameObjectSimple(this.gameObject);
					this.combatant.Battle.StartBattle();
				}
			}
			else
			{
				this.combatant = ORKComponentHelper.GetCombatant(this.gameObject);
			}

			if(this.settings.alwaysOn &&
				this.combatant != null &&
				this.settings.alwaysOnAbility.StoredAsset != null)
			{
				AbilityShortcut ability = this.combatant.Abilities.GetUseable(
					this.settings.alwaysOnAbility.StoredAsset.Settings);
				if(ability == null &&
					!this.settings.alwaysOnKnowsAbility)
				{
					ability = new AbilityShortcut(this.settings.alwaysOnAbility.StoredAsset.Settings, 1, AbilityState.None);
				}
				if(ability != null)
				{
					this.SetAction(new AbilityAction(this.combatant, ability));
					if(this.action != null)
					{
						if(!this.settings.alwaysOnConsumeCosts)
						{
							this.action.ConsumeDone = true;
						}
						DamageDealerActivation ddActivation = this.action.GetDamageDealerActivation();
						if(ddActivation != null)
						{
							ddActivation.Add(this, this.combatant);
						}
						this.SetDamageActive(true);
					}
				}
			}
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public virtual bool IsDamageActive
		{
			get { return this.damageActive && this.action != null; }
		}

		public virtual BaseAction Action
		{
			get { return this.action; }
		}

		public virtual void SetAudioClip(AudioClip a, PlayAudioSettings aset)
		{
			this.audioClip = a;
			this.audioSettings = aset;
		}

		public virtual void SetAudioType(SoundTypeAsset soundType, PlayAudioSettings aset)
		{
			this.audioClip = this.Combatant.Animations.GetAudioClip(soundType);
			this.audioSettings = aset;
		}

		public virtual void SetPrefab(GameObject prefab, bool mountPrefab, float destroyAfterTime, float emitTime)
		{
			this.prefab = prefab;
			this.mountPrefab = mountPrefab;
			this.destroyPrefabAfter = destroyAfterTime;
			this.stopEmittingAfter = emitTime;
		}

		public virtual void SetAction(BaseAction action)
		{
			this.action = action;
			if(this.action != null)
			{
				if(this.action.User != null &&
					this.combatant == null)
				{
					this.combatant = this.action.User;
				}
			}
			else if(this.damageActive)
			{
				this.SetDamageActive(false);
			}
		}

		public virtual void SetDamageActive(bool active)
		{
			if(this.damageActive != active)
			{
				this.damageActive = this.action != null ? active : false;
				if(this.damageActive)
				{
					this.doExpand = true;
				}
				if(!this.damageActive)
				{
					this.doExpand = false;
					this.blocked.Clear();
					this.damageBlocked.Clear();
					this.zoneBlocked.Clear();
					this.zoneDamageBlocked.Clear();
					this.audioClip = null;
					this.audioSettings = null;
					this.prefab = null;
					this.autoDeactivateAfter = -1;
				}
			}
		}

		public virtual void AutoDeactivateAfter(float time)
		{
			this.autoDeactivateAfter = time;
		}

		public virtual bool CheckTags(string[] tags)
		{
			if(tags != null)
			{
				for(int i = 0; i < tags.Length; i++)
				{
					for(int j = 0; j < this.settings.activationTag.Length; j++)
					{
						if(tags[i] == this.settings.activationTag[j])
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public virtual bool CheckTags(List<string> tags)
		{
			if(tags != null)
			{
				for(int i = 0; i < tags.Count; i++)
				{
					for(int j = 0; j < this.settings.activationTag.Length; j++)
					{
						if(tags[i] == this.settings.activationTag[j])
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		protected virtual void DoDamage(GameObject obj, Vector3 position, Quaternion rotation)
		{
			if(this.action != null)
			{
				IDamageZone zone = obj.GetComponent<IDamageZone>();
				if(zone == null &&
					this.settings.zoneFromChildren)
				{
					zone = obj.GetComponentInChildren<IDamageZone>();
				}
				if(zone == null &&
					this.settings.zoneFromParent)
				{
					zone = obj.GetComponentInParent<IDamageZone>();
				}
				if(zone != null &&
					zone.CanDamage(this, this.action))
				{
					zone.Damage(this.action);
					if(this.settings.alwaysOn &&
						this.settings.alwaysOnConsumeCosts)
					{
						this.action.ConsumeDone = false;
					}
					if(this.prefab != null)
					{
						GameObject pref = Maki.Pooling.Get(this.prefab, position, rotation.eulerAngles);
						if(this.stopEmittingAfter >= 0)
						{
							ComponentHelper.EmitParticlesAfter(pref, false, this.stopEmittingAfter, ComponentScope.AllInChildren);
						}
						if(this.destroyPrefabAfter > 0)
						{
							TransformHelper.Destroy(pref, this.destroyPrefabAfter);
						}
						if(this.mountPrefab)
						{
							pref.transform.SetParent(obj.transform);
						}
					}
					if(this.audioClip != null)
					{
						this.audioSettings.PlayAudio(obj, this.audioClip);
					}

					// combatant
					if(zone.Combatant != null)
					{
						if(!this.blocked.ContainsKey(zone.Combatant))
						{
							this.blocked.Add(zone.Combatant, this.settings.resetTargets ? this.settings.targetResetTime : Mathf.Infinity);
						}
						if(!this.damageBlocked.ContainsKey(zone.Combatant))
						{
							this.damageBlocked.Add(zone.Combatant, this.settings.damageEvery);
						}
					}
					// other zones
					else
					{
						if(!this.zoneBlocked.ContainsKey(zone))
						{
							this.zoneBlocked.Add(zone, this.settings.resetTargets ? this.settings.targetResetTime : Mathf.Infinity);
						}
						if(!this.zoneDamageBlocked.ContainsKey(zone))
						{
							this.zoneDamageBlocked.Add(zone, this.settings.damageEvery);
						}
					}

					if(this.settings.destroyOnDamage)
					{
						TransformHelper.Destroy(this.gameObject);
					}
				}
			}
		}

		public virtual bool CheckOrigin(Transform other)
		{
			return !this.transform.IsChildOf(other) &&
				!other.IsChildOf(this.transform);
		}

		protected virtual void Update()
		{
			if(this.damageActive)
			{
				float delta = ORK.Game.DeltaBattleTime;
				if(this.autoDeactivateAfter > 0)
				{
					this.autoDeactivateAfter -= delta;
					if(this.autoDeactivateAfter <= 0)
					{
						this.autoDeactivateAfter = -1;
						this.SetDamageActive(false);
					}
				}
				if(this.damageActive)
				{
					if(this.settings.damageEvery > 0)
					{
						if(this.damageBlocked.Count > 0)
						{
							List<Combatant> keys = new List<Combatant>(this.damageBlocked.Keys);
							for(int i = 0; i < keys.Count; i++)
							{
								this.damageBlocked[keys[i]] -= delta;
								if(this.damageBlocked[keys[i]] <= 0)
								{
									this.damageBlocked.Remove(keys[i]);
								}
							}
						}
						if(this.zoneDamageBlocked.Count > 0)
						{
							List<IDamageZone> keys = new List<IDamageZone>(this.zoneDamageBlocked.Keys);
							for(int i = 0; i < keys.Count; i++)
							{
								this.zoneDamageBlocked[keys[i]] -= delta;
								if(this.zoneDamageBlocked[keys[i]] <= 0)
								{
									this.zoneDamageBlocked.Remove(keys[i]);
								}
							}
						}
					}
					if(this.settings.resetTargets)
					{
						if(this.blocked.Count > 0)
						{
							List<Combatant> keys = new List<Combatant>(this.blocked.Keys);
							for(int i = 0; i < keys.Count; i++)
							{
								this.blocked[keys[i]] -= delta;
								if(this.blocked[keys[i]] <= 0)
								{
									this.blocked.Remove(keys[i]);
								}
							}
						}
						if(this.zoneBlocked.Count > 0)
						{
							List<IDamageZone> keys = new List<IDamageZone>(this.zoneBlocked.Keys);
							for(int i = 0; i < keys.Count; i++)
							{
								this.zoneBlocked[keys[i]] -= delta;
								if(this.zoneBlocked[keys[i]] <= 0)
								{
									this.zoneBlocked.Remove(keys[i]);
								}
							}
						}
					}
					if(this.settings.changeCollider && this.doExpand)
					{
						if(this.colliderComponent != null)
						{
							float change = this.settings.expand * delta;
							if(this.colliderComponent is BoxCollider)
							{
								BoxCollider bc = this.colliderComponent as BoxCollider;
								bc.size += new Vector3(change, change, change);
							}
							else if(this.colliderComponent is SphereCollider)
							{
								SphereCollider sc = this.colliderComponent as SphereCollider;
								sc.radius += change;
							}
							else if(this.colliderComponent is CapsuleCollider)
							{
								CapsuleCollider cc = this.colliderComponent as CapsuleCollider;
								cc.radius += change;
								cc.height += change;
							}
						}
						else if(this.collider2DComponent != null)
						{
							float change = this.settings.expand * delta;
							if(this.collider2DComponent is BoxCollider2D)
							{
								BoxCollider2D bc = this.collider2DComponent as BoxCollider2D;
								bc.size += new Vector2(change, change);
							}
							else if(this.collider2DComponent is CircleCollider2D)
							{
								CircleCollider2D cc = this.collider2DComponent as CircleCollider2D;
								cc.radius += change;
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Blocked functions
		============================================================================
		*/
		public virtual int BlockedCount
		{
			get { return this.blocked.Count; }
		}

		public virtual bool IsBlocked(Combatant combatant)
		{
			return this.blocked.ContainsKey(combatant);
		}

		public virtual bool IsDamageBlocked(Combatant combatant)
		{
			return this.damageBlocked.ContainsKey(combatant);
		}

		public virtual bool IsBlocked(IDamageZone zone)
		{
			return this.zoneBlocked.ContainsKey(zone);
		}

		public virtual bool IsDamageBlocked(IDamageZone zone)
		{
			return this.zoneDamageBlocked.ContainsKey(zone);
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			if(this.damageActive &&
				DamageDealerType.TriggerEnter == this.settings.type &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			if(this.damageActive &&
				DamageDealerType.TriggerExit == this.settings.type &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnTriggerStay(Collider other)
		{
			if(this.damageActive &&
				DamageDealerType.TriggerStay == this.settings.type &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(this.damageActive &&
				DamageDealerType.TriggerEnter == this.settings.type &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			if(this.damageActive &&
				DamageDealerType.TriggerExit == this.settings.type &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnTriggerStay2D(Collider2D other)
		{
			if(this.damageActive &&
				DamageDealerType.TriggerStay == this.settings.type &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Collision functions
		============================================================================
		*/
		protected virtual void OnCollisionEnter(Collision collisionInfo)
		{
			if(this.damageActive &&
				DamageDealerType.CollisionEnter == this.settings.type &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnCollisionExit(Collision collisionInfo)
		{
			if(this.damageActive &&
				DamageDealerType.CollisionExit == this.settings.type &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnCollisionStay(Collision collisionInfo)
		{
			if(this.damageActive &&
				DamageDealerType.CollisionStay == this.settings.type &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnParticleCollision(GameObject other)
		{
			if(this.damageActive &&
				DamageDealerType.CollisionEnter == this.settings.type &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other, other.transform.position, other.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Collision2D functions
		============================================================================
		*/
		protected virtual void OnCollisionEnter2D(Collision2D collisionInfo)
		{
			if(this.damageActive &&
				DamageDealerType.CollisionEnter == this.settings.type &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnCollisionExit2D(Collision2D collisionInfo)
		{
			if(this.damageActive &&
				DamageDealerType.CollisionExit == this.settings.type &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}

		protected virtual void OnCollisionStay2D(Collision2D collisionInfo)
		{
			if(this.damageActive &&
				DamageDealerType.CollisionStay == this.settings.type &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Custom functions
		============================================================================
		*/
		public virtual void CustomDamage(GameObject gameObject, Vector3 position, Quaternion rotation)
		{
			if(gameObject != null &&
				this.damageActive &&
				DamageDealerType.Custom == this.settings.type &&
				this.CheckOrigin(gameObject.transform.root))
			{
				this.DoDamage(gameObject, position, rotation);
				if(this.settings.destroyOnCollision)
				{
					TransformHelper.Destroy(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "/GamingIsLove/ORKFramework/Components/DamageDealer Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Start Type", "Select how dealing damage is started:\n" +
				"- Trigger Enter: When a damage zone enters this game object's trigger.\n" +
				"- Trigger Exit: When a damage zone exits this game object's trigger.\n" +
				"- Trigger Stay: While a damage zone stays this game object's trigger.\n" +
				"- Collision Enter: When a damage zone starts colliding with this game object's collider. " +
				"Also supports particle collision.\n" +
				"- Collision Exit: When a damage zone stops colliding with this game object's collider.\n" +
				"- Collision Stay: While a damage zone is colliding with this game object's collider.\n" +
				"- Custom: By calling this damage dealer's 'CustomDamage' function.")]
			[EditorFoldout("Damage Dealer Settings", "Define how this damage dealer can damage targets.")]
			public DamageDealerType type = DamageDealerType.TriggerEnter;

			[EditorHelp("Change Collider", "Expand the collider's bounds while the damage dealer is active.\n" +
				"E.g. use this for explosion shockwaves expanding.")]
			public bool changeCollider = false;

			[EditorHelp("Expand Units per Second", "Expands the collider's bounds by the defined world units per second.")]
			[EditorIndent]
			[EditorCondition("changeCollider", true)]
			[EditorEndCondition]
			public float expand = 0;


			// always on
			[EditorHelp("Always On", "This damage dealer is always active and doesn't need to be activated.\n" +
				"E.g. used for environmental damage like traps or for dealing contact damage when running into an enemy.")]
			[EditorSeparator]
			[EditorTitleLabel("Environmental Damage (Always On)")]
			[EditorLabel("You can enable a damage dealer to do environmental damage.\n" +
				"The damage dealer will always be acitvated without having an action fired.\n" +
				"You can use this to create traps, hazardous areas or add contact damage to combatants.\n" +
				"An environmental damage dealer always requires a combatant - " +
				"you can either define a combatant here, or let the damage dealer find a 'CombatantComponent' " +
				"attached to the game object (e.g. when on an already spawned combatant).\n" +
				"The combatant needs to know the selected ability (not used as a base/counter attack) " +
				"and be able to use it.")]
			public bool alwaysOn = false;

			[EditorHelp("Ability", "Select the ability that will be used.\n" +
				"The combatant must know the ability.")]
			[EditorCondition("alwaysOn", true)]
			public AssetSelection<AbilityAsset> alwaysOnAbility = new AssetSelection<AbilityAsset>();

			[EditorHelp("Knows Ability", "The combatant has to know the ability.\n" +
				"If disabled, the combatant doesn't need to know the ability.")]
			public bool alwaysOnKnowsAbility = true;

			[EditorHelp("Consume Costs", "Using the ability will consume it's use costs.")]
			public bool alwaysOnConsumeCosts = false;

			[EditorHelp("Set Combatant", "Define the combatant that will be used.\n" +
				"If disabled, a combatant on this game object, it's children or parent objects will be searched.")]
			public bool setCombatant = false;

			[EditorHelp("Faction", "The faction of the combatant.")]
			[EditorCondition("setCombatant", true)]
			public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();

			[EditorAutoInit]
			[EditorEndCondition(2)]
			public CombatantInit combatantSetting;


			// destroy settings
			[EditorHelp("Destroy After Time", "Destroy the damage dealer's game object after a defined amount of time after activation.")]
			[EditorSeparator]
			[EditorTitleLabel("Destroy Settings")]
			public bool destroyAfterTime = false;

			[EditorHelp("Destroy Time (s)", "The time in seconds until this damage dealer's game object is destroyed.")]
			[EditorIndent]
			[EditorCondition("destroyAfterTime", true)]
			[EditorEndCondition]
			public float destroyTime = 0;

			[EditorHelp("Destroy On Damage", "Destroy the damage dealer's game object after dealing damage.")]
			public bool destroyOnDamage = false;

			[EditorHelp("Destroy On Collision", "Destroy the damage dealer's game object after something collides with it or enters it's trigger.\n" +
				"Requires a collision or trigger start type.")]
			[EditorCondition("type", DamageDealerType.TriggerEnter)]
			[EditorCondition("type", DamageDealerType.TriggerExit)]
			[EditorCondition("type", DamageDealerType.TriggerStay)]
			[EditorCondition("type", DamageDealerType.CollisionEnter)]
			[EditorCondition("type", DamageDealerType.CollisionStay)]
			[EditorCondition("type", DamageDealerType.CollisionExit)]
			[EditorEndCondition]
			public bool destroyOnCollision = false;


			// damage settings
			[EditorHelp("Damage Zone From Children", "Damage zones will be searched in child objects of the hit game object.")]
			[EditorSeparator]
			[EditorTitleLabel("Damage Settings")]
			public bool zoneFromChildren = false;

			[EditorHelp("Damage Zone From Parent", "Damage zones will be searched in parent objects of the hit game object.")]
			public bool zoneFromParent = false;


			// target settings
			[EditorHelp("One Time Damage", "Only deal damage once per target.\n" +
				"If disabled, a target can be damaged multiple times.")]
			[EditorSeparator]
			public bool oneTimeDamage = false;

			[EditorHelp("One Target", "Only damage one target.\n" +
				"If disabled, multiple targets can be damaged.")]
			public bool oneTarget = false;

			[EditorHelp("Reset Targets", "Reset the already used targes (from 'One Time Damage' or 'One Target') after a defined time.")]
			[EditorCondition("oneTimeDamage", true)]
			[EditorCondition("oneTarget", true)]
			public bool resetTargets = false;

			[EditorHelp("Reset After (s)", "The time in seconds after which targets will be reset.")]
			[EditorIndent]
			[EditorCondition("resetTargets", true)]
			[EditorEndCondition(2)]
			public float targetResetTime = 1;

			[EditorHelp("Damage Every (s)", "The time in seconds between dealing damage while staying in trigger/colliding.")]
			[EditorCondition("type", DamageDealerType.TriggerStay)]
			[EditorCondition("type", DamageDealerType.CollisionStay)]
			[EditorEndCondition]
			[EditorEndFoldout]
			public float damageEvery = 0;


			// auto activate
			[EditorHelp("Field", "This damage dealer can be activated in the field.")]
			[EditorFoldout("Activation Settings", "Define how this damage dealer can be activated.")]
			[EditorCondition("alwaysOn", false)]
			public bool autoField = false;

			public BattleSystemCheck autoBattleSystem = new BattleSystemCheck();


			// supported actions
			[EditorHelp("Base Attack", "Activate for base attacks.")]
			[EditorSeparator]
			[EditorTitleLabel("Activate on Action")]
			public bool baseAttack = false;

			[EditorHelp("Counter Attack", "Activate for counter attacks.")]
			public bool counterAttack = false;

			[EditorHelp("Ability", "Select the ability that can activate this damage dealer.")]
			[EditorArray("Add Ability", "Adds an ability that can activate this damage dealer.", "",
				"Remove", "Removes this ability", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Ability", "Select the ability that will be used.", ""
				})]
			public AssetSelection<AbilityAsset>[] ability = new AssetSelection<AbilityAsset>[0];

			[EditorHelp("Item", "Select the item that can activate this damage dealer.")]
			[EditorArray("Add Item", "Adds an item that can activate this damage dealer.", "",
				"Remove", "Removes this item", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Item", "Select the item that will be used.", ""
				})]
			public AssetSelection<ItemAsset>[] item = new AssetSelection<ItemAsset>[0];


			// tags
			[EditorHelp("Activation Tag", "The tag used to activate this damage dealer.")]
			[EditorEndFoldout]
			[EditorSeparator]
			[EditorTitleLabel("Activate Tags")]
			[EditorLabel("You can enable damage dealers via tags without setting them up for a specific ability or item.\n" +
				"The damage dealer will be activated/deactivated if one of the tags is used in an 'Activate Damage Dealer' node or defined by an ability or item.")]
			[EditorWidth(true, hideName = true)]
			[EditorArray("Add Activation Tag", "Adds an activation tag to this damage dealer.", "",
				"Remove", "Removes this tag", "", isHorizontal = true)]
			[EditorEndCondition]
			public string[] activationTag = new string[0];

			public Settings()
			{

			}

			public virtual bool CheckAutoActivate(Combatant combatant)
			{
				return !this.alwaysOn &&
					(!combatant.Battle.InBattle && this.autoField) ||
						(combatant.Battle.InBattle && this.autoBattleSystem.Check());
			}
		}
	}
}
