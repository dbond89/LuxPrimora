﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Combatant Highlight: Use Range Scale")]
	public class UseRangeScaleCombatantHighlightCursorPrefab : MonoBehaviour, ICombatantHighlightCursorPrefab
	{
		protected Combatant combatant;

		protected IShortcut lastShortcut;

		public virtual void StartSelection(Combatant combatant)
		{
			this.combatant = combatant;
			this.transform.localScale = Vector3.zero;
			this.UpdateScale();
		}

		public virtual void StopSelection()
		{
			this.combatant = null;
			this.lastShortcut = null;
			this.transform.localScale = Vector3.one;
		}

		protected virtual void Update()
		{
			this.UpdateScale();
		}

		protected virtual void UpdateScale()
		{
			if(this.combatant != null &&
				this.combatant.Battle.BattleMenu != null &&
				this.combatant.Battle.BattleMenu.TargetHighlight.Shortcut != this.lastShortcut)
			{
				bool used = false;
				this.lastShortcut = this.combatant.Battle.BattleMenu.TargetHighlight.Shortcut;
				if(this.lastShortcut != null)
				{
					TargetSelectionSettings targetSettings = TargetSelectionSettings.Get(this.lastShortcut);
					if(targetSettings != null)
					{
						UseRange useRange = targetSettings.useRange.GetConditionalRange(
							this.combatant, this.lastShortcut as IVariableSource);
						if(useRange != null)
						{
							float range = useRange.GetRangeValue(this.combatant);
							if(range > 0)
							{
								used = true;
								this.transform.localScale = new Vector3(range, range, range);
							}
						}
					}
				}
				if(!used)
				{
					this.transform.localScale = Vector3.zero;
				}
			}
		}
	}
}
