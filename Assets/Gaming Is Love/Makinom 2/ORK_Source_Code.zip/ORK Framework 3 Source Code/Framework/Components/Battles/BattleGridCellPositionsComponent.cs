﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Battle Grid Cell Positions")]
	public class BattleGridCellPositionsComponent : SerializedBehaviour<BattleGridCellPositionsComponent.Settings>
	{
		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Player/Ally Positions", "Cell positions are used for placing combatants at specific places on a grid cell.\n" +
				"Player/ally positions are used by player and ally combatants in the order they're added to a cell as occupants.", "")]
			[EditorEndFoldout]
			[EditorArray("Add Player/Ally Position ", "Adds a cell position that'll be used by player and ally combatants for placement on the cell.", "",
				"Remove", "Removes this cell position.", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Player/Ally Position", "Define a game object that'll be used as placement position for player and ally combatants.", ""
			})]
			public CellPosition[] playerPosition = new CellPosition[0];

			[EditorFoldout("Enemy Positions", "Cell positions are used for placing combatants at specific places on a grid cell.\n" +
				"Enemy positions are used by enemy combatants in the order they're added to a cell as occupants.", "")]
			[EditorEndFoldout]
			[EditorArray("Add Enemy Position ", "Adds a cell position that'll be used by enemy combatants for placement on the cell.", "",
				"Remove", "Removes this cell position.", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Enemy Position", "Define a game object that'll be used as placement position for enemy combatants.", ""
			})]
			public CellPosition[] enemyPosition = new CellPosition[0];

			public Settings()
			{

			}

			public virtual CellPosition GetPosition(int index, bool isEnemy)
			{
				if(isEnemy)
				{
					if(index >= 0 && index < this.enemyPosition.Length)
					{
						return this.enemyPosition[index];
					}
				}
				else if(index >= 0 && index < this.playerPosition.Length)
				{
					return this.playerPosition[index];
				}
				return null;
			}
		}


		/*
		============================================================================
		Cell position class
		============================================================================
		*/
		public class CellPosition : BaseData
		{
			[EditorHelp("Position Object", "Select a game object that'll be used as placement position.")]
			[EditorInfo(allowSceneObjects = true)]
			public GameObject positionObject;


			// rotation
			[EditorSeparator]
			[EditorHelp("Set Spawn Rotation", "Set the rotation of a combatant spawning on this cell position.")]
			public bool setSpawnRotation = false;

			[EditorHelp("Spawn Rotation", "The rotation a combatant spawning on this cell position will have.")]
			[EditorCondition("setSpawnRotation", true)]
			[EditorEndCondition]
			public float spawnRotation = 0;

			public CellPosition()
			{

			}

			public virtual Vector3 GetSpawnRotation(Vector3 eulerAngles)
			{
				if(ORK.BattleGridSettings.horizontalPlane.IsXZ)
				{
					return new Vector3(0, eulerAngles.y + (this.setSpawnRotation ? this.spawnRotation : 0), 0);
				}
				else
				{
					return new Vector3(0, 0, eulerAngles.z + (this.setSpawnRotation ? this.spawnRotation : 0));
				}
			}
		}
	}
}
