﻿
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/UI/Object HUD")]
	public class ObjectHUDComponent : SerializedBehaviour<ObjectHUDComponent.Settings>
	{
		// in-game
		protected bool initialized = false;

		protected bool registered = false;

		protected DataCall call;

		protected List<VariableHandler> registeredHandlers;

		protected virtual void Start()
		{
			this.initialized = true;
			this.Register();
		}

		protected virtual DataCall Call
		{
			get
			{
				if(this.call == null)
				{
					this.call = new DataCall(this.gameObject);
				}
				return this.call;
			}
		}

		protected virtual void LateUpdate()
		{
			for(int i = 0; i < this.settings.hud.Length; i++)
			{
				this.settings.hud[i].Tick(this.Call, this.gameObject);
			}
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			if(this.initialized)
			{
				this.Register();
			}
		}

		protected virtual void OnDisable()
		{
			if(this.initialized)
			{
				this.Unregister();
			}
		}

		protected virtual void OnDestroy()
		{
			if(this.initialized)
			{
				this.Unregister();
				for(int i = 0; i < this.settings.hud.Length; i++)
				{
					this.settings.hud[i].Remove();
				}
			}
		}

		public virtual void Register()
		{
			if(!this.registered)
			{
				for(int i = 0; i < this.settings.hud.Length; i++)
				{
					this.settings.hud[i].Register(this.Call, ref this.registeredHandlers);
				}
				this.registered = true;
			}
		}

		public virtual void Unregister()
		{
			if(this.registered)
			{
				for(int i = 0; i < this.settings.hud.Length; i++)
				{
					this.settings.hud[i].Unregister(this.Call, this.registeredHandlers);
				}
				if(this.registeredHandlers != null)
				{
					Maki.Pooling.VariableHandlerLists.Add(this.registeredHandlers);
					this.registeredHandlers = null;
				}
				this.registered = false;
				this.call = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorArray("Add Object HUD", "Adds an 'Object' HUD to this game object.", "",
				"Remove", "Removes this HUD.", "",
				isMove=true, isCopy=true, noRemoveCount=1,
				foldout=true, foldoutText=new string[] {
					"Object HUD", "Select the 'Object' type HUD and define optional conditions.", ""
				})]
			public ObjectHUDSelection[] hud = new ObjectHUDSelection[]
			{
				new ObjectHUDSelection()
			};

			public Settings()
			{

			}
		}
	}
}
