﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Move AI/Point Of Interest")]
	public class PointOfInterest : SerializedBehaviour<PointOfInterest.Settings>
	{
		protected virtual void Start()
		{
			ORK.Game.Scene.AddPointOfInterest(this);
		}

		protected virtual void OnDestroy()
		{
			ORK.Game.Scene.RemovePointOfInterest(this);
		}

		public virtual Revisit CreateRevisit()
		{
			return new Revisit(this, this.settings.revisitAfter);
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/PointOfInterest Icon.png");
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Detection Tag", "A combatant can detect this point of interest if at least one detection tag matches.", "")]
			[EditorWidth(true)]
			[EditorLabel("Points of interest are used by combatants using the move AI.\n" +
				"Combatants can detect points of interest while moving between waypoints and move to them.\n" +
				"What happens at the point of interest is determined by the used schematic, " +
				"the combatant is used as 'Machine Object', the point of interest as 'Starting Object'.")]
			public string detectionTag = "";


			// schematic
			[EditorHelp("Schematic Asset", "Select a schematic asset that will be started when the combatant reaches this point of interest.\n" +
				"The combatant will be used as 'Machine Object', the point of interest as 'Starting Object'.", "")]
			[EditorSeparator]
			public AssetSource<MakinomSchematicAsset> schematicAsset = new AssetSource<MakinomSchematicAsset>();

			[EditorHelp("Wait", "Wait for the schematic to finish before resuming the move AI.", "")]
			[EditorCondition("schematicAsset.Has", true)]
			[EditorElseCondition]
			[EditorEndCondition]
			public bool waitForSchematic = false;


			// visit
			[EditorHelp("Visit Once", "A combatant an only visit this point of interest once.", "")]
			[EditorSeparator]
			public bool visitOnce = true;

			[EditorHelp("Revisit After (s)", "The time in seconds after which a combatant can visit/detect this point of interest again.", "")]
			[EditorLimit(0.0f, false)]
			[EditorCondition("visitOnce", false)]
			[EditorEndCondition]
			public float revisitAfter = 1;


			// stop range
			[EditorSeparator]
			[EditorTitleLabel("Stop Range")]
			public RangeValue stopRange = new RangeValue(0);


			// own move speed
			[EditorHelp("Own Move Speed", "This point of interest override's the move AI's move speed.", "")]
			[EditorSeparator]
			[EditorTitleLabel("Move Speed")]
			public bool ownMoveSpeed = false;

			[EditorCondition("ownMoveSpeed", true)]
			[EditorEndCondition]
			[EditorAutoInit]
			public MoveSpeed<GameObjectSelection> moveSpeed;

			public Settings()
			{

			}

			public bool CheckTag(string[] tags)
			{
				if(tags.Length > 0)
				{
					for(int i = 0; i < tags.Length; i++)
					{
						if(tags[i] == this.detectionTag)
						{
							return true;
						}
					}
					return false;
				}
				else
				{
					return true;
				}
			}
		}

		public class Revisit
		{
			public PointOfInterest poi;

			public float time = -1;

			public Revisit(PointOfInterest poi, float time)
			{
				this.poi = poi;
				this.time = time;
			}
		}
	}
}
